import { w as writable } from "./index.js";
import { b as attr_class, c as stringify } from "./index2.js";
import { e as escape_html } from "./attributes.js";
const savedConvId = typeof localStorage !== "undefined" ? localStorage.getItem("current_conv_id") || "" : "";
const messages = writable([]);
const currentConversationId = writable(savedConvId);
const isStreaming = writable(false);
const currentModelId = writable("");
const currentPersonaId = writable("default");
const conversations = writable([]);
function EmptyState($$renderer, $$props) {
  let { icon = "fa-inbox", message = "暂无数据", submessage = "" } = $$props;
  $$renderer.push(`<div class="flex flex-col items-center justify-center py-12 text-earth-400"><i${attr_class(`fas ${stringify(icon)} text-4xl mb-3 opacity-40`)}></i> <p class="text-sm text-bark-600">${escape_html(message)}</p> `);
  if (submessage) {
    $$renderer.push("<!--[0-->");
    $$renderer.push(`<p class="text-xs mt-1 text-earth-500">${escape_html(submessage)}</p>`);
  } else {
    $$renderer.push("<!--[-1-->");
  }
  $$renderer.push(`<!--]--></div>`);
}
export {
  EmptyState as E,
  currentConversationId as a,
  currentModelId as b,
  conversations as c,
  currentPersonaId as d,
  isStreaming as i,
  messages as m
};
