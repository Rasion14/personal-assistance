import { a as attr } from "../../../chunks/attributes.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let newToolName = "";
    $$renderer2.push(`<div class="flex flex-col h-full p-6"><div class="flex items-center justify-between mb-6"><h1 class="text-2xl font-bold glow-text">🔧 工具管理</h1> <div class="flex items-center gap-2"><input type="text"${attr("value", newToolName)} placeholder="新工具名" class="text-sm py-1.5 w-32"/> <button class="btn-primary text-sm">+ 新建</button></div></div> `);
    {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<p class="text-earth-500">加载中...</p>`);
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
export {
  _page as default
};
