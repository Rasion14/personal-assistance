import { b as attr_class, a7 as derived, c as stringify, e as ensure_array_like, s as store_get, u as unsubscribe_stores, a8 as store_set, a as attr_style } from "../../chunks/index2.js";
import { marked } from "marked";
import DOMPurify from "dompurify";
import { e as escape_html, a as attr } from "../../chunks/attributes.js";
import { m as messages, b as currentModelId, d as currentPersonaId, i as isStreaming, E as EmptyState } from "../../chunks/EmptyState.js";
function html(value) {
  var html2 = String(value ?? "");
  var open = "<!---->";
  return open + html2 + "<!---->";
}
const API_BASE = "http://localhost:8000";
function getApiKey() {
  if (typeof localStorage !== "undefined") {
    return localStorage.getItem("api_key") || "";
  }
  return "";
}
async function request(path, options = {}) {
  const apiKey = getApiKey();
  const headers = {
    "Content-Type": "application/json"
  };
  if (apiKey) {
    headers["X-API-Key"] = apiKey;
  }
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: { ...headers, ...options.headers || {} }
  });
  if (!res.ok) {
    const error = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(error.detail || error.error?.message || `API error: ${res.status}`);
  }
  return res.json();
}
async function switchModel(modelId) {
  return request(`/api/models/switch`, {
    method: "POST",
    body: JSON.stringify({ model_id: modelId })
  });
}
function MarkdownContent($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { content = "", className = "" } = $$props;
    marked.setOptions({ gfm: true, breaks: true });
    let html$1 = derived(() => content ? DOMPurify.sanitize(marked.parse(content, { async: false })) : "");
    $$renderer2.push(`<div${attr_class(`markdown-content ${stringify(
      // 在 HTML 渲染后为代码块添加 wrapper 和复制按钮
      className
    )}`)}>${html(html$1())}</div>`);
  });
}
function ToolCallCard($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { toolCall } = $$props;
    let statusClass = derived(() => toolCall.status === "loading" ? "text-warm-500" : toolCall.status === "done" ? "text-forest-500" : "text-red-400");
    $$renderer2.push(`<div class="glass p-3 mb-2"><div class="flex items-center gap-2"><i class="fas fa-wrench text-forest-500"></i> <span class="font-mono text-sm font-semibold text-bark-700">${escape_html(toolCall.name)}</span> <span${attr_class(`text-xs ${statusClass()}`)}>`);
    if (toolCall.status === "loading") {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<i class="fas fa-spinner fa-spin"></i> 执行中`);
    } else if (toolCall.status === "done") {
      $$renderer2.push("<!--[1-->");
      $$renderer2.push(`<i class="fas fa-check"></i> 完成`);
    } else {
      $$renderer2.push("<!--[-1-->");
      $$renderer2.push(`<i class="fas fa-times"></i> 错误`);
    }
    $$renderer2.push(`<!--]--></span></div> `);
    if (toolCall.result) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<pre class="mt-2 text-xs text-earth-700">${escape_html(toolCall.result)}</pre>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
function MessageBubble($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let { msg, streaming = false } = $$props;
    let isUser = derived(() => msg.role === "user");
    let isStreamingMsg = derived(() => !isUser() && streaming && msg === store_get($$store_subs ??= {}, "$messages", messages).at(-1));
    let msgPersonaId = derived(() => msg.personaId || "default");
    let personaLabel = derived(() => msgPersonaId() === "maid" ? "小樱" : msgPersonaId() === "default" ? "Rasion" : msgPersonaId() || "Agent");
    $$renderer2.push(`<div${attr_class(`flex ${isUser() ? "justify-end" : "justify-start"} group`)}><div class="max-w-2xl w-full"><div class="flex items-center gap-2 mb-1.5 px-1"><span class="text-sm font-semibold text-bark-700">${escape_html(isUser() ? "✨ 帅气的主人" : "🌸 " + personaLabel())}</span> <button class="opacity-0 group-hover:opacity-100 text-earth-400 hover:text-red-400 transition-opacity text-xs" title="删除此轮对话"><i class="fas fa-times-circle"></i></button> `);
    if (!isUser() && isStreamingMsg()) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<span class="status-dot streaming"></span>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--></div> `);
    if (!isUser() && msg.toolCalls && msg.toolCalls.length > 0) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="mb-2"><!--[-->`);
      const each_array = ensure_array_like(msg.toolCalls);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let tc = each_array[$$index];
        ToolCallCard($$renderer2, { toolCall: tc });
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> <div${attr_class(`glass p-4 ${isUser() ? "bg-gradient-to-br from-forest-500/5 to-forest-500/8" : "bg-white/80"}`)}>`);
    if (isStreamingMsg() && streaming) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<span class="typing-cursor">${escape_html(msg.content)}</span>`);
    } else if (isUser()) {
      $$renderer2.push("<!--[1-->");
      $$renderer2.push(`<div class="text-sm whitespace-pre-wrap text-bark-800">${escape_html(msg.content)}</div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
      MarkdownContent($$renderer2, { content: msg.content });
    }
    $$renderer2.push(`<!--]--></div></div></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
function ModelSelector($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let loading = true;
    async function handleSwitch(modelId) {
      try {
        await switchModel(modelId);
        store_set(currentModelId, modelId);
      } catch {
      }
    }
    $$renderer2.push(`<div class="relative">`);
    $$renderer2.select(
      {
        value: store_get($$store_subs ??= {}, "$currentModelId", currentModelId),
        onchange: (e) => handleSwitch(e.target.value),
        disabled: loading,
        class: "bg-white/60 border border-earth-200 text-bark-600 text-xs rounded-lg px-2 py-1.5 focus:ring-1 focus:ring-forest-500/20 outline-none cursor-pointer max-w-[160px] truncate disabled:opacity-50",
        "aria-label": "选择模型"
      },
      ($$renderer3) => {
        {
          $$renderer3.push("<!--[0-->");
          $$renderer3.option({}, ($$renderer4) => {
            $$renderer4.push(`加载中...`);
          });
        }
        $$renderer3.push(`<!--]-->`);
      }
    );
    $$renderer2.push(`</div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
function PersonaSelector($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let personas = [];
    let loading = true;
    let currentPersona = derived(() => personas.find((p) => p.id === store_get($$store_subs ??= {}, "$currentPersonaId", currentPersonaId)) || personas[0] || {
      id: "default",
      name: "助手",
      display_name: "默认",
      icon: "fa-robot",
      color: "#4a9c5d",
      tagline: ""
    });
    $$renderer2.push(`<div class="persona-selector relative"><button${attr("disabled", loading, true)} class="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs transition-all cursor-pointer border bg-white/60 hover:bg-white/90 disabled:opacity-50"${attr_style(`border-color: ${stringify(currentPersona().color)}30;`)}${attr("title", `${stringify(currentPersona().display_name)}: ${stringify(currentPersona().tagline)}`)}><span class="flex items-center justify-center w-5 h-5 rounded-full text-[10px]"${attr_style(`background: ${stringify(currentPersona().color)}18; color: ${stringify(currentPersona().color)}`)}><i${attr_class(`fas ${stringify(currentPersona().icon)}`)}></i></span> <span class="text-bark-600">${escape_html(currentPersona().name)}</span> <i class="fas fa-chevron-down text-[10px] text-earth-400"></i></button> `);
    {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
function StatusIndicator($$renderer) {
  var $$store_subs;
  let status = derived(() => store_get($$store_subs ??= {}, "$isStreaming", isStreaming) ? "streaming" : "idle");
  $$renderer.push(`<div class="flex items-center gap-1.5"><span${attr_class(`status-dot ${status()}`)}></span> <span class="text-[11px] text-earth-500">${escape_html(store_get($$store_subs ??= {}, "$isStreaming", isStreaming) ? "思考中" : "就绪")}</span></div>`);
  if ($$store_subs) unsubscribe_stores($$store_subs);
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let input = "";
    let isSending = false;
    $$renderer2.push(`<div class="flex flex-col h-full"><div class="flex items-center justify-center px-6 py-2.5 glass border-0 rounded-none border-b border-earth-200 relative"><h1 class="text-lg font-bold glow-text font-serif tracking-wide">🌿 个人助手</h1> <div class="absolute right-6">`);
    StatusIndicator($$renderer2);
    $$renderer2.push(`<!----></div></div> <div class="flex-1 overflow-y-auto px-6 py-4 space-y-4">`);
    if (store_get($$store_subs ??= {}, "$messages", messages).length === 0) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="flex items-center justify-center h-full">`);
      EmptyState($$renderer2, {
        icon: "fa-leaf",
        message: "开始对话吧",
        submessage: "在下方输入消息，与 Agent 一起探索 🌱"
      });
      $$renderer2.push(`<!----></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
      $$renderer2.push(`<!--[-->`);
      const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$messages", messages));
      for (let i = 0, $$length = each_array.length; i < $$length; i++) {
        let msg = each_array[i];
        MessageBubble($$renderer2, {
          msg,
          streaming: store_get($$store_subs ??= {}, "$isStreaming", isStreaming)
        });
      }
      $$renderer2.push(`<!--]-->`);
    }
    $$renderer2.push(`<!--]--></div> <div class="px-4 py-3 border-t border-earth-200 glass border-0 rounded-none"><div class="max-w-3xl mx-auto"><div class="flex gap-2 items-end bg-white/60 rounded-2xl p-2 border border-earth-200 focus-within:border-forest-400 focus-within:ring-2 focus-within:ring-forest-500/10 transition-all"><textarea placeholder="输入消息... (Enter 发送)" class="flex-1 resize-none border-0 bg-transparent focus:ring-0 focus:border-0 focus:shadow-none p-2" rows="1">`);
    const $$body = escape_html(input);
    if ($$body) {
      $$renderer2.push(`${$$body}`);
    }
    $$renderer2.push(`</textarea> <button${attr("disabled", isSending, true)}${attr_class(`flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center transition-all ${"bg-forest-500 text-white hover:bg-forest-600 hover:shadow-lg"}`)} aria-label="发送消息"><i class="fas fa-paper-plane text-sm"></i></button></div> <div class="flex items-center justify-between gap-2 mt-2 text-xs"><div class="flex items-center gap-2">`);
    PersonaSelector($$renderer2);
    $$renderer2.push(`<!----> `);
    ModelSelector($$renderer2);
    $$renderer2.push(`<!----></div> <button class="text-xs text-earth-500 hover:text-forest-500 transition-colors px-2 py-1 rounded-lg border border-earth-200 hover:border-forest-400" title="工具配置">🔧 工具</button> <button class="text-xs text-earth-500 hover:text-forest-500 transition-colors px-2 py-1 rounded-lg border border-earth-200 hover:border-forest-400" title="Skill配置">🧩 Skills</button></div> `);
    {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--></div></div></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
export {
  _page as default
};
