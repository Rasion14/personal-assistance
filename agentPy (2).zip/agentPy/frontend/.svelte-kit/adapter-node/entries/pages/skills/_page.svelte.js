import "clsx";
import { b as attr_class, e as ensure_array_like, s as store_get, c as stringify, u as unsubscribe_stores } from "../../../chunks/index2.js";
import { w as writable } from "../../../chunks/index.js";
import { a as attr, e as escape_html } from "../../../chunks/attributes.js";
const skills = writable([]);
function SkillMarket($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    let installUrl = "";
    let installing = false;
    function getCategoryIcon(cat) {
      const icons = {
        web: "fa-globe",
        code: "fa-code",
        data: "fa-database",
        file: "fa-file",
        analysis: "fa-chart-bar",
        creativity: "fa-palette",
        automation: "fa-robot",
        other: "fa-puzzle-piece"
      };
      return icons[cat] || "fa-puzzle-piece";
    }
    function sourceLabel(skill) {
      const meta = skill.metadata || {};
      if (meta.source === "uploaded" || skill.install_path && skill.install_path.includes("uploaded")) return "📁 本地";
      return "🌐 网络";
    }
    $$renderer2.push(`<div class="h-full flex flex-col"><div class="flex gap-1 mb-4 bg-white/50 rounded-xl p-1 w-fit"><button${attr_class(`px-4 py-1.5 rounded-lg text-xs font-medium transition-colors ${"bg-forest-500 text-white"}`)}>🌐 URL 安装</button> <button${attr_class(`px-4 py-1.5 rounded-lg text-xs font-medium transition-colors ${"text-earth-600 hover:text-bark-700"}`)}>📁 本地上传</button></div> `);
    {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="flex gap-3 mb-6"><input${attr("value", installUrl)} placeholder="输入 Skill ZIP URL..." class="flex-1"/> <button${attr("disabled", installing, true)} class="btn-primary"><i class="fas fa-download mr-2"></i>${escape_html("安装")}</button></div>`);
    }
    $$renderer2.push(`<!--]--> <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 overflow-y-auto"><!--[-->`);
    const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$skills", skills));
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let skill = each_array[$$index];
      $$renderer2.push(`<div class="glass p-5"><div class="flex items-start justify-between mb-3"><div class="flex items-center gap-2"><i${attr_class(`fas ${stringify(getCategoryIcon(skill.category))} text-forest-500 text-lg`)}></i> <div><h3 class="font-semibold text-bark-700">${escape_html(skill.name)}</h3> <span class="text-xs text-earth-500">v${escape_html(skill.version)} · ${escape_html(sourceLabel(skill))}</span></div></div> <span${attr_class(`status-dot ${skill.status === "enabled" ? "working" : "idle"}`)}></span></div> <p class="text-sm text-earth-700 mb-3">${escape_html(skill.description || "无描述")}</p> <div class="flex gap-2"><button class="text-xs px-3 py-1 rounded-lg border border-earth-200 hover:border-forest-400 hover:text-forest-600 text-earth-600 transition-colors">${escape_html(skill.status === "enabled" ? "禁用" : "启用")}</button> <button class="text-xs px-3 py-1 rounded-lg border border-earth-200 hover:border-red-300 hover:text-red-400 text-earth-600 transition-colors">卸载</button></div></div>`);
    }
    $$renderer2.push(`<!--]--></div> `);
    if (store_get($$store_subs ??= {}, "$skills", skills).length === 0) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="flex-1 flex items-center justify-center"><div class="text-center text-earth-400"><i class="fas fa-puzzle-piece text-4xl mb-3 opacity-40"></i> <p class="text-sm">暂无已安装的 Skill</p></div></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
function _page($$renderer) {
  $$renderer.push(`<div class="flex flex-col h-full p-6"><h1 class="text-2xl font-bold glow-text mb-6"><i class="fas fa-puzzle-piece mr-2"></i> Skill 市场</h1> `);
  SkillMarket($$renderer);
  $$renderer.push(`<!----></div>`);
}
export {
  _page as default
};
