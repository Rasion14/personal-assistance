import { a as attr, e as escape_html } from "../../../chunks/attributes.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let apiKey = "";
    let saving = false;
    $$renderer2.push(`<div class="flex flex-col h-full p-6 max-w-2xl"><h1 class="text-2xl font-bold glow-text mb-6"><i class="fas fa-cog mr-2"></i> 设置</h1> <div class="space-y-6"><div class="glass p-6"><h2 class="text-lg font-semibold text-bark-800 mb-4">平台 API Key</h2> <p class="text-sm text-earth-700 mb-3">此 Key 需要与后端 <code class="text-forest-600 bg-forest-50 px-1.5 py-0.5 rounded">.env</code> 中的 <code class="text-forest-600 bg-forest-50 px-1.5 py-0.5 rounded">API_KEY</code> 一致。</p> <div class="space-y-3"><label class="block"><span class="text-sm text-earth-600">X-API-Key</span> <input type="password"${attr("value", apiKey)} class="w-full mt-1" placeholder="与后端 .env 中的 API_KEY 一致"/></label> <div class="flex items-center gap-3"><button${attr("disabled", saving, true)} class="btn-primary"><i class="fas fa-save mr-2"></i>${escape_html("保存")}</button> `);
    {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--></div></div></div> <div class="glass p-6"><h2 class="text-lg font-semibold text-bark-800 mb-4">LLM Provider 配置</h2> <p class="text-sm text-earth-700">LLM API Key 在 <code class="text-forest-600 bg-forest-50 px-1.5 py-0.5 rounded">backend/.env</code> 中配置，无需在此设置。</p></div> <div class="glass p-6"><h2 class="text-lg font-semibold text-bark-800 mb-4">关于</h2> <p class="text-earth-700 text-sm">Agent Platform v0.1.0 — 基于 Pydantic AI 构建的企业级智能助手平台 🌿</p></div></div></div>`);
  });
}
export {
  _page as default
};
