import { g as getContext, a as attr_style, s as store_get, b as attr_class, e as ensure_array_like, u as unsubscribe_stores, h as head, c as stringify } from "../../chunks/index2.js";
import { w as writable } from "../../chunks/index.js";
import { E as EmptyState, c as conversations, a as currentConversationId } from "../../chunks/EmptyState.js";
import { a as attr, e as escape_html } from "../../chunks/attributes.js";
import "@sveltejs/kit/internal";
import "../../chunks/exports.js";
import "../../chunks/utils2.js";
import "@sveltejs/kit/internal/server";
import "../../chunks/root.js";
import "../../chunks/state.svelte.js";
import "clsx";
const sidebarOpen = writable(true);
const getStores = () => {
  const stores$1 = getContext("__svelte__");
  return {
    /** @type {typeof page} */
    page: {
      subscribe: stores$1.page.subscribe
    },
    /** @type {typeof navigating} */
    navigating: {
      subscribe: stores$1.navigating.subscribe
    },
    /** @type {typeof updated} */
    updated: stores$1.updated
  };
};
const page = {
  subscribe(fn) {
    const store = getStores().page;
    return store.subscribe(fn);
  }
};
function Sidebar($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    function isActive(path) {
      return store_get($$store_subs ??= {}, "$page", page).url.pathname === path;
    }
    $$renderer2.push(`<button class="fixed top-3 z-50 p-1.5 rounded-lg bg-white/40 hover:bg-white/70 text-earth-400 hover:text-forest-500 transition-all duration-300"${attr_style(`left: ${store_get($$store_subs ??= {}, "$sidebarOpen", sidebarOpen) ? "16rem" : "0.5rem"}`)}${attr("title", store_get($$store_subs ??= {}, "$sidebarOpen", sidebarOpen) ? "折叠" : "展开")}><i${attr_class(`fas ${store_get($$store_subs ??= {}, "$sidebarOpen", sidebarOpen) ? "fa-chevron-left" : "fa-chevron-right"} text-xs`)}></i></button> <div${attr_class(`${store_get($$store_subs ??= {}, "$sidebarOpen", sidebarOpen) ? "w-64" : "w-0"} transition-all duration-300 overflow-hidden bg-white/60 backdrop-blur border-r border-earth-200 flex flex-col h-full`)}>`);
    if (store_get($$store_subs ??= {}, "$sidebarOpen", sidebarOpen)) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<nav class="p-3 pt-14 space-y-1"><button${attr_class(`w-full text-left px-3 py-2.5 rounded-xl hover:bg-forest-500/8 flex items-center gap-2 transition-colors ${isActive("/") ? "text-forest-600 bg-forest-500/10 font-medium" : "text-bark-600"}`)}><i class="fas fa-comments w-4 text-center"></i> 对话</button> <button${attr_class(`w-full text-left px-3 py-2.5 rounded-xl hover:bg-forest-500/8 flex items-center gap-2 transition-colors ${isActive("/personas") ? "text-forest-600 bg-forest-500/10 font-medium" : "text-bark-600"}`)}><i class="fas fa-theater-masks w-4 text-center"></i> 角色</button> <button${attr_class(`w-full text-left px-3 py-2.5 rounded-xl hover:bg-forest-500/8 flex items-center gap-2 transition-colors ${isActive("/skills") ? "text-forest-600 bg-forest-500/10 font-medium" : "text-bark-600"}`)}><i class="fas fa-puzzle-piece w-4 text-center"></i> Skills</button> <button${attr_class(`w-full text-left px-3 py-2.5 rounded-xl hover:bg-forest-500/8 flex items-center gap-2 transition-colors ${isActive("/tools") ? "text-forest-600 bg-forest-500/10 font-medium" : "text-bark-600"}`)}><i class="fas fa-toolbox w-4 text-center"></i> 工具</button> <button class="w-full text-left px-3 py-2.5 rounded-xl bg-forest-500/10 hover:bg-forest-500/20 text-forest-600 flex items-center gap-2 transition-colors font-medium mt-2"><i class="fas fa-plus w-4 text-center"></i> 新建对话</button></nav> <div class="flex-1 overflow-y-auto p-3"><h3 class="text-xs text-earth-500 uppercase tracking-wider mb-2 px-2">对话历史</h3> `);
      if (store_get($$store_subs ??= {}, "$conversations", conversations).length === 0) {
        $$renderer2.push("<!--[0-->");
        EmptyState($$renderer2, { icon: "fa-comments", message: "暂无对话" });
      } else {
        $$renderer2.push("<!--[-1-->");
        $$renderer2.push(`<!--[-->`);
        const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$conversations", conversations));
        for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
          let conv = each_array[$$index];
          $$renderer2.push(`<div${attr_class(`group flex items-center justify-between w-full px-3 py-2 rounded-lg hover:bg-forest-500/6 text-sm transition-colors ${conv.id === store_get($$store_subs ??= {}, "$currentConversationId", currentConversationId) ? "bg-forest-500/10 text-forest-700" : "text-bark-600"}`)}><button class="truncate flex-1 min-w-0 text-left">${escape_html(conv.title)} `);
          if (conv.message_count > 0) {
            $$renderer2.push("<!--[0-->");
            $$renderer2.push(`<span class="text-xs text-earth-400 ml-1">(${escape_html(conv.message_count)})</span>`);
          } else {
            $$renderer2.push("<!--[-1-->");
          }
          $$renderer2.push(`<!--]--></button> <button class="opacity-0 group-hover:opacity-100 text-earth-400 hover:text-red-400 transition-all ml-1 flex-shrink-0" aria-label="删除对话"><i class="fas fa-trash text-xs"></i></button></div>`);
        }
        $$renderer2.push(`<!--]-->`);
      }
      $$renderer2.push(`<!--]--></div> <div class="p-3 border-t border-earth-100"><button class="w-full text-left px-3 py-2 rounded-lg hover:bg-forest-500/8 flex items-center gap-2 text-earth-500 hover:text-bark-700 transition-colors text-sm"><i class="fas fa-cog w-4 text-center"></i> 设置</button></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--></div>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
function _layout($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { children } = $$props;
    const bgImages = [
      "/images/8fd9055949242e41b27a2bf29f0d71d2.jpeg",
      "/images/3058d0bc9d4999576d246e97ad73ef16.jpeg",
      "/images/603d456fa190b44c09b315482f223603.jpeg",
      "/images/71c5e8c05af37a6a7c8bdedc5fdd8e83.jpeg",
      "/images/c2ba5c02e57dd2a87a6efbee8483511c.jpeg",
      "/images/ac16593390903119d54d11c8a7824abe.jpeg",
      "/images/d419b907b5ca230dc3a309dc35d2cd8d.jpeg",
      "/images/2c0b4ac1d91309d9ab3860eb60ba2a62.jpeg"
    ];
    let currentIdx = 0;
    let nextIdx = 1;
    head("12qhfyh", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>个人助手</title>`);
      });
    });
    $$renderer2.push(`<div class="flex h-screen overflow-hidden relative"><div class="absolute inset-0 transition-opacity duration-1000 ease-in-out"${attr_style(`background: url(${stringify(bgImages[currentIdx])}) center/cover fixed; opacity: ${stringify(0.28)};`)}></div> <div class="absolute inset-0 transition-opacity duration-1000 ease-in-out"${attr_style(`background: url(${stringify(bgImages[nextIdx])}) center/cover fixed; opacity: ${stringify(0)};`)}></div> `);
    Sidebar($$renderer2);
    $$renderer2.push(`<!----> <main class="flex-1 flex flex-col overflow-hidden relative z-10">`);
    children($$renderer2);
    $$renderer2.push(`<!----></main></div>`);
  });
}
export {
  _layout as default
};
