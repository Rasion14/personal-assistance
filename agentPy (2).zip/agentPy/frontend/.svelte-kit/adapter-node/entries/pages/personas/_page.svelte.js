import { a as attr, e as escape_html } from "../../../chunks/attributes.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let genName = "";
    let genDesc = "";
    let genStyle = "professional";
    let generating = false;
    $$renderer2.push(`<div class="flex flex-col h-full p-6"><h1 class="text-2xl font-bold glow-text mb-6">🎭 角色管理</h1> `);
    {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-1 overflow-auto"><div class="glass p-6 space-y-4 h-fit"><h2 class="text-lg font-semibold text-bark-800">🤖 AI 生成角色</h2> <input type="text"${attr("value", genName)} placeholder="角色名称" class="w-full"/> `);
    $$renderer2.select({ value: genStyle, class: "w-full" }, ($$renderer3) => {
      $$renderer3.option({ value: "professional" }, ($$renderer4) => {
        $$renderer4.push(`专业`);
      });
      $$renderer3.option({ value: "casual" }, ($$renderer4) => {
        $$renderer4.push(`随意`);
      });
      $$renderer3.option({ value: "maid" }, ($$renderer4) => {
        $$renderer4.push(`女仆`);
      });
      $$renderer3.option({ value: "scholar" }, ($$renderer4) => {
        $$renderer4.push(`学者`);
      });
      $$renderer3.option({ value: "comedian" }, ($$renderer4) => {
        $$renderer4.push(`幽默`);
      });
    });
    $$renderer2.push(` <textarea rows="3" placeholder="描述你想要的AI角色风格..." class="w-full">`);
    const $$body_1 = escape_html(genDesc);
    if ($$body_1) {
      $$renderer2.push(`${$$body_1}`);
    }
    $$renderer2.push(`</textarea> <button${attr("disabled", generating, true)} class="btn-primary w-full">${escape_html("✨ AI 生成")}</button></div> <div class="glass p-6 space-y-3 h-fit"><h2 class="text-lg font-semibold text-bark-800">📋 已有角色</h2> `);
    {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<p class="text-earth-500 text-sm">加载中...</p>`);
    }
    $$renderer2.push(`<!--]--></div></div> `);
    {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
export {
  _page as default
};
