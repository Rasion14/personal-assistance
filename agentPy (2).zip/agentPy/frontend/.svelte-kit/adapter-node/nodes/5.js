

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/skills/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.CchU68KT.js","_app/immutable/chunks/B513rd-Q.js","_app/immutable/chunks/DUhX60Um.js","_app/immutable/chunks/CJjK2UUT.js","_app/immutable/chunks/e9QRveVr.js","_app/immutable/chunks/DH3oQPF8.js","_app/immutable/chunks/DJGWD7Om.js","_app/immutable/chunks/CgQFcIF8.js","_app/immutable/chunks/B1INVoQK.js"];
export const stylesheets = [];
export const fonts = [];
