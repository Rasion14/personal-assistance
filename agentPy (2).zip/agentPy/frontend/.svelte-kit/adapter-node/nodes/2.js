

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.Dd3BQkaZ.js","_app/immutable/chunks/B513rd-Q.js","_app/immutable/chunks/DUhX60Um.js","_app/immutable/chunks/e9QRveVr.js","_app/immutable/chunks/DH3oQPF8.js","_app/immutable/chunks/DJGWD7Om.js","_app/immutable/chunks/CgQFcIF8.js","_app/immutable/chunks/B1INVoQK.js","_app/immutable/chunks/CL0FrlvW.js","_app/immutable/chunks/Ba-5hIze.js","_app/immutable/chunks/Df_ssRQv.js","_app/immutable/chunks/BlenQs6_.js","_app/immutable/chunks/D94lijIc.js"];
export const stylesheets = [];
export const fonts = [];
