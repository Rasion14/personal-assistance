

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/personas/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/3.xF3a8NzM.js","_app/immutable/chunks/B513rd-Q.js","_app/immutable/chunks/DUhX60Um.js","_app/immutable/chunks/e9QRveVr.js","_app/immutable/chunks/DH3oQPF8.js","_app/immutable/chunks/DJGWD7Om.js","_app/immutable/chunks/CgQFcIF8.js","_app/immutable/chunks/D94lijIc.js","_app/immutable/chunks/B1INVoQK.js","_app/immutable/chunks/BlenQs6_.js"];
export const stylesheets = [];
export const fonts = [];
