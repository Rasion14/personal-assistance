

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.DHS7fATx.js","_app/immutable/chunks/B513rd-Q.js","_app/immutable/chunks/DUhX60Um.js","_app/immutable/chunks/Y3Tbqvbp.js"];
export const stylesheets = [];
export const fonts = [];
