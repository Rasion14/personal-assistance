

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/settings/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.DuzV9AXh.js","_app/immutable/chunks/B513rd-Q.js","_app/immutable/chunks/DUhX60Um.js","_app/immutable/chunks/CJjK2UUT.js","_app/immutable/chunks/e9QRveVr.js","_app/immutable/chunks/DJGWD7Om.js","_app/immutable/chunks/B1INVoQK.js","_app/immutable/chunks/BHxXGjYC.js"];
export const stylesheets = [];
export const fonts = [];
