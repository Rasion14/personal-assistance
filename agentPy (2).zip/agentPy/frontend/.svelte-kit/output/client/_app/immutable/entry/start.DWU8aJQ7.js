import{l as o,a as r}from"../chunks/Y3Tbqvbp.js";export{o as load_css,r as start};
