
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	type MatcherParam<M> = M extends (param : string) => param is (infer U extends string) ? U : string;

	export interface AppTypes {
		RouteId(): "/" | "/personas" | "/settings" | "/skills" | "/tools";
		RouteParams(): {
			
		};
		LayoutParams(): {
			"/": Record<string, never>;
			"/personas": Record<string, never>;
			"/settings": Record<string, never>;
			"/skills": Record<string, never>;
			"/tools": Record<string, never>
		};
		Pathname(): "/" | "/personas" | "/settings" | "/skills" | "/tools";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/images/2c0b4ac1d91309d9ab3860eb60ba2a62.jpeg" | "/images/3058d0bc9d4999576d246e97ad73ef16.jpeg" | "/images/603d456fa190b44c09b315482f223603.jpeg" | "/images/71c5e8c05af37a6a7c8bdedc5fdd8e83.jpeg" | "/images/8fd9055949242e41b27a2bf29f0d71d2.jpeg" | "/images/ac16593390903119d54d11c8a7824abe.jpeg" | "/images/c2ba5c02e57dd2a87a6efbee8483511c.jpeg" | "/images/d419b907b5ca230dc3a309dc35d2cd8d.jpeg" | string & {};
	}
}