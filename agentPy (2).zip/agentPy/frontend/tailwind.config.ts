import type { Config } from 'tailwindcss';

export default {
  content: ['./src/**/*.{html,js,svelte,ts}'],
  theme: {
    extend: {
      colors: {
        forest: {
          50: '#f4f9f3',
          100: '#e6f1e4',
          200: '#c8e0c4',
          300: '#9dc897',
          400: '#6bab64',
          500: '#4a9c5d',
          600: '#3d8a4f',
          700: '#2f6e3d',
          800: '#255832',
          900: '#1c4528',
        },
        earth: {
          50: '#fdfaf7',
          100: '#faf5ed',
          200: '#f0e6d3',
          300: '#e0ccad',
          400: '#c4a97d',
          500: '#b8935e',
          600: '#a37d4a',
          700: '#8b6f4e',
          800: '#6e5538',
          900: '#4a3728',
        },
        warm: {
          300: '#f4b87a',
          400: '#e8954a',
          500: '#d4873a',
          600: '#b86e2a',
        },
        bark: {
          500: '#6b5a4a',
          600: '#5c4a3a',
          700: '#4a3728',
          800: '#3d3227',
          900: '#2a1f14',
        },
        cream: {
          50: '#fefdfb',
          100: '#faf8f5',
          200: '#f5f0e8',
          300: '#ede5d8',
        },
      },
      fontFamily: {
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      borderRadius: {
        'xl': '1rem',
        '2xl': '1.25rem',
        '3xl': '1.5rem',
      },
    },
  },
  plugins: [],
} satisfies Config;
