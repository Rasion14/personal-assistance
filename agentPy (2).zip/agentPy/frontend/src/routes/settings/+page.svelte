<script lang="ts">
  import { onMount } from 'svelte';

  let apiKey = '';
  let saving = false;
  let saved = false;

  onMount(() => {
    apiKey = localStorage.getItem('api_key') || '';
  });

  async function saveSettings() {
    saving = true;
    saved = false;
    localStorage.setItem('api_key', apiKey);
    await new Promise(r => setTimeout(r, 500));
    saving = false;
    saved = true;
    setTimeout(() => { window.location.reload(); }, 800);
  }
</script>

<div class="flex flex-col h-full p-6 max-w-2xl">
  <h1 class="text-2xl font-bold glow-text mb-6">
    <i class="fas fa-cog mr-2"></i>
    设置
  </h1>

  <div class="space-y-6">
    <div class="glass p-6">
      <h2 class="text-lg font-semibold text-bark-800 mb-4">平台 API Key</h2>
      <p class="text-sm text-earth-700 mb-3">
        此 Key 需要与后端 <code class="text-forest-600 bg-forest-50 px-1.5 py-0.5 rounded">.env</code> 中的 <code class="text-forest-600 bg-forest-50 px-1.5 py-0.5 rounded">API_KEY</code> 一致。
      </p>
      <div class="space-y-3">
        <label class="block">
          <span class="text-sm text-earth-600">X-API-Key</span>
          <input type="password" bind:value={apiKey} class="w-full mt-1" placeholder="与后端 .env 中的 API_KEY 一致" />
        </label>
        <div class="flex items-center gap-3">
          <button onclick={saveSettings} disabled={saving} class="btn-primary">
            <i class="fas fa-save mr-2"></i>{saving ? '保存中...' : '保存'}
          </button>
          {#if saved}
            <span class="text-sm text-forest-600"><i class="fas fa-check mr-1"></i>已保存，即将刷新...</span>
          {/if}
        </div>
      </div>
    </div>

    <div class="glass p-6">
      <h2 class="text-lg font-semibold text-bark-800 mb-4">LLM Provider 配置</h2>
      <p class="text-sm text-earth-700">
        LLM API Key 在 <code class="text-forest-600 bg-forest-50 px-1.5 py-0.5 rounded">backend/.env</code> 中配置，无需在此设置。
      </p>
    </div>

    <div class="glass p-6">
      <h2 class="text-lg font-semibold text-bark-800 mb-4">关于</h2>
      <p class="text-earth-700 text-sm">
        Agent Platform v0.1.0 — 基于 Pydantic AI 构建的企业级智能助手平台 🌿
      </p>
    </div>
  </div>
</div>
