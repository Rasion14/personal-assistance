<script lang="ts">
  import { onMount } from 'svelte';
  import '../lib/styles/global.css';
  import Sidebar from '../lib/components/Sidebar.svelte';

  let { children } = $props();

  const bgImages = [
    '/images/8fd9055949242e41b27a2bf29f0d71d2.jpeg',
    '/images/3058d0bc9d4999576d246e97ad73ef16.jpeg',
    '/images/603d456fa190b44c09b315482f223603.jpeg',
    '/images/71c5e8c05af37a6a7c8bdedc5fdd8e83.jpeg',
    '/images/c2ba5c02e57dd2a87a6efbee8483511c.jpeg',
    '/images/ac16593390903119d54d11c8a7824abe.jpeg',
    '/images/d419b907b5ca230dc3a309dc35d2cd8d.jpeg',
    '/images/2c0b4ac1d91309d9ab3860eb60ba2a62.jpeg',
  ];

  let currentIdx = $state(0);
  let nextIdx = $state(1);
  let fading = $state(false);

  function rotateBg() {
    fading = true;
    setTimeout(() => {
      currentIdx = (currentIdx + 1) % bgImages.length;
      nextIdx = (currentIdx + 1) % bgImages.length;
      fading = false;
    }, 800);
  }

  onMount(() => {
    const interval = setInterval(rotateBg, 15000);
    return () => clearInterval(interval);
  });
</script>

<svelte:head>
  <title>个人助手</title>
</svelte:head>

<div class="flex h-screen overflow-hidden relative">
  <!-- 背景层 -->
  <div
    class="absolute inset-0 transition-opacity duration-1000 ease-in-out"
    style="background: url({bgImages[currentIdx]}) center/cover fixed; opacity: {fading ? 0 : 0.28};"
  ></div>
  <div
    class="absolute inset-0 transition-opacity duration-1000 ease-in-out"
    style="background: url({bgImages[nextIdx]}) center/cover fixed; opacity: {fading ? 0.28 : 0};"
  ></div>

  <Sidebar />
  <main class="flex-1 flex flex-col overflow-hidden relative z-10">
    {@render children()}
  </main>
</div>
