<script lang="ts">
  import { onMount } from 'svelte';

  let tools = $state<Array<any>>([]);
  let loading = $state(true);
  let editing = $state('');
  let editSource = $state('');
  let saving = $state(false);
  let message = $state('');
  let renaming = $state('');
  let newName = $state('');
  let newToolName = $state('');

  const API_BASE = 'http://localhost:8000';
  function key() { return localStorage.getItem('api_key') || ''; }

  onMount(() => loadTools());

  async function api(url: string, opts: RequestInit = {}) {
    const res = await fetch(`${API_BASE}${url}`, { ...opts, headers: { ...opts.headers, 'X-API-Key': key() } });
    return res.json();
  }

  async function loadTools() {
    loading = true;
    try { const data = await api('/api/tools/files'); tools = data.tools || []; }
    catch {} finally { loading = false; }
  }

  async function openEditor(name: string) {
    const data = await api(`/api/tools/${name}`);
    editing = name; editSource = data.source || '';
  }

  async function saveTool() {
    saving = true;
    const data = await api(`/api/tools/${editing}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ source: editSource }) });
    if (data.success) { message = `✅ ${editing} 已更新`; editing = ''; await loadTools(); }
    else { message = '失败: ' + (data.detail || ''); }
    saving = false;
  }

  async function doRename() {
    if (!newName.trim() || !renaming) return;
    const data = await api(`/api/tools/rename?old_name=${renaming}&new_name=${newName}`, { method: 'POST' });
    if (data.success) { message = `✅ 已重命名为 ${newName}`; renaming = ''; newName = ''; await loadTools(); }
    else { message = '失败: ' + (data.detail || ''); }
  }

  async function createTool() {
    if (!newToolName.trim()) return;
    const data = await api(`/api/tools/create?name=${newToolName}`, { method: 'POST' });
    if (data.success) { message = `✅ 工具 ${newToolName} 已创建`; newToolName = ''; await loadTools(); }
    else { message = '失败: ' + (data.detail || ''); }
  }

  async function deleteTool(name: string) {
    if (!confirm(`确定删除工具 ${name}？`)) return;
    const data = await api(`/api/tools/${name}`, { method: 'DELETE' });
    if (data.success) { message = `✅ ${name} 已删除`; await loadTools(); }
    else { message = '失败: ' + (data.detail || ''); }
  }
</script>

<div class="flex flex-col h-full p-6">
  <div class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold glow-text">🔧 工具管理</h1>
    <div class="flex items-center gap-2">
      <input type="text" bind:value={newToolName} placeholder="新工具名" class="text-sm py-1.5 w-32"
        onkeydown={(e) => e.key === 'Enter' && createTool()} />
      <button onclick={createTool} class="btn-primary text-sm">+ 新建</button>
    </div>
  </div>

  {#if editing}
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-sm" onclick={() => editing = ''}>
      <div class="glass p-6 w-full max-w-3xl max-h-[85vh] overflow-auto m-4" onclick={(e) => e.stopPropagation()}>
        <h2 class="text-lg font-semibold mb-3">✏️ 编辑: {editing}.py</h2>
        <textarea bind:value={editSource} rows="22" class="w-full font-mono text-sm"></textarea>
        <div class="flex gap-3 mt-3">
          <button onclick={saveTool} disabled={saving} class="btn-primary">{saving ? '保存中...' : '💾 保存并生效'}</button>
          <button onclick={() => editing = ''} class="px-4 py-2 rounded-lg border border-earth-200 text-earth-600">取消</button>
          {#if message}<span class="text-sm text-forest-600 self-center">{message}</span>{/if}
        </div>
      </div>
    </div>
  {/if}

  {#if message && !editing}
    <div class="text-sm text-forest-600 mb-3">{message}</div>
  {/if}

  {#if loading}
    <p class="text-earth-500">加载中...</p>
  {:else}
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 overflow-auto">
      {#each tools as tool}
        <div class="glass p-5 group">
          <div class="flex items-center justify-between mb-2">
            {#if renaming === tool.name}
              <div class="flex items-center gap-2">
                <input type="text" bind:value={newName} class="text-sm py-1 px-2 w-32" onkeydown={(e) => e.key === 'Enter' && doRename()} />
                <button onclick={doRename} class="text-xs text-forest-600 font-medium">确定</button>
                <button onclick={() => { renaming = ''; newName = ''; }} class="text-xs text-earth-500">取消</button>
              </div>
            {:else}
              <h3 class="font-semibold text-bark-700"><i class="fas fa-code text-forest-500 mr-2"></i>{tool.name}</h3>
              <div class="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onclick={() => { renaming = tool.name; newName = tool.name; }} class="text-xs text-earth-400 hover:text-forest-500 p-1" title="重命名"><i class="fas fa-pen"></i></button>
                <button onclick={() => openEditor(tool.name)} class="text-xs text-earth-400 hover:text-forest-500 p-1" title="编辑源码"><i class="fas fa-edit"></i></button>
                <button onclick={() => deleteTool(tool.name)} class="text-xs text-earth-400 hover:text-red-400 p-1" title="删除"><i class="fas fa-trash"></i></button>
              </div>
            {/if}
          </div>
          {#each tool.functions as fn}
            <div class="ml-2 mb-2 p-2 bg-white/40 rounded-lg">
              <span class="text-xs font-mono text-forest-600 font-medium">{fn.async ? 'async ' : ''}def {fn.name}()</span>
              {#if fn.doc}<p class="text-xs text-earth-600 mt-0.5">{fn.doc}</p>{/if}
            </div>
          {/each}
        </div>
      {/each}
    </div>
  {/if}
</div>
