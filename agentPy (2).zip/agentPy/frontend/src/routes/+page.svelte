<script lang="ts">
  import MessageBubble from '../lib/components/MessageBubble.svelte';
  import ModelSelector from '../lib/components/ModelSelector.svelte';
  import PersonaSelector from '../lib/components/PersonaSelector.svelte';
  import StatusIndicator from '../lib/components/StatusIndicator.svelte';
  import EmptyState from '../lib/components/EmptyState.svelte';
  import { messages, isStreaming, streamingContent, currentModelId, currentPersonaId, currentConversationId, addMessage, updateLastMessage, clearMessages, refreshConversations } from '../lib/stores/chat.store';
  import { streamMessage, createConversation } from '../lib/api/client';
  import { get } from 'svelte/store';
  import { tick } from 'svelte';

  import { listSkills, enableSkill, disableSkill, listTools } from '../lib/api/client';

  let input = $state('');
  let isSending = $state(false);
  let msgContainer: HTMLDivElement;
  let userScrolledUp = $state(false);
  let showTools = $state(false);
  let showSkills = $state(false);
  let crossSession = $state(false);  // 跨会话记忆开关
  let availableTools = $state<Array<{name: string; enabled: boolean}>>([]);
  let availableSkills = $state<Array<{name: string; enabled: boolean; status: string}>>([]);

  // 打开工具面板时加载，但保留已修改的勾选状态
  async function loadToolsConfig() {
    try {
      const data = await listTools();
      const prevState = new Map(availableTools.map(t => [t.name, t.enabled]));
      availableTools = (data.tools || []).map((t: any) => ({
        name: t.name,
        enabled: prevState.has(t.name) ? prevState.get(t.name)! : true,  // 保留旧的勾选状态
      }));
    } catch {}
  }
  async function loadSkillsConfig() {
    try {
      const data = await listSkills();
      const prevState = new Map(availableSkills.map(s => [s.name, s.enabled]));
      availableSkills = (data.skills || []).map((s: any) => ({
        name: s.name,
        enabled: prevState.has(s.name) ? prevState.get(s.name)! : (s.status === 'enabled'),
        status: s.status || 'disabled',
      }));
    } catch {}
  }
  async function applySkillChanges() {
    for (const s of availableSkills) {
      try {
        if (s.enabled && s.status !== 'enabled') { await enableSkill(s.name); s.status = 'enabled'; }
        else if (!s.enabled && s.status === 'enabled') { await disableSkill(s.name); s.status = 'disabled'; }
      } catch {}
    }
    showSkills = false;
    // 变更后实时刷新 skill 列表
    await loadSkillsConfig();
  }

  // 自动滚到底部 (用户未手动上滚时)
  function scrollToBottom(force = false) {
    if (!msgContainer) return;
    if (!force && userScrolledUp) return;
    requestAnimationFrame(() => {
      msgContainer.scrollTop = msgContainer.scrollHeight;
    });
  }

  function onScroll() {
    if (!msgContainer) return;
    const threshold = 80;
    const atBottom = msgContainer.scrollHeight - msgContainer.scrollTop - msgContainer.clientHeight < threshold;
    userScrolledUp = !atBottom;
  }

  // 流式输出时持续滚到底部
  $effect(() => {
    if ($streamingContent) { scrollToBottom(); }
  });

  // 新消息时滚到底部
  $effect(() => {
    if ($messages.length > 0) { scrollToBottom(true); }
  });

  async function ensureConversation() {
    if (!get(currentConversationId)) {
      try {
        const data = await createConversation('新对话');
        const newId = data.id || data.conversation_id || '';
        currentConversationId.set(newId);
        localStorage.setItem('current_conv_id', newId);
      } catch {
        currentConversationId.set('temp-' + crypto.randomUUID());
      }
    }
  }

  async function handleSend() {
    if (!input.trim() || isSending) return;
    const modelId = get(currentModelId);
    if (!modelId) { alert('模型加载中，请稍候再试'); return; }
    const userMsg = input.trim();
    input = '';
    isSending = true;
    userScrolledUp = false;  // 发送时强制跟随

    await ensureConversation();
    refreshConversations();

    // 收集当前勾选的工具和 skill
    // 注意: 若面板从未打开 (availableTools 为空), 传 null 使用默认全部工具
    const checkedTools = availableTools.length > 0
      ? availableTools.filter(t => t.enabled).map(t => t.name)
      : undefined;
    const checkedSkills = availableSkills.length > 0
      ? availableSkills.filter(s => s.enabled).map(s => s.name)
      : undefined;

    // 使用 get() 读取 store 值，确保 Svelte 5 runes 模式下正确
    const personaId = get(currentPersonaId);
    const convId = get(currentConversationId);

    addMessage('user', userMsg, [], personaId);
    isStreaming.set(true);
    streamingContent.set('');
    scrollToBottom(true);

    try {
      addMessage('assistant', '', [], personaId);
      // 把当前会话中已有的消息作为历史传给后端
      const history = get(messages).slice(0, -1).map(m => ({ role: m.role, content: m.content }));
      let streamAccum = '';
      for await (const payload of streamMessage(
        userMsg, convId, modelId, personaId, history,
        checkedTools, checkedSkills, crossSession,
      )) {
        if (payload.content !== undefined && payload.type === 'text') {
          streamAccum += payload.content;
          streamingContent.set(streamAccum);
          updateLastMessage(streamAccum);
        } else if (payload.code && payload.error) {
          updateLastMessage(streamAccum + '\n\n⚠️ 错误: ' + payload.error);
        }
      }
    } catch (e: any) {
      updateLastMessage(get(streamingContent) + '\n\n❌ 请求失败: ' + e.message);
    } finally {
      isStreaming.set(false);
      streamingContent.set('');
      isSending = false;
      // 延迟刷新以获取后端生成的标题
      refreshConversations();
    }
  }
</script>

<div class="flex flex-col h-full">
  <div class="flex items-center justify-center px-6 py-2.5 glass border-0 rounded-none border-b border-earth-200 relative">
    <h1 class="text-lg font-bold glow-text font-serif tracking-wide">🌿 个人助手</h1>
    <div class="absolute right-6">
      <StatusIndicator />
    </div>
  </div>

  <!-- svelte-ignore a11y_no_static_element_interactions -->
  <div
    bind:this={msgContainer}
    onscroll={onScroll}
    class="flex-1 overflow-y-auto px-6 py-4 space-y-4"
  >
    {#if $messages.length === 0}
      <div class="flex items-center justify-center h-full">
        <EmptyState icon="fa-leaf" message="开始对话吧" submessage="在下方输入消息，与 Agent 一起探索 🌱" />
      </div>
    {:else}
      {#each $messages as msg, i (msg.id)}
        <MessageBubble {msg} streaming={$isStreaming} index={i} />
      {/each}
    {/if}
  </div>

  <div class="px-4 py-3 border-t border-earth-200 glass border-0 rounded-none">
    <div class="max-w-3xl mx-auto">
      <div class="flex gap-2 items-end bg-white/60 rounded-2xl p-2 border border-earth-200 focus-within:border-forest-400 focus-within:ring-2 focus-within:ring-forest-500/10 transition-all">
        <textarea bind:value={input}
          onkeydown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSend())}
          placeholder="输入消息... (Enter 发送)"
          class="flex-1 resize-none border-0 bg-transparent focus:ring-0 focus:border-0 focus:shadow-none p-2" rows="1"
        ></textarea>
        <button onclick={handleSend} disabled={isSending}
          class="flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center transition-all
                 {isSending ? 'bg-earth-300 text-white cursor-not-allowed' : 'bg-forest-500 text-white hover:bg-forest-600 hover:shadow-lg'}"
          aria-label="发送消息">
          <i class="fas fa-paper-plane text-sm"></i>
        </button>
      </div>
      <div class="flex items-center justify-between gap-2 mt-2 text-xs">
        <div class="flex items-center gap-2">
          <PersonaSelector />
          <ModelSelector />
          <button onclick={() => crossSession = !crossSession}
            class="text-xs transition-colors px-2 py-1 rounded-lg border {crossSession ? 'border-forest-400 text-forest-600 bg-forest-500/10' : 'border-earth-200 text-earth-500'}"
            title={crossSession ? '跨会话记忆已开启' : '跨会话记忆已关闭'}>
            🧠 {crossSession ? '跨会话' : '本会话'}
          </button>
        </div>
        <button onclick={() => { showTools = !showTools; if (showTools) loadToolsConfig(); }}
          class="text-xs text-earth-500 hover:text-forest-500 transition-colors px-2 py-1 rounded-lg border border-earth-200 hover:border-forest-400" title="工具配置">
          🔧 工具
        </button>
        <button onclick={() => { showSkills = !showSkills; if (showSkills) loadSkillsConfig(); }}
          class="text-xs text-earth-500 hover:text-forest-500 transition-colors px-2 py-1 rounded-lg border border-earth-200 hover:border-forest-400" title="Skill配置">
          🧩 Skills
        </button>
      </div>

      {#if showTools}
        <div class="mt-2 p-3 glass rounded-xl text-xs max-h-40 overflow-y-auto">
          <h4 class="font-medium text-bark-700 mb-1.5">🔧 可用工具</h4>
          {#each availableTools as t}
            <label class="flex items-center gap-2 py-0.5 cursor-pointer">
              <input type="checkbox" bind:checked={t.enabled} class="w-4 h-4 accent-forest-500" />
              <span class="text-earth-700">{t.name}</span>
            </label>
          {/each}
          {#if availableTools.length === 0}<p class="text-earth-400">暂无</p>{/if}
          <button onclick={() => showTools = false} class="btn-primary text-xs mt-2 w-full">✅ 确定</button>
        </div>
      {/if}
      {#if showSkills}
        <div class="mt-2 p-3 glass rounded-xl text-xs max-h-40 overflow-y-auto">
          <h4 class="font-medium text-bark-700 mb-1.5">🧩 可用Skills</h4>
          {#each availableSkills as s}
            <label class="flex items-center gap-2 py-0.5 cursor-pointer">
              <input type="checkbox" bind:checked={s.enabled} class="w-4 h-4 accent-forest-500" />
              <span class="text-earth-700">{s.name}</span>
            </label>
          {/each}
          {#if availableSkills.length === 0}<p class="text-earth-400">暂无</p>{/if}
          <button onclick={applySkillChanges} class="btn-primary text-xs mt-2 w-full">✅ 确认</button>
        </div>
      {/if}
    </div>
  </div>
</div>
