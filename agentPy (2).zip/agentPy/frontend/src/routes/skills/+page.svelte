<script lang="ts">
  import SkillMarket from '../../lib/components/SkillMarket.svelte';
</script>

<div class="flex flex-col h-full p-6">
  <h1 class="text-2xl font-bold glow-text mb-6">
    <i class="fas fa-puzzle-piece mr-2"></i>
    Skill 市场
  </h1>
  <SkillMarket />
</div>
