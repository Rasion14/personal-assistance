<script lang="ts">
  import { listPersonas } from '../../lib/api/client';
  import { onMount } from 'svelte';

  let personas = $state<Array<any>>([]);
  let loading = $state(true);
  let genName = $state(''); let genDesc = $state(''); let genStyle = $state('professional');
  let generating = $state(false); let generatedYaml = $state('');
  let creating = $state(false); let message = $state('');

  // 编辑模式
  let editingId = $state(''); let editingYaml = $state('');
  let saving = $state(false);

  const API_BASE = 'http://localhost:8000';
  function key() { return localStorage.getItem('api_key') || ''; }

  onMount(() => loadPersonas());

  async function loadPersonas() {
    loading = true;
    try { const data = await listPersonas(); personas = data.personas || []; }
    catch { personas = []; } finally { loading = false; }
  }

  async function handleGenerate() {
    if (!genDesc.trim()) { message = '请输入角色描述'; return; }
    generating = true; message = '';
    try {
      const res = await fetch(`${API_BASE}/api/personas/generate`, {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'X-API-Key': key() },
        body: JSON.stringify({ name: genName, description: genDesc, style: genStyle }),
      });
      const data = await res.json();
      if (data.success) { generatedYaml = data.yaml; message = '生成成功！'; }
      else { message = '生成失败: ' + (data.detail || ''); }
    } catch (e: any) { message = '请求失败: ' + e.message; }
    finally { generating = false; }
  }

  async function handleCreate() {
    if (!generatedYaml.trim()) return;
    creating = true;
    try {
      const match = generatedYaml.match(/^id:\s*(\S+)/m);
      const pid = match ? match[1] : 'custom';
      const res = await fetch(`${API_BASE}/api/personas/create`, {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'X-API-Key': key() },
        body: JSON.stringify({ id: pid, yaml_content: generatedYaml }),
      });
      const data = await res.json();
      if (data.success) { message = `✅ 角色 ${data.id} 已创建`; generatedYaml = ''; genName = ''; genDesc = ''; await loadPersonas(); }
      else { message = '失败: ' + (data.detail || ''); }
    } catch (e: any) { message = '失败: ' + e.message; }
    finally { creating = false; }
  }

  async function handleEdit(personaId: string) {
    try {
      const res = await fetch(`${API_BASE}/api/personas/${personaId}`, { headers: { 'X-API-Key': key() } });
      const data = await res.json();
      editingId = personaId;
      editingYaml = data.yaml;
    } catch (e: any) { message = '加载失败: ' + e.message; }
  }

  async function handleSaveEdit() {
    saving = true;
    try {
      const res = await fetch(`${API_BASE}/api/personas/${editingId}`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json', 'X-API-Key': key() },
        body: JSON.stringify({ id: editingId, yaml_content: editingYaml }),
      });
      const data = await res.json();
      if (data.success) { message = `✅ ${editingId} 已更新`; editingId = ''; await loadPersonas(); }
      else { message = '失败: ' + (data.detail || ''); }
    } catch (e: any) { message = '失败: ' + e.message; }
    finally { saving = false; }
  }

  async function handleDelete(id: string) {
    if (!confirm('确定删除 ' + id + '？')) return;
    try {
      await fetch(`${API_BASE}/api/personas/${id}`, { method: 'DELETE', headers: { 'X-API-Key': key() } });
      await loadPersonas();
    } catch {}
  }
</script>

<div class="flex flex-col h-full p-6">
  <h1 class="text-2xl font-bold glow-text mb-6">🎭 角色管理</h1>

  <!-- 编辑弹窗 -->
  {#if editingId}
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-sm" onclick={() => editingId = ''}>
      <div class="glass p-6 w-full max-w-2xl max-h-[80vh] overflow-auto m-4" onclick={(e) => e.stopPropagation()}>
        <h2 class="text-lg font-semibold mb-3">✏️ 编辑: {editingId}</h2>
        <textarea bind:value={editingYaml} rows="20" class="w-full font-mono text-sm"></textarea>
        <div class="flex gap-3 mt-3">
          <button onclick={handleSaveEdit} disabled={saving} class="btn-primary">{saving ? '保存中...' : '💾 保存'}</button>
          <button onclick={() => editingId = ''} class="px-4 py-2 rounded-lg border border-earth-200 text-earth-600">取消</button>
          {#if message}<span class="text-sm text-forest-600 self-center">{message}</span>{/if}
        </div>
      </div>
    </div>
  {/if}

  <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-1 overflow-auto">
    <!-- AI 生成 -->
    <div class="glass p-6 space-y-4 h-fit">
      <h2 class="text-lg font-semibold text-bark-800">🤖 AI 生成角色</h2>
      <input type="text" bind:value={genName} placeholder="角色名称" class="w-full" />
      <select bind:value={genStyle} class="w-full">
        <option value="professional">专业</option><option value="casual">随意</option>
        <option value="maid">女仆</option><option value="scholar">学者</option>
        <option value="comedian">幽默</option>
      </select>
      <textarea bind:value={genDesc} rows="3" placeholder="描述你想要的AI角色风格..." class="w-full"></textarea>
      <button onclick={handleGenerate} disabled={generating} class="btn-primary w-full">
        {generating ? '⏳ 生成中...' : '✨ AI 生成'}
      </button>
    </div>

    <!-- 已有角色 -->
    <div class="glass p-6 space-y-3 h-fit">
      <h2 class="text-lg font-semibold text-bark-800">📋 已有角色</h2>
      {#if loading}
        <p class="text-earth-500 text-sm">加载中...</p>
      {:else}
        {#each personas as p}
          <div class="flex items-center justify-between p-3 bg-white/40 rounded-xl cursor-pointer hover:bg-white/70 transition-colors"
               onclick={() => handleEdit(p.id)} title="点击编辑">
            <div class="flex items-center gap-3">
              <span class="w-8 h-8 rounded-full flex items-center justify-center text-sm"
                    style="background:{p.color}18; color:{p.color}">
                <i class="fas {p.icon}"></i>
              </span>
              <div>
                <div class="font-medium text-sm text-bark-700">{p.display_name}</div>
                <div class="text-xs text-earth-500">{p.tagline}</div>
              </div>
            </div>
            {#if p.id !== 'default'}
              <button onclick={(e) => { e.stopPropagation(); handleDelete(p.id); }}
                class="text-xs text-red-400 hover:text-red-600 px-2 py-1">
                <i class="fas fa-trash"></i>
              </button>
            {/if}
          </div>
        {/each}
      {/if}
    </div>
  </div>

  <!-- 生成结果 -->
  {#if generatedYaml}
    <div class="glass p-6 mt-4 space-y-3">
      <h2 class="text-lg font-semibold">✏️ 编辑并保存</h2>
      <textarea bind:value={generatedYaml} rows="14" class="w-full font-mono text-sm"></textarea>
      <div class="flex items-center gap-3">
        <button onclick={handleCreate} disabled={creating} class="btn-primary">{creating ? '保存中...' : '💾 保存角色'}</button>
        {#if message}<span class="text-sm text-forest-600">{message}</span>{/if}
      </div>
    </div>
  {/if}
</div>
