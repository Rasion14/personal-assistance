// UI 状态管理

import { writable } from 'svelte/store';

export const sidebarOpen = writable(true);
export const activeView = writable('chat');

export function setView(view) {
  activeView.set(view);
}
