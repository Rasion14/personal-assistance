// 聊天状态管理

import { writable, get } from 'svelte/store';
import { listConversations, deleteMessage } from '../api/client';

// 始终从全新 session 开始 (不自动恢复旧会话)
export const messages = writable<Message[]>([]);
export const currentConversationId = writable('');
export const isStreaming = writable(false);
export const currentModelId = writable('');  // 启动时从 API 加载默认模型
export const currentPersonaId = writable('default');
export const streamingContent = writable('');
export const conversations = writable<Conversation[]>([]);

export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system' | 'tool';
  content: string;
  timestamp: string;
  toolCalls?: ToolCall[];
  personaId?: string;
  metadata?: Record<string, unknown>;
}

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
  result?: string;
  status: 'loading' | 'done' | 'error';
}

export interface Conversation {
  id: string;
  title: string;
  modelId: string;
  messages: Message[];
  createdAt: string;
  updatedAt: string;
}

export function clearMessages() {
  messages.set([]);
  streamingContent.set('');
}

export function addMessage(role: string, content: string, toolCalls: ToolCall[] = [], personaId: string = 'default') {
  const msg: Message = {
    id: crypto.randomUUID(),
    role: role as Message['role'],
    content,
    timestamp: new Date().toISOString(),
    toolCalls,
    personaId,
  };
  messages.update(ms => [...ms, msg]);
}

export function updateLastMessage(content: string) {
  messages.update(ms => {
    if (ms.length === 0) return ms;
    const updated = [...ms];
    updated[updated.length - 1] = { ...updated[updated.length - 1], content };
    return updated;
  });
}

// 删除配对消息 + 同步后端 (异步: 先调 API, 成功后再更新本地状态)
export async function removeMessagePair(clickedIndex: number): Promise<void> {
  const convId = get(currentConversationId);
  if (!convId) return;

  const ms = get(messages);
  if (clickedIndex < 0 || clickedIndex >= ms.length) return;

  // 找到要删除的 user 消息索引:
  // - 如果点击的是 user 消息 → 该索引就是 user 消息
  // - 如果点击的是 assistant 消息 → 找到它前面最近的 user 消息
  let userIdx: number;
  if (ms[clickedIndex].role === 'user') {
    userIdx = clickedIndex;
  } else {
    userIdx = -1;
    for (let i = clickedIndex - 1; i >= 0; i--) {
      if (ms[i].role === 'user') { userIdx = i; break; }
    }
    if (userIdx < 0) return;
  }

  // 先调后端删除, 成功后再更新本地状态
  try {
    await deleteMessage(convId, userIdx);
  } catch (e) {
    console.error('删除消息失败:', e);
    return; // API 失败 → 不更新本地状态
  }

  // 后端删除成功 → 更新本地 store
  messages.update(ms => {
    if (userIdx < 0 || userIdx >= ms.length) return ms;
    const nextIdx = userIdx + 1;
    const hasPairedAssistant = nextIdx < ms.length && ms[nextIdx].role === 'assistant';
    if (hasPairedAssistant) {
      return [...ms.slice(0, userIdx), ...ms.slice(nextIdx + 1)];
    }
    return [...ms.slice(0, userIdx), ...ms.slice(userIdx + 1)];
  });
}

export async function loadConversations(): Promise<void> {
  try {
    const data = await listConversations();
    conversations.set(data.conversations || []);
  } catch {
    // 静默处理加载失败
  }
}

// 供外部触发刷新的信号 (延迟加载，确保后端已保存)
export function refreshConversations(): void {
  setTimeout(() => loadConversations(), 1500);  // 等标题生成完成后刷新
}
