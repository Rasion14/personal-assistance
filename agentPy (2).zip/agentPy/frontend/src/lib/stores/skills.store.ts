// Skill 状态管理

import { writable } from 'svelte/store';

export const skills = writable([]);
export const selectedSkills = writable([]);

export function addSkill(skill) {
  skills.update(s => [...s, skill]);
}

export function removeSkill(name) {
  skills.update(s => s.filter(sk => sk.name !== name));
}
