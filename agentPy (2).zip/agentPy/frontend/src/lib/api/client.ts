// API 客户端 — 封装后端 API 调用
// 自动处理 snake_case / camelCase 转换和 X-API-Key 认证

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000';

// 从 localStorage 读取 API Key（设置页面保存）
function getApiKey(): string {
  if (typeof localStorage !== 'undefined') {
    return localStorage.getItem('api_key') || '';
  }
  return '';
}

// 通用请求函数 — 自动附加 X-API-Key、处理错误
async function request(path: string, options: RequestInit = {}): Promise<any> {
  const apiKey = getApiKey();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (apiKey) {
    headers['X-API-Key'] = apiKey;
  }

  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: { ...headers, ...((options.headers as Record<string, string>) || {}) },
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(error.detail || error.error?.message || `API error: ${res.status}`);
  }

  return res.json();
}

// ==================== 对话 ====================

export async function sendMessage(
  msg: string, convId: string = '', modelId?: string, personaId?: string,
  enabledTools?: string[], enabledSkills?: string[],
): Promise<any> {
  return request(`/api/chat`, {
    method: 'POST',
    body: JSON.stringify({
      message: msg, conversation_id: convId, model_id: modelId, persona_id: personaId,
      enabled_tools: enabledTools ?? null, enabled_skills: enabledSkills ?? null,
    }),
  });
}

export async function* streamMessage(
  msg: string, convId: string = '', modelId?: string, personaId?: string,
  history?: Array<{role: string; content: string}>,
  enabledTools?: string[], enabledSkills?: string[], crossSession?: boolean,
): AsyncGenerator<any> {
  const apiKey = getApiKey();
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (apiKey) headers['X-API-Key'] = apiKey;

  const res = await fetch(`${API_BASE}/api/chat/stream`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      message: msg, conversation_id: convId, model_id: modelId, persona_id: personaId,
      message_history: history,
      enabled_tools: enabledTools ?? null, enabled_skills: enabledSkills ?? null,
      enable_cross_session: crossSession ?? false,
    }),
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(error.detail || `API error: ${res.status}`);
  }
  if (!res.body) throw new Error('No response body');

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      if (line.startsWith('data: ')) {
        try {
          const payload = JSON.parse(line.slice(6));
          yield payload;
        } catch {}
      }
    }
  }
}

// ==================== 模型管理 ====================

export async function listModels(): Promise<any> {
  return request(`/api/models`);
}

export async function switchModel(modelId: string): Promise<any> {
  return request(`/api/models/switch`, {
    method: 'POST',
    body: JSON.stringify({ model_id: modelId }),
  });
}

// ==================== Persona 管理 ====================

export async function listPersonas(): Promise<any> {
  return request(`/api/personas`);
}

export async function switchPersona(personaId: string, convId?: string): Promise<any> {
  return request(`/api/personas/switch`, {
    method: 'POST',
    body: JSON.stringify({ persona_id: personaId, conversation_id: convId || '' }),
  });
}

// ==================== Skill 管理 ====================

export async function listSkills(): Promise<any> {
  return request(`/api/skills`);
}

export async function installSkill(url: string, name?: string): Promise<any> {
  return request(`/api/skills/install`, {
    method: 'POST',
    body: JSON.stringify({ source_url: url, name: name || null }),
  });
}

export async function uninstallSkill(name: string): Promise<any> {
  return request(`/api/skills/uninstall`, {
    method: 'POST',
    body: JSON.stringify({ name }),
  });
}

export async function enableSkill(name: string): Promise<any> {
  return request(`/api/skills/${encodeURIComponent(name)}/enable`, { method: 'POST' });
}

export async function disableSkill(name: string): Promise<any> {
  return request(`/api/skills/${encodeURIComponent(name)}/disable`, { method: 'POST' });
}

// ==================== Tool 管理 ====================

export async function listTools(): Promise<any> {
  return request(`/api/tools`);
}

// ==================== 对话管理 ====================

export async function listConversations(): Promise<any> {
  return request(`/api/conversations`);
}

export async function createConversation(title: string = '新对话', modelId?: string): Promise<any> {
  return request(`/api/conversations`, {
    method: 'POST',
    body: JSON.stringify({ title, model_id: modelId }),
  });
}

export async function getConversation(id: string): Promise<any> {
  return request(`/api/conversations/${encodeURIComponent(id)}`);
}

export async function deleteConversation(id: string): Promise<any> {
  return request(`/api/conversations/${encodeURIComponent(id)}`, { method: 'DELETE' });
}

export async function deleteMessage(convId: string, messageIndex: number): Promise<any> {
  return request(`/api/conversations/${encodeURIComponent(convId)}/messages/${messageIndex}`, { method: 'DELETE' });
}

// ==================== 健康检查 ====================

export async function healthCheck(): Promise<any> {
  return request(`/api/health`);
}
