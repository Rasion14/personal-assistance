// API 类型定义

export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system' | 'tool';
  content: string;
  timestamp: string;
  toolCalls?: ToolCall[];
  metadata?: Record<string, unknown>;
}

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
  result?: string;
  status: 'loading' | 'done' | 'error';
}

export interface Conversation {
  id: string;
  title: string;
  modelId: string;
  messages: Message[];
  createdAt: string;
  updatedAt: string;
}

export interface ModelEntry {
  id: string;
  provider: string;
  displayName: string;
  description: string;
  isDefault: boolean;
}

export interface SkillInfo {
  name: string;
  version: string;
  description: string;
  category: string;
  status: 'installed' | 'enabled' | 'disabled' | 'error';
  sourceUrl?: string;
  installPath?: string;
  instructions?: string;
  tools?: string[];
}

export interface ChatRequest {
  message: string;
  conversationId?: string;
  modelId?: string;
  enableThinking?: boolean;
}

export interface ChatResponse {
  content: string;
  conversationId?: string;
  modelId?: string;
  personaId?: string;
  usage?: Record<string, unknown>;
  elapsed?: number;
}

export interface PersonaInfo {
  id: string;
  name: string;
  display_name: string;
  icon: string;
  color: string;
  role: string;
  tagline: string;
}

export interface ChatRequest {
  message: string;
  conversationId?: string;
  modelId?: string;
  personaId?: string;
  enableThinking?: boolean;
}
