<script lang="ts">
  import { currentModelId } from '../stores/chat.store';
  import { listModels, switchModel } from '../api/client';
  import { onMount } from 'svelte';

  let models = $state<Array<{ id: string; display_name?: string; displayName?: string; is_default?: boolean }>>([]);
  let loading = $state(true);
  let error = $state('');

  onMount(() => loadModels());

  async function loadModels() {
    loading = true;
    error = '';
    try {
      const data = await listModels();
      models = data.models || [];
      // 自动选择默认模型 (is_default=true 或第一个)
      if (!$currentModelId && models.length > 0) {
        const def = models.find((m: any) => m.is_default) || models[0];
        $currentModelId = def.id;
      }
    } catch {
      error = '加载失败';
    } finally {
      loading = false;
    }
  }

  async function handleSwitch(modelId: string) {
    try {
      await switchModel(modelId);
      $currentModelId = modelId;
    } catch {}
  }
</script>

<div class="relative">
  <select
    value={$currentModelId}
    onchange={(e) => handleSwitch((e.target as HTMLSelectElement).value)}
    disabled={loading || !!error}
    class="bg-white/60 border border-earth-200 text-bark-600 text-xs rounded-lg px-2 py-1.5
           focus:ring-1 focus:ring-forest-500/20 outline-none cursor-pointer
           max-w-[160px] truncate disabled:opacity-50"
    aria-label="选择模型"
  >
    {#if loading}
      <option>加载中...</option>
    {:else if error}
      <option>{error}</option>
    {:else if models.length === 0}
      <option value={$currentModelId}>{$currentModelId}</option>
    {:else}
      {#each models as model}
        {@const name = model.display_name || model.displayName || model.id.split(':').pop() || model.id}
        <option value={model.id}>{name}</option>
      {/each}
    {/if}
  </select>
</div>
