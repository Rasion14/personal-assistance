<script lang="ts">
  import { sidebarOpen } from '../stores/ui.store';
  import { conversations, loadConversations, currentConversationId, currentPersonaId, clearMessages, messages } from '../stores/chat.store';
  import { onMount } from 'svelte';
  import { goto } from '$app/navigation';
  import { page } from '$app/stores';
  import EmptyState from './EmptyState.svelte';
  import { createConversation, deleteConversation, getConversation } from '../api/client';

  onMount(() => loadConversations());

  function toggleSidebar() { $sidebarOpen = !$sidebarOpen; }
  function isActive(path: string): boolean { return $page.url.pathname === path; }
  function navTo(path: string) { goto(path); }

  async function newSession() {
    try {
      const data = await createConversation('新对话');
      const id = data.id || data.conversation_id || '';
      $currentConversationId = id;
      $currentPersonaId = 'default';
      localStorage.setItem('current_conv_id', id);
      clearMessages();
      await loadConversations();
      navTo('/');
    } catch {}
  }

  let _loadingConvId = '';

  async function loadConversation(id: string) {
    if (_loadingConvId === id) return;  // 防止重复加载
    _loadingConvId = id;
    $currentConversationId = id;
    localStorage.setItem('current_conv_id', id);
    try {
      const data = await getConversation(id);
      if (data && data.messages) {
        // 恢复会话的人设
        const convPersona = (data.metadata && data.metadata.persona_id) || 'default';
        $currentPersonaId = convPersona;

        messages.set(data.messages.map((m: any) => ({
          id: m.id, role: m.role, content: m.content,
          timestamp: m.timestamp, toolCalls: m.tool_calls || [],
          personaId: (m.metadata && m.metadata.persona_id) || convPersona,
        })));
      }
    } catch {} finally {
      _loadingConvId = '';
    }
    navTo('/');
  }

  async function delConv(id: string, e: Event) {
    e.stopPropagation();
    if (!confirm('删除此对话？')) return;
    try {
      await deleteConversation(id);
      if ($currentConversationId === id) {
        $currentConversationId = '';
        localStorage.removeItem('current_conv_id');
        clearMessages();
      }
      await loadConversations();
    } catch {}
  }
</script>

<button
  onclick={toggleSidebar}
  class="fixed top-3 z-50 p-1.5 rounded-lg bg-white/40 hover:bg-white/70 text-earth-400 hover:text-forest-500 transition-all duration-300"
  style="left: {$sidebarOpen ? '16rem' : '0.5rem'}"
  title={$sidebarOpen ? '折叠' : '展开'}
>
  <i class="fas {($sidebarOpen as boolean) ? 'fa-chevron-left' : 'fa-chevron-right'} text-xs"></i>
</button>

<div class="{($sidebarOpen as boolean) ? 'w-64' : 'w-0'} transition-all duration-300 overflow-hidden bg-white/60 backdrop-blur border-r border-earth-200 flex flex-col h-full"
>
  {#if $sidebarOpen}
    <nav class="p-3 pt-14 space-y-1">
      <button onclick={() => navTo('/')}
        class="w-full text-left px-3 py-2.5 rounded-xl hover:bg-forest-500/8 flex items-center gap-2 transition-colors
               {isActive('/') ? 'text-forest-600 bg-forest-500/10 font-medium' : 'text-bark-600'}">
        <i class="fas fa-comments w-4 text-center"></i> 对话
      </button>
      <button onclick={() => navTo('/personas')}
        class="w-full text-left px-3 py-2.5 rounded-xl hover:bg-forest-500/8 flex items-center gap-2 transition-colors
               {isActive('/personas') ? 'text-forest-600 bg-forest-500/10 font-medium' : 'text-bark-600'}">
        <i class="fas fa-theater-masks w-4 text-center"></i> 角色
      </button>
      <button onclick={() => navTo('/skills')}
        class="w-full text-left px-3 py-2.5 rounded-xl hover:bg-forest-500/8 flex items-center gap-2 transition-colors
               {isActive('/skills') ? 'text-forest-600 bg-forest-500/10 font-medium' : 'text-bark-600'}">
        <i class="fas fa-puzzle-piece w-4 text-center"></i> Skills
      </button>
      <button onclick={() => navTo('/tools')}
        class="w-full text-left px-3 py-2.5 rounded-xl hover:bg-forest-500/8 flex items-center gap-2 transition-colors
               {isActive('/tools') ? 'text-forest-600 bg-forest-500/10 font-medium' : 'text-bark-600'}">
        <i class="fas fa-toolbox w-4 text-center"></i> 工具
      </button>
      <button onclick={newSession}
        class="w-full text-left px-3 py-2.5 rounded-xl bg-forest-500/10 hover:bg-forest-500/20 text-forest-600 flex items-center gap-2 transition-colors font-medium mt-2">
        <i class="fas fa-plus w-4 text-center"></i> 新建对话
      </button>
    </nav>

    <div class="flex-1 overflow-y-auto p-3">
      <h3 class="text-xs text-earth-500 uppercase tracking-wider mb-2 px-2">对话历史</h3>
      {#if ($conversations as any[]).length === 0}
        <EmptyState icon="fa-comments" message="暂无对话" />
      {:else}
        {#each $conversations as conv}
          <div class="group flex items-center justify-between w-full px-3 py-2 rounded-lg hover:bg-forest-500/6 text-sm transition-colors
                      {conv.id === $currentConversationId ? 'bg-forest-500/10 text-forest-700' : 'text-bark-600'}">
            <button class="truncate flex-1 min-w-0 text-left" onclick={() => loadConversation(conv.id)}>
              {conv.title}
              {#if conv.message_count > 0}
                <span class="text-xs text-earth-400 ml-1">({conv.message_count})</span>
              {/if}
            </button>
            <button onclick={(e) => delConv(conv.id, e)}
              class="opacity-0 group-hover:opacity-100 text-earth-400 hover:text-red-400 transition-all ml-1 flex-shrink-0"
              aria-label="删除对话">
              <i class="fas fa-trash text-xs"></i>
            </button>
          </div>
        {/each}
      {/if}
    </div>

    <div class="p-3 border-t border-earth-100">
      <button onclick={() => navTo('/settings')}
        class="w-full text-left px-3 py-2 rounded-lg hover:bg-forest-500/8 flex items-center gap-2 text-earth-500 hover:text-bark-700 transition-colors text-sm">
        <i class="fas fa-cog w-4 text-center"></i> 设置
      </button>
    </div>
  {/if}
</div>
