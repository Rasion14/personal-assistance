<script lang="ts">
  import MarkdownContent from './MarkdownContent.svelte';
  import ToolCallCard from './ToolCallCard.svelte';
  import { messages, removeMessagePair } from '../stores/chat.store';

  let {
    msg,
    streaming = false,
    index = 0,
  }: {
    msg: { id: string; role: string; content: string; timestamp: string; personaId?: string;
      toolCalls?: Array<{ id: string; name: string; status: string; result?: string }>; };
    streaming?: boolean;
    index?: number;
  } = $props();

  let isUser = $derived(msg.role === 'user');
  let isStreamingMsg = $derived(!isUser && streaming && msg === $messages.at(-1));

  // 使用消息自带的 personaId，而非全局当前 persona
  let msgPersonaId = $derived(msg.personaId || 'default');
  let personaLabel = $derived(
    msgPersonaId === 'maid' ? '小樱' :
    msgPersonaId === 'default' ? 'Rasion' :
    (msgPersonaId || 'Agent')
  );
</script>

<div class="flex {isUser ? 'justify-end' : 'justify-start'} group">
  <div class="max-w-2xl w-full">
    <div class="flex items-center gap-2 mb-1.5 px-1">
      <span class="text-sm font-semibold text-bark-700">
        {isUser ? '✨ 帅气的主人' : '🌸 ' + personaLabel}
      </span>
      <button onclick={() => removeMessagePair(index)}
        class="opacity-0 group-hover:opacity-100 text-earth-400 hover:text-red-400 transition-opacity text-xs"
        title="删除此轮对话">
        <i class="fas fa-times-circle"></i>
      </button>
      {#if !isUser && isStreamingMsg}
        <span class="status-dot streaming"></span>
      {/if}
    </div>

    {#if !isUser && msg.toolCalls && msg.toolCalls.length > 0}
      <div class="mb-2">
        {#each msg.toolCalls as tc}
          <ToolCallCard toolCall={tc} />
        {/each}
      </div>
    {/if}

    <div class="glass p-4 {isUser ? 'bg-gradient-to-br from-forest-500/5 to-forest-500/8' : 'bg-white/80'}">
      {#if isStreamingMsg && streaming}
        <span class="typing-cursor">{msg.content}</span>
      {:else if isUser}
        <div class="text-sm whitespace-pre-wrap text-bark-800">{msg.content}</div>
      {:else}
        <MarkdownContent content={msg.content} />
      {/if}
    </div>
  </div>
</div>
