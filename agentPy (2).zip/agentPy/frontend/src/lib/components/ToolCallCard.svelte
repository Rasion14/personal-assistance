<script lang="ts">
  let { toolCall }: { toolCall: any } = $props();

  let statusClass = $derived(
    toolCall.status === 'loading' ? 'text-warm-500' :
    toolCall.status === 'done' ? 'text-forest-500' : 'text-red-400'
  );
</script>

<div class="glass p-3 mb-2">
  <div class="flex items-center gap-2">
    <i class="fas fa-wrench text-forest-500"></i>
    <span class="font-mono text-sm font-semibold text-bark-700">{toolCall.name}</span>
    <span class="text-xs {statusClass}">
      {#if toolCall.status === 'loading'}<i class="fas fa-spinner fa-spin"></i> 执行中
      {:else if toolCall.status === 'done'}<i class="fas fa-check"></i> 完成
      {:else}<i class="fas fa-times"></i> 错误{/if}
    </span>
  </div>
  {#if toolCall.result}
    <pre class="mt-2 text-xs text-earth-700">{toolCall.result}</pre>
  {/if}
</div>
