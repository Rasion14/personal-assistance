<script lang="ts">
  let { icon = 'fa-inbox', message = '暂无数据', submessage = '' } = $props();
</script>

<div class="flex flex-col items-center justify-center py-12 text-earth-400">
  <i class="fas {icon} text-4xl mb-3 opacity-40"></i>
  <p class="text-sm text-bark-600">{message}</p>
  {#if submessage}
    <p class="text-xs mt-1 text-earth-500">{submessage}</p>
  {/if}
</div>
