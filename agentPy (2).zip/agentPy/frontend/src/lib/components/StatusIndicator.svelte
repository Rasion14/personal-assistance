<script lang="ts">
  import { isStreaming } from '../stores/chat.store';

  let status = $derived($isStreaming ? 'streaming' : 'idle');
</script>

<div class="flex items-center gap-1.5">
  <span class="status-dot {status}"></span>
  <span class="text-[11px] text-earth-500">{$isStreaming ? '思考中' : '就绪'}</span>
</div>
