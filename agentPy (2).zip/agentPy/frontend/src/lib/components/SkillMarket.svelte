<script lang="ts">
  import { skills } from '../stores/skills.store';
  import { listSkills, installSkill, uninstallSkill, enableSkill, disableSkill } from '../api/client';
  import { onMount } from 'svelte';

  let installUrl = $state('');
  let installing = $state(false);
  let tab = $state<'url' | 'upload'>('url');
  let uploading = $state(false);
  let uploadMsg = $state('');
  let uploadProgress = $state(0);

  onMount(() => loadSkills());

  async function loadSkills() {
    try {
      const data = await listSkills();
      $skills = data.skills || [];
    } catch {}
  }

  async function handleInstall() {
    if (!installUrl.trim()) return;
    installing = true;
    try {
      await installSkill(installUrl);
      installUrl = '';
      await loadSkills();
    } catch (e: any) { alert('安装失败: ' + e.message); }
    finally { installing = false; }
  }

  async function handleUpload(e: Event) {
    const input = e.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;
    uploading = true;
    uploadMsg = '';
    uploadProgress = 0;

    try {
      const API_BASE = 'http://localhost:8000';
      const key = localStorage.getItem('api_key') || '';
      const form = new FormData();
      form.append('file', file);

      // 使用 XMLHttpRequest 以支持上传进度
      const data: any = await new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open('POST', `${API_BASE}/api/skills/upload`);

        // 监听上传进度
        xhr.upload.addEventListener('progress', (evt) => {
          if (evt.lengthComputable) {
            uploadProgress = Math.round((evt.loaded / evt.total) * 100);
          }
        });

        xhr.addEventListener('load', () => {
          try {
            const parsed = JSON.parse(xhr.responseText);
            if (xhr.status >= 200 && xhr.status < 300) {
              resolve(parsed);
            } else {
              reject(new Error(parsed.detail || `上传失败 (${xhr.status})`));
            }
          } catch {
            reject(new Error('解析响应失败'));
          }
        });

        xhr.addEventListener('error', () => reject(new Error('网络错误')));
        xhr.addEventListener('abort', () => reject(new Error('上传已取消')));

        xhr.setRequestHeader('X-API-Key', key);
        xhr.send(form);
      });

      if (data.success) {
        uploadMsg = `✅ ${data.skill.name} 上传成功`;
        input.value = '';
        await loadSkills();
      } else {
        uploadMsg = '❌ ' + (data.detail || '上传失败');
      }
    } catch (e: any) { uploadMsg = '❌ ' + e.message; }
    finally { uploading = false; }
  }

  async function toggleEnable(name: string) {
    const skill = ($skills as any[]).find(s => s.name === name);
    if (skill?.status === 'enabled') await disableSkill(name);
    else await enableSkill(name);
    await loadSkills();
  }

  async function handleUninstall(name: string) {
    if (confirm('确定卸载 ' + name + '?')) {
      await uninstallSkill(name);
      await loadSkills();
    }
  }

  function getCategoryIcon(cat: string): string {
    const icons: Record<string, string> = {
      web: 'fa-globe', code: 'fa-code', data: 'fa-database',
      file: 'fa-file', analysis: 'fa-chart-bar', creativity: 'fa-palette',
      automation: 'fa-robot', other: 'fa-puzzle-piece'
    };
    return icons[cat] || 'fa-puzzle-piece';
  }

  function sourceLabel(skill: any): string {
    const meta = skill.metadata || {};
    if (meta.source === 'uploaded' || (skill.install_path && skill.install_path.includes('uploaded')))
      return '📁 本地';
    return '🌐 网络';
  }
</script>

<div class="h-full flex flex-col">
  <!-- Tab 切换 -->
  <div class="flex gap-1 mb-4 bg-white/50 rounded-xl p-1 w-fit">
    <button onclick={() => tab = 'url'}
      class="px-4 py-1.5 rounded-lg text-xs font-medium transition-colors
             {tab === 'url' ? 'bg-forest-500 text-white' : 'text-earth-600 hover:text-bark-700'}">
      🌐 URL 安装
    </button>
    <button onclick={() => tab = 'upload'}
      class="px-4 py-1.5 rounded-lg text-xs font-medium transition-colors
             {tab === 'upload' ? 'bg-forest-500 text-white' : 'text-earth-600 hover:text-bark-700'}">
      📁 本地上传
    </button>
  </div>

  {#if tab === 'url'}
    <div class="flex gap-3 mb-6">
      <input bind:value={installUrl} placeholder="输入 Skill ZIP URL..."
        class="flex-1" onkeydown={(e) => e.key === 'Enter' && handleInstall()} />
      <button onclick={handleInstall} disabled={installing} class="btn-primary">
        <i class="fas fa-download mr-2"></i>{installing ? '安装中...' : '安装'}
      </button>
    </div>
  {:else}
    <div class="mb-6">
      <label class="btn-primary cursor-pointer inline-block">
        <i class="fas fa-upload mr-2"></i>{uploading ? '上传中...' : '选择 ZIP 文件'}
        <input type="file" accept=".zip" onchange={handleUpload} class="hidden" disabled={uploading} />
      </label>
      {#if uploading && uploadProgress > 0}
        <div class="mt-2 w-full max-w-xs">
          <div class="h-2 bg-earth-200 rounded-full overflow-hidden">
            <div class="h-full bg-forest-500 rounded-full transition-all duration-300" style="width:{uploadProgress}%"></div>
          </div>
          <span class="text-xs text-earth-500 mt-0.5 block">{uploadProgress}%</span>
        </div>
      {/if}
      {#if uploadMsg}
        <span class="ml-3 text-sm text-forest-600">{uploadMsg}</span>
      {/if}
    </div>
  {/if}

  <!-- Skill grid -->
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 overflow-y-auto">
    {#each $skills as skill}
      <div class="glass p-5">
        <div class="flex items-start justify-between mb-3">
          <div class="flex items-center gap-2">
            <i class="fas {getCategoryIcon(skill.category)} text-forest-500 text-lg"></i>
            <div>
              <h3 class="font-semibold text-bark-700">{skill.name}</h3>
              <span class="text-xs text-earth-500">
                v{skill.version} · {sourceLabel(skill)}
              </span>
            </div>
          </div>
          <span class="status-dot {skill.status === 'enabled' ? 'working' : 'idle'}"></span>
        </div>
        <p class="text-sm text-earth-700 mb-3">{skill.description || '无描述'}</p>
        <div class="flex gap-2">
          <button onclick={() => toggleEnable(skill.name)}
            class="text-xs px-3 py-1 rounded-lg border border-earth-200 hover:border-forest-400 hover:text-forest-600 text-earth-600 transition-colors">
            {skill.status === 'enabled' ? '禁用' : '启用'}
          </button>
          <button onclick={() => handleUninstall(skill.name)}
            class="text-xs px-3 py-1 rounded-lg border border-earth-200 hover:border-red-300 hover:text-red-400 text-earth-600 transition-colors">
            卸载
          </button>
        </div>
      </div>
    {/each}
  </div>

  {#if ($skills as any[]).length === 0}
    <div class="flex-1 flex items-center justify-center">
      <div class="text-center text-earth-400">
        <i class="fas fa-puzzle-piece text-4xl mb-3 opacity-40"></i>
        <p class="text-sm">暂无已安装的 Skill</p>
      </div>
    </div>
  {/if}
</div>
