<script lang="ts">
  import { marked } from 'marked';
  import DOMPurify from 'dompurify';

  let { content = '', className = '' } = $props();

  // 配置 marked
  marked.setOptions({
    gfm: true,
    breaks: true,
  });

  let html = $derived(
    content
      ? DOMPurify.sanitize(
          (marked.parse(content, { async: false }) as string)
        )
      : ''
  );

  function handleCopy(e: MouseEvent) {
    const btn = e.currentTarget as HTMLButtonElement;
    const pre = btn.closest('.code-block-wrapper')?.querySelector('pre');
    if (!pre) return;
    const code = pre.textContent || '';
    navigator.clipboard.writeText(code).then(() => {
      btn.innerHTML = '<i class="fas fa-check"></i>';
      setTimeout(() => {
        btn.innerHTML = '<i class="fas fa-copy"></i>';
      }, 2000);
    });
  }

  // 在 HTML 渲染后为代码块添加 wrapper 和复制按钮
  $effect(() => {
    if (content) {
      requestAnimationFrame(() => {
        document.querySelectorAll('.markdown-content pre').forEach((pre) => {
          if (pre.closest('.code-block-wrapper')) return;
          const wrapper = document.createElement('div');
          wrapper.className = 'code-block-wrapper';
          pre.parentNode?.insertBefore(wrapper, pre);
          wrapper.appendChild(pre);

          const copyBtn = document.createElement('button');
          copyBtn.className = 'code-copy-btn';
          copyBtn.innerHTML = '<i class="fas fa-copy"></i>';
          copyBtn.onclick = (e) => handleCopy(e as MouseEvent);
          wrapper.appendChild(copyBtn);
        });
      });
    }
  });
</script>

<div class="markdown-content {className}">
  {@html html}
</div>
