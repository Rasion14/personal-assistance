<script lang="ts">
  import { currentPersonaId, currentConversationId } from '../stores/chat.store';
  import { listPersonas, switchPersona } from '../api/client';
  import { onMount } from 'svelte';

  let personas = $state<Array<{ id: string; name: string; display_name: string; icon: string; color: string; tagline: string }>>([]);
  let loading = $state(true);
  let open = $state(false);

  onMount(() => loadPersonas());

  async function loadPersonas() {
    loading = true;
    try {
      const data = await listPersonas();
      personas = data.personas || [];
    } catch { personas = []; }
    finally { loading = false; }
  }

  function select(id: string) {
    $currentPersonaId = id;
    open = false;
    // 异步验证并更新服务端会话的人设
    let convId = '';
    currentConversationId.subscribe(v => convId = v)();
    switchPersona(id, convId || undefined).catch(() => {});
  }

  function handleOutsideClick(e: MouseEvent) {
    const target = e.target as HTMLElement;
    if (!target.closest('.persona-selector')) { open = false; }
  }

  let currentPersona = $derived(
    personas.find(p => p.id === $currentPersonaId)
    || personas[0]
    || { id: 'default', name: '助手', display_name: '默认', icon: 'fa-robot', color: '#4a9c5d', tagline: '' }
  );
</script>

<svelte:window onclick={handleOutsideClick} />

<div class="persona-selector relative">
  <button
    onclick={() => open = !open}
    disabled={loading}
    class="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs transition-all cursor-pointer
           border bg-white/60 hover:bg-white/90 disabled:opacity-50"
    style="border-color: {currentPersona.color}30;"
    title="{currentPersona.display_name}: {currentPersona.tagline}"
  >
    <span class="flex items-center justify-center w-5 h-5 rounded-full text-[10px]"
          style="background: {currentPersona.color}18; color: {currentPersona.color}">
      <i class="fas {currentPersona.icon}"></i>
    </span>
    <span class="text-bark-600">{currentPersona.name}</span>
    <i class="fas fa-chevron-down text-[10px] text-earth-400"></i>
  </button>

  {#if open}
    <div class="absolute bottom-full left-0 mb-2 w-52 glass border border-earth-200 rounded-xl shadow-lg z-50 overflow-hidden">
      <div class="px-3 py-1.5 text-[11px] text-earth-500 uppercase tracking-wider">角色</div>
      {#each personas as p}
        <button
          onclick={() => select(p.id)}
          class="w-full flex items-center gap-2.5 px-3 py-2 text-left hover:bg-forest-500/8 transition-colors
                 {($currentPersonaId as string) === p.id ? 'bg-forest-500/6' : ''}"
        >
          <span class="w-7 h-7 rounded-full flex items-center justify-center text-xs"
                style="background: {p.color}18; color: {p.color}">
            <i class="fas {p.icon}"></i>
          </span>
          <div class="flex-1 min-w-0">
            <div class="text-xs font-medium text-bark-700">{p.display_name}</div>
            <div class="text-[11px] text-earth-500 truncate">{p.tagline}</div>
          </div>
          {#if ($currentPersonaId as string) === p.id}
            <i class="fas fa-check text-[10px]" style="color: {p.color}"></i>
          {/if}
        </button>
      {/each}
    </div>
  {/if}
</div>
