<script lang="ts">
  import { onDestroy } from 'svelte';

  let { text = '', speed = 16 } = $props();

  let displayed = $state('');
  let timer: ReturnType<typeof setInterval> | null = null;

  $effect(() => {
    if (text) {
      displayed = '';
      if (timer) clearInterval(timer);
      let i = 0;
      timer = setInterval(() => {
        if (i < text.length) {
          displayed += text[i];
          i++;
        } else {
          if (timer) clearInterval(timer);
        }
      }, speed);
    }

    return () => {
      if (timer) clearInterval(timer);
    };
  });
</script>

<span class="typing-cursor">{displayed}</span>
