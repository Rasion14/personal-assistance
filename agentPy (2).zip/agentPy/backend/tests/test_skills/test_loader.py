"""测试 Skill 加载器

验证 SKILL.md 和 skill.yaml 解析、合并、错误处理。
"""

from __future__ import annotations

from pathlib import Path

from agent_platform.skills.loader import (
    load_skill_from_directory,
    load_skill_to_info,
    build_system_instructions_prompt,
)


class TestLoadSkillFromDirectory:
    """Skill 目录加载测试"""

    def test_load_skill_md(self, sample_skill_md: Path):
        """测试加载 SKILL.md"""
        result = load_skill_from_directory(sample_skill_md)
        assert result["name"] == "test-skill"
        assert result["version"] == "1.0.0"
        assert result["description"] == "一个测试 Skill"
        assert "error" not in result or result["error"] is None
        assert result["source"] == "skill.md"
        assert "test_tool" in result["tools"]

    def test_load_skill_yaml(self, sample_skill_yaml: Path):
        """测试加载 skill.yaml"""
        result = load_skill_from_directory(sample_skill_yaml)
        assert result["name"] == "yaml-skill"
        assert result["version"] == "2.0.0"
        assert result["description"] == "YAML 格式的测试 Skill"
        assert "error" not in result or result["error"] is None
        assert result["source"] == "skill.yaml"
        assert "yaml_tool" in result["tools"]

    def test_load_nonexistent_directory(self):
        """测试加载不存在的目录"""
        result = load_skill_from_directory("/nonexistent/path")
        assert result.get("error") is not None
        assert "不存在" in result["error"]

    def test_load_empty_directory(self, tmp_skills_dir: Path):
        """测试加载空目录"""
        empty_dir = tmp_skills_dir / "empty"
        empty_dir.mkdir()
        result = load_skill_from_directory(empty_dir)
        assert result.get("error") is not None
        assert "未找到" in result["error"]

    def test_load_skill_md_without_frontmatter(self, tmp_skills_dir: Path):
        """测试没有 frontmatter 的 SKILL.md"""
        skill_dir = tmp_skills_dir / "no-frontmatter"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text("这是一段纯文本指令。", encoding="utf-8")
        result = load_skill_from_directory(skill_dir)
        assert result["instructions"] == "这是一段纯文本指令。"
        assert result.get("error") is None

    def test_load_merged_md_and_yaml(self, tmp_skills_dir: Path):
        """测试 SKILL.md + skill.yaml 合并"""
        skill_dir = tmp_skills_dir / "merged-skill"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text(
            "---\n"
            "name: merged-skill\n"
            "version: 1.0.0\n"
            "description: MD 描述\n"
            "tools:\n"
            "  - md_tool\n"
            "---\n"
            "MD 正文内容。",
            encoding="utf-8",
        )
        (skill_dir / "skill.yaml").write_text(
            "name: yaml-name\n"
            "version: 0.1.0\n"
            "tools:\n"
            "  - yaml_tool\n"
            "metadata:\n"
            "  author: test\n",
            encoding="utf-8",
        )
        result = load_skill_from_directory(skill_dir)
        assert result["source"] == "merged"
        # name/version 以 SKILL.md 为主
        assert result["name"] == "merged-skill"
        assert result["version"] == "1.0.0"
        # tools 合并
        assert "md_tool" in result["tools"]
        assert "yaml_tool" in result["tools"]


class TestLoadSkillToInfo:
    """SkillInfo 模型加载测试"""

    def test_load_to_info_success(self, sample_skill_md: Path):
        """测试成功加载为 SkillInfo"""
        info = load_skill_to_info(sample_skill_md)
        assert info.name == "test-skill"
        assert info.version == "1.0.0"
        assert info.is_available()

    def test_load_to_info_error(self):
        """测试加载失败时返回 ERROR 状态"""
        info = load_skill_to_info("/nonexistent")
        assert info.status.value == "error"
        assert not info.is_available()


class TestBuildSystemInstructionsPrompt:
    """系统指令构建测试"""

    def test_empty_skills(self):
        """空技能列表"""
        result = build_system_instructions_prompt([])
        assert result == ""

    def test_single_skill(self):
        """单个技能"""
        skills = [
            {"name": "test", "version": "1.0", "description": "测试",
             "instructions": "指令内容", "tools": ["tool1"]}
        ]
        result = build_system_instructions_prompt(skills)
        assert "test" in result
        assert "测试" in result
        assert "指令内容" in result

    def test_skip_error_skills(self):
        """跳过加载失败的技能"""
        skills = [
            {"name": "good", "version": "1.0", "description": "正常",
             "instructions": "正常指令"},
            {"name": "bad", "error": "加载失败", "version": "1.0"},
        ]
        result = build_system_instructions_prompt(skills)
        assert "good" in result
        assert "bad" not in result
