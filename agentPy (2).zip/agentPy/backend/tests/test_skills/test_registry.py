"""测试 Skill 注册中心

验证 CRUD 操作、启用/禁用、状态持久化。
"""

from __future__ import annotations

from pathlib import Path

from agent_platform.skills.models import SkillInfo, SkillStatus
from agent_platform.skills.registry import SkillRegistry


class TestSkillRegistry:
    """Skill 注册中心测试"""

    def test_add_skill(self, tmp_path: Path):
        """测试添加 Skill"""
        registry = SkillRegistry(skills_dir=tmp_path)
        skill = SkillInfo(
            name="test-skill",
            version="1.0.0",
            description="测试",
            install_path=str(tmp_path / "test-skill"),
        )
        result = registry.add_skill(skill)
        assert result.name == "test-skill"
        assert len(registry.get_all()) == 1

    def test_get_by_name(self, tmp_path: Path):
        """测试按名称获取"""
        registry = SkillRegistry(skills_dir=tmp_path)
        skill = SkillInfo(
            name="test-skill",
            version="1.0.0",
            description="测试",
            install_path=str(tmp_path / "test-skill"),
        )
        registry.add_skill(skill)
        found = registry.get_by_name("test-skill")
        assert found is not None
        assert found.name == "test-skill"

    def test_get_nonexistent(self, tmp_path: Path):
        """测试获取不存在的 Skill"""
        registry = SkillRegistry(skills_dir=tmp_path)
        assert registry.get_by_name("nonexistent") is None

    def test_enable_skill(self, tmp_path: Path):
        """测试启用 Skill"""
        registry = SkillRegistry(skills_dir=tmp_path)
        skill = SkillInfo(
            name="test-skill",
            version="1.0.0",
            description="测试",
            install_path=str(tmp_path / "test-skill"),
            status=SkillStatus.INSTALLED,
        )
        registry.add_skill(skill)
        enabled = registry.enable_skill("test-skill")
        assert enabled.status == SkillStatus.ENABLED
        assert enabled.is_active()

    def test_disable_skill(self, tmp_path: Path):
        """测试禁用 Skill"""
        registry = SkillRegistry(skills_dir=tmp_path)
        skill = SkillInfo(
            name="test-skill",
            version="1.0.0",
            description="测试",
            install_path=str(tmp_path / "test-skill"),
            status=SkillStatus.ENABLED,
        )
        registry.add_skill(skill)
        disabled = registry.disable_skill("test-skill")
        assert disabled.status == SkillStatus.INSTALLED
        assert not disabled.is_active()

    def test_remove_skill(self, tmp_path: Path):
        """测试移除 Skill"""
        registry = SkillRegistry(skills_dir=tmp_path)
        skill = SkillInfo(
            name="test-skill",
            version="1.0.0",
            description="测试",
            install_path=str(tmp_path / "test-skill"),
        )
        registry.add_skill(skill)
        result = registry.remove_skill("test-skill")
        assert result is True
        assert len(registry.get_all()) == 0

    def test_get_enabled(self, tmp_path: Path):
        """测试获取已启用 Skill"""
        registry = SkillRegistry(skills_dir=tmp_path)
        registry.add_skill(SkillInfo(
            name="enabled-skill", version="1.0.0", description="测试",
            install_path=str(tmp_path), status=SkillStatus.ENABLED,
        ))
        registry.add_skill(SkillInfo(
            name="disabled-skill", version="1.0.0", description="测试",
            install_path=str(tmp_path), status=SkillStatus.INSTALLED,
        ))
        enabled = registry.get_enabled()
        assert len(enabled) == 1
        assert enabled[0].name == "enabled-skill"

    def test_persistence(self, tmp_path: Path):
        """测试持久化 — 重新加载后数据保留"""
        registry = SkillRegistry(skills_dir=tmp_path)
        registry.add_skill(SkillInfo(
            name="persistent-skill", version="1.0.0", description="测试",
            install_path=str(tmp_path), status=SkillStatus.ENABLED,
        ))

        # 重新创建注册中心 (模拟重启)
        registry2 = SkillRegistry(skills_dir=tmp_path)
        skill = registry2.get_by_name("persistent-skill")
        assert skill is not None
        assert skill.status == SkillStatus.ENABLED

    def test_update_skill(self, tmp_path: Path):
        """测试更新 Skill"""
        registry = SkillRegistry(skills_dir=tmp_path)
        registry.add_skill(SkillInfo(
            name="test-skill", version="1.0.0", description="旧描述",
            install_path=str(tmp_path),
        ))
        updated = registry.update_skill("test-skill", description="新描述")
        assert updated.description == "新描述"
