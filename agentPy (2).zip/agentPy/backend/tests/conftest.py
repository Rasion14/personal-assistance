"""pytest 全局配置

提供测试 fixtures:
- test_settings: 模拟配置实例
- test_storage: 内存 SQLite 存储
- event_loop_policy: asyncio 事件循环策略
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import AsyncGenerator

import pytest
import pytest_asyncio

from agent_platform.config import Settings, get_settings, _settings


@pytest.fixture(autouse=True)
def reset_settings():
    """每个测试后重置 Settings 单例，防止测试间污染"""
    global _settings
    old = _settings
    _settings = None
    yield
    # 恢复原始设置
    _settings = old


@pytest.fixture
def test_settings(tmp_path: Path) -> Settings:
    """创建一个隔离的 Settings 实例，使用临时目录"""
    return Settings(
        app_env="test",
        app_debug=True,
        api_key="test-api-key",
        anthropic_api_key="test-ant-key",
        database_url=f"sqlite+aiosqlite:///{tmp_path / 'test.db'}",
        skills_data_dir=str(tmp_path / "skills"),
        sandbox_dir=str(tmp_path / "sandbox"),
    )


@pytest_asyncio.fixture
async def test_storage(test_settings: Settings) -> AsyncGenerator:
    """创建一个测试用的 ConversationStorage 实例"""
    from agent_platform.conversations.storage import ConversationStorage, get_storage, _storage

    storage = ConversationStorage(db_url=test_settings.database_url)
    await storage.connect()
    # 临时替换全局单例
    global _storage
    old_storage = _storage
    _storage = storage
    yield storage
    await storage.close()
    _storage = old_storage


@pytest.fixture
def tmp_skills_dir(tmp_path: Path) -> Path:
    """创建一个临时 Skills 目录"""
    skills_dir = tmp_path / "skills"
    skills_dir.mkdir(parents=True, exist_ok=True)
    return skills_dir


@pytest.fixture
def sample_skill_md(tmp_skills_dir: Path) -> Path:
    """创建一个示例 SKILL.md 文件"""
    skill_dir = tmp_skills_dir / "test-skill"
    skill_dir.mkdir(parents=True, exist_ok=True)
    skill_file = skill_dir / "SKILL.md"
    skill_file.write_text(
        "---\n"
        "name: test-skill\n"
        "version: 1.0.0\n"
        "description: 一个测试 Skill\n"
        "instructions: |\n"
        "  这是测试 Skill 的指令。\n"
        "tools:\n"
        "  - test_tool\n"
        "---\n"
        "\n"
        "这是 SKILL.md 的正文内容。",
        encoding="utf-8",
    )
    return skill_dir


@pytest.fixture
def sample_skill_yaml(tmp_skills_dir: Path) -> Path:
    """创建一个示例 skill.yaml 文件"""
    skill_dir = tmp_skills_dir / "yaml-skill"
    skill_dir.mkdir(parents=True, exist_ok=True)
    yaml_file = skill_dir / "skill.yaml"
    yaml_file.write_text(
        "name: yaml-skill\n"
        "version: 2.0.0\n"
        "description: YAML 格式的测试 Skill\n"
        "instructions: |\n"
        "  YAML Skill 指令内容。\n"
        "tools:\n"
        "  - yaml_tool\n"
        "metadata:\n"
        "  author: test\n",
        encoding="utf-8",
    )
    return skill_dir
