"""测试计算器工具

验证数学计算功能和安全性 (注入攻击防护)。
"""

from __future__ import annotations

from agent_platform.tools.calculator import calculator


class TestCalculator:
    """计算器工具测试"""

    def test_basic_addition(self):
        assert calculator("2 + 3") == "5"

    def test_subtraction(self):
        assert calculator("10 - 4") == "6"

    def test_multiplication(self):
        assert calculator("3 * 4") == "12"

    def test_division(self):
        assert calculator("10 / 2") == "5.0"

    def test_modulo(self):
        assert calculator("10 % 3") == "1"

    def test_parentheses(self):
        assert calculator("(2 + 3) * 4") == "20"

    def test_decimal(self):
        assert calculator("1.5 + 2.5") == "4.0"

    def test_complex_expression(self):
        assert calculator("2 + 3 * 4") == "14"

    def test_whitespace_handling(self):
        assert calculator("  2 + 3  ") == "5"

    # -- 安全测试 --

    def test_block_import(self):
        """阻止 import 语句"""
        result = calculator("import os")
        assert "错误" in result or "非法" in result

    def test_block_system_call(self):
        """阻止 __import__ 调用"""
        result = calculator("__import__('os').system('ls')")
        assert "错误" in result or "非法" in result

    def test_block_semicolon(self):
        """阻止分号拼接"""
        result = calculator("1 + 1; import os")
        assert "错误" in result or "非法" in result

    def test_block_builtins_access(self):
        """阻止访问内置函数"""
        result = calculator("__builtins__")
        assert "错误" in result or "非法" in result

    def test_block_eval(self):
        """阻止 eval 调用"""
        result = calculator("eval('1+1')")
        assert "错误" in result or "非法" in result

    def test_block_string_execution(self):
        """阻止字符串执行"""
        result = calculator("'hello'.upper()")
        assert "错误" in result or "非法" in result

    def test_empty_input(self):
        """空输入处理"""
        result = calculator("")
        assert "错误" in result or "非法" in result

    def test_invalid_expression(self):
        """无效表达式处理"""
        result = calculator("+++")
        # 应返回计算错误
        assert "错误" in result or "计算" in result
