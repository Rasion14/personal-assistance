"""测试文件操作工具

验证路径穿越防护和文件读写功能。
"""

from __future__ import annotations

from pathlib import Path

import pytest

from agent_platform.tools.file_ops import _safe_resolve


class TestSafeResolve:
    """路径安全解析测试"""

    def test_normal_path(self, tmp_path: Path):
        result = _safe_resolve(tmp_path, "test.txt")
        assert result == tmp_path / "test.txt"

    def test_nested_path(self, tmp_path: Path):
        result = _safe_resolve(tmp_path, "sub/dir/file.txt")
        assert result == tmp_path / "sub" / "dir" / "file.txt"

    def test_block_parent_traversal(self, tmp_path: Path):
        with pytest.raises(PermissionError, match="路径越界"):
            _safe_resolve(tmp_path, "../secret.txt")

    def test_block_double_parent_traversal(self, tmp_path: Path):
        with pytest.raises(PermissionError, match="路径越界"):
            _safe_resolve(tmp_path, "../../etc/passwd")

    def test_block_absolute_path(self, tmp_path: Path):
        with pytest.raises(PermissionError, match="路径越界"):
            _safe_resolve(tmp_path, "/etc/passwd")

    def test_block_symlink_escape(self, tmp_path: Path):
        """阻止符号链接逃逸"""
        outside = tmp_path / "outside"
        outside.mkdir()
        (outside / "secret.txt").write_text("secret")

        sandbox = tmp_path / "sandbox"
        sandbox.mkdir()
        (sandbox / "link").symlink_to(outside)

        with pytest.raises(PermissionError, match="路径越界"):
            _safe_resolve(sandbox, "link/secret.txt")
