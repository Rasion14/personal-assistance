"""测试安全中间件

验证 API Key 认证和速率限制。
"""

from __future__ import annotations

import pytest
from httpx import AsyncClient, ASGITransport

from agent_platform.main import create_app


@pytest.mark.asyncio
async def test_api_key_required(monkeypatch):
    """测试缺少 API Key 返回 401"""
    monkeypatch.setenv("APP_ENV", "production")
    monkeypatch.setenv("API_KEY", "production-secret-key")

    from agent_platform.config import _settings
    import agent_platform.config
    agent_platform.config._settings = None

    app = create_app()
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post("/api/chat", json={"message": "hello"})
        assert response.status_code == 401


@pytest.mark.asyncio
async def test_valid_api_key(monkeypatch):
    """测试有效 API Key 通过认证"""
    monkeypatch.setenv("APP_ENV", "production")
    monkeypatch.setenv("API_KEY", "production-secret-key")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    from agent_platform.config import _settings
    import agent_platform.config
    agent_platform.config._settings = None

    app = create_app()
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/api/chat",
            json={"message": "hello"},
            headers={"X-API-Key": "production-secret-key"},
        )
        assert response.status_code != 401


@pytest.mark.asyncio
async def test_health_bypasses_auth(monkeypatch):
    """测试健康检查端点不需要认证"""
    monkeypatch.setenv("APP_ENV", "production")
    monkeypatch.setenv("API_KEY", "production-secret-key")

    from agent_platform.config import _settings
    import agent_platform.config
    agent_platform.config._settings = None

    app = create_app()
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.get("/api/health")
        assert response.status_code == 200


@pytest.mark.asyncio
async def test_dev_mode_skips_auth(monkeypatch):
    """测试开发模式跳过认证"""
    monkeypatch.setenv("APP_ENV", "development")
    monkeypatch.setenv("API_KEY", "default-dev-key-change-me")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    from agent_platform.config import _settings
    import agent_platform.config
    agent_platform.config._settings = None

    app = create_app()
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post("/api/chat", json={"message": "hello"})
        assert response.status_code != 401
