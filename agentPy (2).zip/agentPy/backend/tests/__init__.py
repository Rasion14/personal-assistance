"""
# agent-platform test suites

测试套件:
- test_config.py: 配置加载、默认值、环境变量
- test_tools/: 计算器、文件操作、Web 工具
- test_skills/: Skill 加载器、注册中心
- test_api/: API 路由测试
- test_models/: 模型解析器
- test_security.py: 安全中间件
- test_errors.py: 错误处理
"""
