"""测试模型解析器

验证 model_id 解析、provider 验证。
"""

from __future__ import annotations

from agent_platform.models.resolver import resolve_model


def test_resolve_valid_anthropic_model(monkeypatch):
    """测试解析有效的 Anthropic 模型"""
    from agent_platform.config import Settings, _settings
    monkeypatch.setattr(
        "agent_platform.config._settings",
        Settings(anthropic_api_key="test-key"),
    )
    result = resolve_model("anthropic:claude-sonnet-4-6")
    assert result == "anthropic:claude-sonnet-4-6"


def test_resolve_missing_api_key(monkeypatch):
    """测试缺少 API Key 时抛出异常"""
    from agent_platform.config import Settings, _settings
    monkeypatch.setattr(
        "agent_platform.config._settings",
        Settings(anthropic_api_key=""),
    )
    try:
        resolve_model("anthropic:claude-sonnet-4-6")
        assert False, "Should have raised ValueError"
    except ValueError as e:
        assert "API Key" in str(e) or "未配置" in str(e)


def test_resolve_ollama_no_key_needed(monkeypatch):
    """测试 Ollama 不需要 API Key"""
    from agent_platform.config import Settings, _settings
    monkeypatch.setattr(
        "agent_platform.config._settings",
        Settings(),
    )
    result = resolve_model("ollama:llama3.2")
    assert result == "ollama:llama3.2"


def test_resolve_custom_model_id(monkeypatch):
    """测试自定义 model_id (不严格限制)"""
    from agent_platform.config import Settings, _settings
    monkeypatch.setattr(
        "agent_platform.config._settings",
        Settings(anthropic_api_key="test-key"),
    )
    # 未知的 model_id 不会被阻止（只要 API Key 存在）
    result = resolve_model("anthropic:custom-model")
    assert result == "anthropic:custom-model"
