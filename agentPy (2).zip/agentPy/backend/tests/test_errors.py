"""测试统一错误处理

验证结构化错误响应格式和全局异常处理器。
"""

from __future__ import annotations

import pytest
from httpx import AsyncClient, ASGITransport

from agent_platform.errors import (
    AgentPlatformError,
    ValidationError,
    NotFoundError,
    ConflictError,
    TimeoutError,
)


@pytest.mark.asyncio
async def test_validation_error_response():
    """测试验证错误返回 400"""
    from fastapi import FastAPI
    from agent_platform.errors import register_exception_handlers

    app = FastAPI()
    register_exception_handlers(app)

    @app.post("/test")
    async def test_endpoint():
        raise ValidationError("无效的消息格式")

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post("/test")
        assert response.status_code == 400
        data = response.json()
        assert "error" in data
        assert data["error"]["code"] == "VALIDATION_ERROR"
        assert "无效" in data["error"]["message"]


@pytest.mark.asyncio
async def test_not_found_error_response():
    """测试 404 错误"""
    from fastapi import FastAPI
    from agent_platform.errors import register_exception_handlers

    app = FastAPI()
    register_exception_handlers(app)

    @app.get("/test")
    async def test_endpoint():
        raise NotFoundError("资源不存在")

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.get("/test")
        assert response.status_code == 404
        data = response.json()
        assert data["error"]["code"] == "NOT_FOUND"


@pytest.mark.asyncio
async def test_timeout_error_response():
    """测试超时错误返回 408"""
    from fastapi import FastAPI
    from agent_platform.errors import register_exception_handlers

    app = FastAPI()
    register_exception_handlers(app)

    @app.post("/test")
    async def test_endpoint():
        raise TimeoutError("请求超时")

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post("/test")
        assert response.status_code == 408


@pytest.mark.asyncio
async def test_generic_exception_returns_safe_message():
    """测试未捕获异常被全局处理器捕获并返回 500"""
    from fastapi import FastAPI
    from starlette.testclient import TestClient

    from agent_platform.errors import register_exception_handlers

    app = FastAPI(debug=False)
    register_exception_handlers(app)

    @app.get("/test")
    async def test_endpoint():
        raise RuntimeError("Internal secret error details")

    client = TestClient(app, raise_server_exceptions=False)
    response = client.get("/test")
    assert response.status_code == 500
    data = response.json()
    assert "error" in data
    # 不应返回内部错误详情
    assert "secret" not in data.get("error", {}).get("message", "")
