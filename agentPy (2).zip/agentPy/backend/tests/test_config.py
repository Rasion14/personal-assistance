"""测试配置模块

验证 Settings 加载、默认值、环境变量优先级、
能力开关、生产环境校验等。
"""

from __future__ import annotations

import os

from agent_platform.config import Settings


def test_default_settings():
    """测试默认配置值"""
    settings = Settings()
    assert settings.app_name == "agent-platform"
    assert settings.app_env == "development"
    assert settings.app_debug is True
    assert settings.app_version == "0.1.0"
    assert settings.api_key == "default-dev-key-change-me"
    assert settings.default_model == "anthropic:claude-sonnet-4-6"


def test_settings_from_env():
    """测试环境变量覆盖"""
    os.environ["APP_NAME"] = "test-app"
    os.environ["APP_ENV"] = "production"
    os.environ["API_KEY"] = "test-key"
    try:
        settings = Settings()
        assert settings.app_name == "test-app"
        assert settings.app_env == "production"
        assert settings.api_key == "test-key"
        assert settings.is_production is True
    finally:
        os.environ.pop("APP_NAME", None)
        os.environ.pop("APP_ENV", None)
        os.environ.pop("API_KEY", None)


def test_cors_origins_list():
    """测试 CORS 解析"""
    settings = Settings(cors_origins="http://localhost:3000, http://example.com")
    assert settings.cors_origins_list == ["http://localhost:3000", "http://example.com"]


def test_cors_origins_empty():
    """测试空 CORS 字符串"""
    settings = Settings(cors_origins="")
    assert settings.cors_origins_list == []


def test_capability_defaults():
    """测试能力开关默认关闭"""
    settings = Settings()
    assert settings.enable_thinking is False
    assert settings.enable_planning is False
    assert settings.enable_code_mode is False
    assert settings.enable_filesystem is False
    assert settings.enable_shell is False
    assert settings.enable_subagents is False
    assert settings.enable_compaction is False


def test_capability_toggles():
    """测试能力开关启用"""
    settings = Settings(
        enable_thinking=True,
        enable_planning=True,
        enable_code_mode=True,
    )
    assert settings.enable_thinking is True
    assert settings.enable_planning is True
    assert settings.enable_code_mode is True
    assert settings.enable_filesystem is False


def test_security_defaults():
    """测试安全参数默认值"""
    settings = Settings()
    assert settings.agent_request_timeout == 120
    assert settings.max_message_length == 10000
    assert settings.max_response_length == 65536
    assert settings.max_file_read_bytes == 1048576


def test_shell_commands_list():
    """测试 Shell 命令解析"""
    settings = Settings(shell_allowed_commands="ls, cat, grep")
    assert settings.shell_commands_list == ["ls", "cat", "grep"]


def test_has_any_llm_key():
    """测试 LLM Key 检查"""
    settings = Settings()
    assert settings.has_any_llm_key() is False

    settings = Settings(anthropic_api_key="sk-test")
    assert settings.has_any_llm_key() is True

    settings = Settings(openai_api_key="sk-test")
    assert settings.has_any_llm_key() is True


def test_database_backend():
    """测试数据库后端检测"""
    settings = Settings()
    assert settings.get_database_backend() == "sqlite"

    settings = Settings(
        database_url="postgresql+asyncpg://user:pass@localhost/db"
    )
    assert settings.get_database_backend() == "postgresql"


def test_log_level():
    """测试日志级别"""
    settings = Settings(app_env="development")
    assert settings.log_level == "DEBUG"

    settings = Settings(app_env="production")
    assert settings.log_level == "INFO"
