"""测试健康检查 API

验证健康检查端点返回正确的状态信息。
"""

from __future__ import annotations

import pytest
from httpx import AsyncClient, ASGITransport

from agent_platform.main import create_app


@pytest.mark.asyncio
async def test_health_check():
    """测试健康检查端点"""
    app = create_app()
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.get("/api/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert "service" in data
        assert "version" in data
        assert "environment" in data
