"""agent_platform — 基于 Pydantic AI 搭建的 Agent 平台

基于 pydantic-ai 2.x + pydantic-ai-harness + FastAPI 构建的企业级智能体平台。
支持多模型切换、Skill 动态管理、流式对话、沙箱代码执行等企业级功能。
"""

__version__ = "0.1.0"
