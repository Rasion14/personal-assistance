"""请求追踪中间件

为每个 HTTP 请求生成或传递 X-Request-ID，
注入到 scope 和响应头中用于链路追踪。
"""

from __future__ import annotations

import uuid

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response


class RequestIDMiddleware(BaseHTTPMiddleware):
    """X-Request-ID 中间件

    如果请求头中已有 X-Request-ID，则透传；
    否则生成一个 UUID 并注入到 scope 和响应头中。
    """

    async def dispatch(self, request: Request, call_next) -> Response:
        request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
        request.scope["request_id"] = request_id

        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response
