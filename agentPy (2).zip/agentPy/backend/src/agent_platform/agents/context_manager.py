"""对话上下文管理器

参考 Claude Code 的记忆管理机制:
1. 最大消息数限制 — 超过则按策略压缩
2. 最大 token 数限制 — 超过则逐条移除旧消息
3. 多种压缩策略: truncate / summarize / sliding_window

当消息数或 token 数超限时自动触发压缩，保证上下文在模型窗口内。
"""

from __future__ import annotations

import logging
from typing import Any

from agent_platform.config import get_settings

_logger = logging.getLogger("agent_platform.context")


def estimate_tokens(text: str) -> int:
    """粗略估算 token 数: 中文约 1.5 字/token, 英文约 4 字/token"""
    chinese_chars = sum(1 for c in text if '一' <= c <= '鿿')
    other_chars = len(text) - chinese_chars
    return int(chinese_chars / 1.5 + other_chars / 4)


def manage_context(
    message_history: list[dict],
    strategy: str = "sliding_window",
    max_messages: int | None = None,
    max_tokens: int | None = None,
) -> list[dict]:
    """管理对话上下文

    当消息数或 token 数超限时，按策略压缩历史消息。

    Args:
        message_history: [{role, content}, ...] 格式的消息列表
        strategy: 压缩策略
            - "sliding_window": 保留最近 N 条消息 (默认)
            - "truncate": 只保留最近的消息, 丢弃旧消息
            - "summarize": 压缩旧消息为摘要 (需要 LLM 调用, 暂用 truncate 代替)
        max_messages: 最大消息数 (None=使用配置)
        max_tokens: 最大 token 数 (None=使用配置)

    Returns:
        压缩后的消息列表
    """
    settings = get_settings()
    max_msgs = max_messages or settings.max_context_messages
    max_tok = max_tokens or settings.max_context_tokens

    if not message_history:
        return message_history

    result = list(message_history)

    # 1. 消息数超限 → 滑动窗口
    if len(result) > max_msgs:
        _logger.info(
            "Context: %d messages exceeds limit %d, applying %s",
            len(result), max_msgs, strategy,
        )
        if strategy == "sliding_window":
            # 保留 system 消息 + 最近的消息
            system_msgs = [m for m in result if m.get("role") == "system"]
            other_msgs = [m for m in result if m.get("role") != "system"]
            result = system_msgs + other_msgs[-(max_msgs - len(system_msgs)):]
        else:
            result = result[-max_msgs:]

    # 2. Token 数超限 → 逐条移除最旧的非 system 消息
    total_tokens = sum(estimate_tokens(m.get("content", "")) for m in result)
    while total_tokens > max_tok and len(result) > 2:
        # 找到第一条非 system 消息并移除
        for i, m in enumerate(result):
            if m.get("role") != "system":
                removed = result.pop(i)
                total_tokens -= estimate_tokens(removed.get("content", ""))
                break
        else:
            break  # 只剩 system 消息了

    if len(result) < len(message_history):
        _logger.info(
            "Context compressed: %d→%d messages, %d tokens (limit: %d msgs, %d tok)",
            len(message_history), len(result), total_tokens, max_msgs, max_tok,
        )

    return result


def context_stats(messages: list[dict]) -> dict[str, Any]:
    """统计上下文消息的指标"""
    total_chars = sum(len(m.get("content", "")) for m in messages)
    total_tokens = sum(estimate_tokens(m.get("content", "")) for m in messages)
    return {
        "message_count": len(messages),
        "total_chars": total_chars,
        "estimated_tokens": total_tokens,
        "roles": {m.get("role", "?") for m in messages},
    }
