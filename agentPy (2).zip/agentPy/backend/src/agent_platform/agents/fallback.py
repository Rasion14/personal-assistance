"""模型回退链 + 熔断器

当主模型发生错误时，按优先级链自动切换到备用模型。
熔断器在连续失败后临时禁用故障模型，冷却后自动恢复探测。
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from agent_platform.config import get_settings
from agent_platform.agents.retry import classify_error

_logger = logging.getLogger("agent_platform.fallback")


class CircuitState(str, Enum):
    CLOSED = "closed"         # 正常通行
    OPEN = "open"             # 熔断中，拒绝请求
    HALF_OPEN = "half_open"  # 冷却后探测


@dataclass
class CircuitBreaker:
    """单个模型的熔断器

    状态机: CLOSED → (连续N次失败) → OPEN → (冷却T秒) → HALF_OPEN
             HALF_OPEN → (成功) → CLOSED
             HALF_OPEN → (失败) → OPEN (重新计时)
    """

    threshold: int = 3         # 连续失败 N 次后熔断
    cooldown: float = 60.0     # 冷却时间 (秒)

    state: CircuitState = CircuitState.CLOSED
    failure_count: int = 0
    last_failure_time: float = 0.0
    last_success_time: float = 0.0

    @classmethod
    def from_settings(cls) -> "CircuitBreaker":
        settings = get_settings()
        return cls(
            threshold=settings.circuit_breaker_threshold,
            cooldown=settings.circuit_breaker_cooldown,
        )

    def record_success(self) -> None:
        self.last_success_time = time.time()
        if self.state == CircuitState.HALF_OPEN:
            _logger.info("Circuit breaker: HALF_OPEN → CLOSED (probe succeeded)")
            self.state = CircuitState.CLOSED
            self.failure_count = 0

    def record_failure(self) -> None:
        self.failure_count += 1
        self.last_failure_time = time.time()
        if self.state == CircuitState.CLOSED and self.failure_count >= self.threshold:
            _logger.warning(
                "Circuit breaker: CLOSED → OPEN (%d consecutive failures, cooldown %ds)",
                self.failure_count, self.cooldown,
            )
            self.state = CircuitState.OPEN
        elif self.state == CircuitState.HALF_OPEN:
            _logger.warning("Circuit breaker: HALF_OPEN → OPEN (probe failed)")
            self.state = CircuitState.OPEN

    def is_allowed(self) -> bool:
        """检查当前是否允许请求通过"""
        if self.state == CircuitState.CLOSED:
            return True
        if self.state == CircuitState.HALF_OPEN:
            return True
        # OPEN: 检查冷却时间
        if time.time() - self.last_failure_time >= self.cooldown:
            _logger.info("Circuit breaker: OPEN → HALF_OPEN (cooldown expired)")
            self.state = CircuitState.HALF_OPEN
            return True
        return False

    @property
    def status(self) -> dict:
        return {
            "state": self.state.value,
            "failure_count": self.failure_count,
            "last_failure": self.last_failure_time,
            "last_success": self.last_success_time,
        }


@dataclass
class ModelFallbackChain:
    """模型回退链

    按优先级链依次尝试模型，直到成功或全部失败。
    结合 CircuitBreaker: 熔断的模型自动跳过。
    """

    primary_model: str
    fallback_models: list[str] = field(default_factory=list)
    _circuits: dict[str, CircuitBreaker] = field(default_factory=dict)

    @classmethod
    def from_settings(cls, primary: str) -> "ModelFallbackChain":
        settings = get_settings()
        fallbacks = [
            m.strip() for m in settings.model_fallback_chain.split(",")
            if m.strip() and m.strip() != primary
        ]
        return cls(primary_model=primary, fallback_models=fallbacks)

    def _get_circuit(self, model_id: str) -> CircuitBreaker:
        if model_id not in self._circuits:
            self._circuits[model_id] = CircuitBreaker.from_settings()
        return self._circuits[model_id]

    def allowed_models(self) -> list[str]:
        """返回所有未被熔断的模型列表 (按优先级)"""
        models = [self.primary_model] + self.fallback_models
        return [m for m in models if self._get_circuit(m).is_allowed()]

    def record_success(self, model_id: str) -> None:
        self._get_circuit(model_id).record_success()

    def record_failure(self, model_id: str) -> None:
        self._get_circuit(model_id).record_failure()

    def next_model(self, current_model: str, error: Exception) -> str | None:
        """获取下一个可用的回退模型

        Args:
            current_model: 当前失败的模型
            error: 导致失败的异常

        Returns:
            下一个可用模型 ID，或无可用模型时返回 None
        """
        self.record_failure(current_model)

        retryable, error_type = classify_error(error)
        _logger.info(
            "Model %s failed (type=%s retryable=%s), searching fallback...",
            current_model, error_type, retryable,
        )

        available = self.allowed_models()
        try:
            idx = available.index(current_model)
            next_idx = idx + 1
        except ValueError:
            next_idx = 0

        if next_idx < len(available):
            next_model = available[next_idx]
            _logger.info("Falling back from %s → %s", current_model, next_model)
            return next_model

        _logger.error("No available fallback models after %s", current_model)
        return None

    def get_circuit_status(self) -> dict[str, dict]:
        return {mid: self._get_circuit(mid).status for mid in self._circuits}
