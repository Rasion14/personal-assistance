"""重试管理器

指数退避 + 随机抖动重试。
区分可重试/不可重试错误类型。
"""

from __future__ import annotations

import asyncio
import logging
import random
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from agent_platform.config import get_settings

_logger = logging.getLogger("agent_platform.retry")


# 错误分类: (错误关键词, 是否可重试, 错误类型标签)
_ERROR_PATTERNS: list[tuple[str, bool, str]] = [
    ("rate", True, "rate_limit"),
    ("429", True, "rate_limit"),
    ("throttl", True, "rate_limit"),
    ("quota", True, "rate_limit"),
    ("timeout", True, "timeout"),
    ("timed out", True, "timeout"),
    ("context length", False, "context_length"),
    ("context window", False, "context_length"),
    ("token", False, "context_length"),
    ("too long", False, "context_length"),
    ("server error", True, "server_error"),
    ("500", True, "server_error"),
    ("502", True, "server_error"),
    ("503", True, "server_error"),
    ("504", True, "server_error"),
    ("unavailable", True, "server_error"),
    ("connection", True, "connection_error"),
    ("network", True, "connection_error"),
    ("dns", True, "connection_error"),
    ("unauthorized", False, "auth_error"),
    ("401", False, "auth_error"),
    ("403", False, "auth_error"),
    ("invalid", False, "invalid_request"),
    ("400", False, "invalid_request"),
    ("not found", False, "invalid_request"),
]


def classify_error(error: Exception) -> tuple[bool, str]:
    """分类错误: (是否可重试, 错误类型标签)

    Args:
        error: 异常对象

    Returns:
        (retryable, error_type)
    """
    msg = str(error).lower()
    for pattern, retryable, etype in _ERROR_PATTERNS:
        if pattern in msg:
            return retryable, etype
    return True, "unknown"  # 未知错误保守处理: 可重试


@dataclass
class RetryManager:
    """指数退避重试管理器

    退避公式: delay = min(base_delay * 2^attempt + jitter, max_delay)
    其中 jitter = random(0, base_delay)
    """

    max_retries: int = 3
    base_delay: float = 1.0
    max_delay: float = 30.0
    jitter: bool = True

    _attempt: int = field(default=0, init=False)

    @classmethod
    def from_settings(cls) -> "RetryManager":
        settings = get_settings()
        return cls(
            max_retries=settings.retry_max_attempts,
            base_delay=settings.retry_base_delay,
            max_delay=settings.retry_max_delay,
        )

    def reset(self) -> None:
        self._attempt = 0

    @property
    def attempt(self) -> int:
        return self._attempt

    def next_delay(self) -> float:
        """计算下一次重试的等待时间"""
        delay = min(
            self.base_delay * (2 ** self._attempt),
            self.max_delay,
        )
        if self.jitter:
            delay += random.uniform(0, self.base_delay)
        self._attempt += 1
        return delay

    async def execute(
        self,
        fn: Callable,
        *args,
        on_retry: Callable | None = None,
        on_error: Callable | None = None,
        **kwargs,
    ) -> Any:
        """执行业务函数，自动重试

        Args:
            fn: 异步业务函数
            *args, **kwargs: 传入 fn 的参数
            on_retry: 重试回调 (attempt, delay, error) -> None
            on_error: 最终失败回调 (error) -> None

        Returns:
            fn 的返回值

        Raises:
            最后一次的错误 (不可重试时直接抛出)
        """
        self.reset()
        last_error: Exception | None = None

        for attempt_num in range(self.max_retries + 1):
            try:
                return await fn(*args, **kwargs)
            except Exception as e:
                last_error = e
                retryable, error_type = classify_error(e)

                if not retryable:
                    _logger.warning(
                        "Non-retryable error type=%s: %s",
                        error_type, str(e)[:200],
                    )
                    raise

                if attempt_num >= self.max_retries:
                    _logger.error(
                        "Max retries (%d) exhausted for error type=%s: %s",
                        self.max_retries, error_type, str(e)[:200],
                    )
                    if on_error:
                        on_error(e)
                    raise

                delay = self.next_delay()
                _logger.info(
                    "Retry %d/%d after %.1fs (type=%s): %s",
                    attempt_num + 1, self.max_retries, delay, error_type, str(e)[:150],
                )
                if on_retry:
                    on_retry(attempt_num + 1, delay, e)
                await asyncio.sleep(delay)

        # 理论上不会到这里
        if last_error:
            raise last_error
