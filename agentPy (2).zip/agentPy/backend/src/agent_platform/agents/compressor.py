"""上下文压缩器

当对话上下文超过模型限制时，将早期消息压缩为摘要，减少 token 使用量。

策略:
- 保留 system prompt + 最近 N 轮完整对话
- 更早的消息用简要摘要替代
- 工具调用结果优先丢弃 (保留调用名和关键结果)
"""

from __future__ import annotations

import logging

from agent_platform.config import get_settings

_logger = logging.getLogger("agent_platform.compressor")


class ContextCompressor:
    """对话上下文压缩器

    不需要额外的 LLM 调用 — 使用基于规则的压缩:
    1. 保留最近 N 条消息
    2. 早期消息: 用户消息截断到 100 字，AI 回复替换为 [已压缩]
    3. 丢弃非关键工具调用详情
    """

    def __init__(
        self,
        keep_recent: int = 4,          # 保留最近 N 条消息不变
        max_truncate: int = 150,       # 早期消息最大长度
        max_total_chars: int = 50000,  # 总字符数上限 (≈12k tokens)
    ) -> None:
        self.keep_recent = keep_recent
        self.max_truncate = max_truncate
        self.max_total_chars = max_total_chars

    @classmethod
    def from_settings(cls) -> "ContextCompressor":
        settings = get_settings()
        return cls()

    def compress(self, message_history: list[dict]) -> list[dict]:
        """压缩消息历史

        Args:
            message_history: [{role, content, ...}, ...] 格式的消息列表

        Returns:
            压缩后的消息列表
        """
        if len(message_history) <= self.keep_recent:
            return message_history

        total_chars = sum(len(m.get("content", "")) for m in message_history)
        if total_chars <= self.max_total_chars:
            return message_history  # 未超限，无需压缩

        _logger.info(
            "Compressing context: %d messages, %d chars → target ≤%d",
            len(message_history), total_chars, self.max_total_chars,
        )

        # 分离: system 消息 + 最近 N 条 + 早期消息
        system_msgs = [m for m in message_history if m.get("role") == "system"]
        non_system = [m for m in message_history if m.get("role") != "system"]

        recent = non_system[-self.keep_recent:]
        early = non_system[:-self.keep_recent]

        # 压缩早期消息
        compressed_early = []
        for msg in early:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if role == "user":
                compressed_early.append({
                    **msg,
                    "content": content[:self.max_truncate] + ("..." if len(content) > self.max_truncate else ""),
                    "_compressed": True,
                })
            elif role == "assistant":
                # AI 回复: 保留首句 (通常包含要点)
                first_sentence = content.split("。")[0][:self.max_truncate]
                compressed_early.append({
                    **msg,
                    "content": f"[已压缩] {first_sentence}...",
                    "_compressed": True,
                })
            elif role == "tool":
                # 工具消息: 只保留名称
                compressed_early.append({
                    **msg,
                    "content": "[工具调用结果已省略]",
                    "_compressed": True,
                })

        result = system_msgs + compressed_early + recent

        new_total = sum(len(m.get("content", "")) for m in result)
        _logger.info(
            "Context compressed: %d→%d messages, %d→%d chars (%.0f%% reduction)",
            len(message_history), len(result),
            total_chars, new_total,
            (1 - new_total / max(total_chars, 1)) * 100,
        )

        return result

    def should_compress(self, error: Exception) -> bool:
        """判断错误是否因上下文过长导致"""
        msg = str(error).lower()
        indicators = ["context length", "context window", "token", "too long", "too large"]
        return any(ind in msg for ind in indicators)
