"""生命周期钩子 (pydantic-ai 2.11 兼容)

使用 Hooks capability 在 Agent 运行各阶段记录日志。
pydantic-ai 2.11 的 RunContext 不再暴露 deps/extra/metadata 写权限，
因此钩子仅做纯日志记录，不依赖 ctx 状态。
"""

from __future__ import annotations

from typing import Any

from pydantic_ai import RunContext
from pydantic_ai.capabilities.hooks import Hooks
from pydantic_ai.models import ModelRequestContext

_logger = __import__("logging").getLogger("agent_platform.hooks")

agent_hooks = Hooks()


@agent_hooks.on.before_run
async def on_before_run(ctx: RunContext[Any]) -> None:
    _logger.info("Agent run started run_id=%s", ctx.run_id)


@agent_hooks.on.before_model_request
async def on_before_model_request(
    ctx: RunContext[Any],
    request_context: ModelRequestContext,
) -> ModelRequestContext:
    _logger.debug("Model request: %d messages", len(request_context.messages))
    return request_context


@agent_hooks.on.after_model_request
async def on_after_model_request(
    ctx: RunContext[Any],
    request_context: ModelRequestContext,
) -> None:
    _logger.debug("Model response received")


@agent_hooks.on.after_run
async def on_after_run(ctx: RunContext[Any]) -> None:
    _logger.info("Agent run completed run_id=%s", ctx.run_id)


@agent_hooks.on.run_error
async def on_run_error(ctx: RunContext[Any], error: Exception) -> None:
    _logger.error(
        "Agent error run_id=%s type=%s msg=%.200s",
        ctx.run_id, type(error).__name__, str(error),
    )


def get_agent_hooks() -> Hooks:
    return agent_hooks
