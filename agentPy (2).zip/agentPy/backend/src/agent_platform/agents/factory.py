"""Agent 工厂

两层 API:
- create_agent()          — 基础 Agent + Deps 构造
- create_resilient_agent() — 带韧性包装: 并发控制 + 重试 + 回退 + 压缩

能力开关由 Settings 配置驱动。
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

from pydantic_ai import Agent

from agent_platform.agents.compressor import ContextCompressor
from agent_platform.agents.concurrency import get_concurrency_controller
from agent_platform.agents.deps import AgentDeps
from agent_platform.agents.events import ErrorEvent, default_error_callback
from agent_platform.agents.fallback import ModelFallbackChain
from agent_platform.agents.retry import RetryManager, classify_error
from agent_platform.agents.system_prompt import build_system_instructions
from agent_platform.config import get_settings
from agent_platform.models.resolver import resolve_model
from agent_platform.skills.registry import SkillRegistry

_logger = logging.getLogger("agent_platform.factory")

# ====================================================================
# Agent 缓存: 按规格缓存 Agent 实例，避免重复创建
# ====================================================================
# key: (model_id, persona_id, tools_frozenset, skills_frozenset, thinking, cross_session, date)
from datetime import date as _date
_agent_cache: dict[tuple, tuple[Agent, AgentDeps]] = {}
_MAX_CACHE_SIZE = 50


def _cache_key(
    model_id: str, persona_id: str,
    enabled_tools: list[str] | None,
    enabled_skills: list[str] | None,
    enable_thinking: bool,
    enable_cross_session: bool,
) -> tuple:
    """构造缓存键，None 表示"全部"，空元组表示"无" """
    tools_key = tuple(sorted(enabled_tools)) if enabled_tools is not None else None
    skills_key = tuple(sorted(enabled_skills)) if enabled_skills is not None else None
    return (model_id, persona_id, tools_key, skills_key, enable_thinking, enable_cross_session, str(_date.today()))


def _cache_prune() -> None:
    """缓存条目过多时清理最旧的一半"""
    if len(_agent_cache) > _MAX_CACHE_SIZE:
        remove_count = len(_agent_cache) // 2
        for _ in range(remove_count):
            _agent_cache.pop(next(iter(_agent_cache)), None)
        _logger.info("Agent cache pruned, remaining=%d", len(_agent_cache))


def create_agent(
    model_id: str = "anthropic:claude-sonnet-4-6",
    conversation_id: str = "",
    persona_id: str = "default",
    skill_registry: SkillRegistry | None = None,
    enable_thinking: bool | None = None,
    enable_memory: bool | None = None,
    user_message: str = "",
    message_history: list[dict] | None = None,
    enabled_tools: list[str] | None = None,
    enabled_skills: list[str] | None = None,
    enable_cross_session: bool = False,
) -> tuple[Agent[AgentDeps, str], AgentDeps]:
    """创建 Agent 实例和依赖对象

    Args:
        enabled_tools: 本次请求启用的工具名列表。
                       None = 使用全部工具，[] = 不使用任何工具。
        enabled_skills: 本次请求启用的 skill 名列表。
                        None = 使用 registry 全局配置，[] = 不使用任何 skill。
        enable_cross_session: 是否启用跨会话记忆检索。

    Returns:
        (agent, deps) — deps 需要传入 agent.run(user_prompt, deps=deps)
    """
    settings = get_settings()

    if enable_thinking is None:
        enable_thinking = settings.enable_thinking

    # ---- Agent 缓存: 相同规格返回缓存实例 ----
    ck = _cache_key(model_id, persona_id, enabled_tools, enabled_skills, enable_thinking, enable_cross_session)
    if ck in _agent_cache:
        cached_agent, _cached_deps = _agent_cache[ck]
        # 更新 deps 中与请求相关的动态字段
        _cached_deps.conversation_id = conversation_id
        _logger.debug("Agent cache HIT key=%s", ck)
        return cached_agent, _cached_deps

    deps = AgentDeps(
        model_id=model_id,
        conversation_id=conversation_id,
        enable_thinking=enable_thinking,
    )
    deps.extra_context["sandbox_dir"] = str(settings.sandbox_path)

    # ---- 工具: 按 enabled_tools 过滤 ----
    from agent_platform.tools.base import get_all_tools
    all_tools = get_all_tools()

    if enabled_tools is not None:
        tools = [t for t in all_tools if t.name in enabled_tools]
        _logger.info("Tools filtered: requested=%s found=%d", enabled_tools, len(tools))
    else:
        tools = list(all_tools)
        _logger.info("Tools: using all %d tools (default)", len(tools))

    # ---- Skill: 按 enabled_skills 决定使用哪些 skill 指令 ----
    if enabled_skills is not None:
        skill_names = enabled_skills
        skill_instructions_map: dict[str, str] = {}
        missing_skills: list[str] = []
        if skill_registry:
            for skill in skill_registry.get_all():
                if skill.name in enabled_skills and skill.is_available():
                    skill_instructions_map[skill.name] = skill.instructions
                    deps.enabled_skills.append(skill.name)
            for sn in enabled_skills:
                if sn not in skill_instructions_map:
                    missing_skills.append(sn)
        if missing_skills:
            from agent_platform.skills.loader import load_skill_from_directory
            from pathlib import Path as _Path
            skills_root = settings.skills_data_path
            for sn in missing_skills:
                for sub in ("uploaded", "installed", ""):
                    candidate = skills_root / sub / sn if sub else skills_root / sn
                    if candidate.is_dir():
                        loaded = load_skill_from_directory(candidate)
                        if not loaded.get("error"):
                            skill_instructions_map[sn] = loaded.get("instructions", "")
                            deps.enabled_skills.append(sn)
                            _logger.info("Direct-loaded skill {name} from {path}", name=sn, path=str(candidate))
                            break
    else:
        skill_names = []
        skill_instructions_map = {}
        if skill_registry:
            skill_names = skill_registry.get_enabled_names()
            for skill in skill_registry.get_enabled():
                skill_instructions_map[skill.name] = skill.instructions
            deps.enabled_skills = list(skill_names)

    # 跨会话记忆: enable_cross_session=True 时传递给 system_prompt
    _mem = enable_cross_session if enable_cross_session else (enable_memory if enable_memory is not None else None)

    instructions = build_system_instructions(
        persona_id=persona_id,
        enabled_skills=skill_names,
        skill_instructions=skill_instructions_map,
        user_message=user_message,
        enable_memory=_mem,
    )

    resolved_model = resolve_model(model_id)
    agent = Agent(
        model=resolved_model,
        name="Rasion",
        system_prompt=instructions,
        tools=tools,
        deps_type=AgentDeps,
    )

    # 缓存新建的 Agent
    _agent_cache[ck] = (agent, deps)
    _cache_prune()
    _logger.info("Agent cache MISS — created new agent (cache size=%d)", len(_agent_cache))

    return agent, deps


# ====================================================================
# 韧性 Agent 创建
# ====================================================================

async def create_resilient_agent(
    model_id: str = "anthropic:claude-sonnet-4-6",
    conversation_id: str = "",
    persona_id: str = "default",
    skill_registry: SkillRegistry | None = None,
    enable_thinking: bool | None = None,
    enable_memory: bool | None = None,
    user_message: str = "",
    message_history: list[dict] | None = None,
    enabled_tools: list[str] | None = None,
    enabled_skills: list[str] | None = None,
    enable_cross_session: bool = False,
    on_error_event: Any | None = default_error_callback,
    acquire_timeout: float | None = 30.0,
) -> tuple[Agent[AgentDeps, str], AgentDeps]:
    """创建带韧性包装的 Agent + Deps

    Args:
        enabled_tools: 本次启用的工具名列表 (None=全部, []=无)
        enabled_skills: 本次启用的 skill 名列表 (None=全局配置, []=无)
        enable_cross_session: 是否启用跨会话记忆检索

    Returns:
        (agent, deps) — 调用方使用 await agent.run(msg, deps=deps)
    """
    settings = get_settings()
    start_time = time.time()

    concurrency = get_concurrency_controller()
    await concurrency.acquire(timeout=acquire_timeout)

    fallback = ModelFallbackChain.from_settings(model_id)
    compressor = ContextCompressor()
    retry = RetryManager.from_settings()

    history = list(message_history) if message_history else []
    current_model = model_id
    retry_count = 0

    # 闭包捕获，供内部重试循环使用
    _enabled_tools = enabled_tools
    _enabled_skills = enabled_skills
    _enable_cross_session = enable_cross_session

    def _emit_event(error_type: str, error_msg: str, action: str, fb_model: str | None = None):
        event = ErrorEvent(
            model_id=current_model, error_type=error_type, error_message=error_msg,
            attempt=retry_count, action=action,
            elapsed=time.time() - start_time, fallback_model=fb_model,
            conversation_id=conversation_id,
        )
        if on_error_event:
            try: on_error_event(event)
            except Exception: pass

    try:
        while True:
            try:
                agent, deps = create_agent(
                    model_id=current_model, conversation_id=conversation_id,
                    persona_id=persona_id, skill_registry=skill_registry,
                    enable_thinking=enable_thinking, enable_memory=enable_memory,
                    user_message=user_message, message_history=history,
                    enabled_tools=_enabled_tools,
                    enabled_skills=_enabled_skills,
                    enable_cross_session=_enable_cross_session,
                )
                fallback.record_success(current_model)
                return agent, deps

            except Exception as e:
                retryable, error_type = classify_error(e)
                _emit_event(error_type, str(e), "evaluating")

                if error_type == "context_length" and settings.context_compression_enabled:
                    compressed = compressor.compress(history)
                    if len(compressed) < len(history):
                        _emit_event(error_type, str(e), "compress")
                        history = compressed
                        retry_count += 1
                        continue

                if retryable and retry_count < retry.max_retries:
                    delay = retry.next_delay()
                    _emit_event(error_type, str(e), "retry")
                    await asyncio.sleep(delay)
                    retry_count += 1
                    continue

                next_model = fallback.next_model(current_model, e)
                if next_model:
                    _emit_event(error_type, str(e), "fallback", next_model)
                    current_model = next_model
                    retry = RetryManager.from_settings()
                    retry_count = 0
                    history = list(message_history) if message_history else []
                    continue

                _emit_event(error_type, str(e), "fail")
                raise RuntimeError(
                    f"所有模型均不可用 (最后尝试: {current_model}, 原因: {error_type})"
                ) from e
    finally:
        concurrency.release()
