"""系统指令模板

根据已启用的 Skill、选中的人设 (persona_id) 和记忆上下文动态构建系统指令。
"""

from __future__ import annotations

import logging
from datetime import date

from agent_platform.agents.persona import load_persona
from agent_platform.conversations.memory import get_relevant_memories
from agent_platform.config import get_settings

_logger = logging.getLogger("agent_platform.system_prompt")


def build_system_instructions(
    persona_id: str = "default",
    enabled_skills: list[str] | None = None,
    skill_instructions: dict[str, str] | None = None,
    user_message: str = "",
    enable_memory: bool | None = None,
) -> str:
    """构建完整的系统指令

    Args:
        persona_id: 人设标识
        enabled_skills: 已启用的 Skill 名称列表
        skill_instructions: Skill 名称 -> 指令文本的映射
        user_message: 当前用户消息 (用于检索相关记忆)
        enable_memory: 是否启用跨会话记忆 (None=使用配置默认值)

    Returns:
        完整的系统指令字符串
    """
    settings = get_settings()
    parts: list[str] = []

    # ---- 1. 加载人设配置 ----
    persona_text = load_persona(persona_id)
    parts.append(persona_text)
    _logger.info("build_system_instructions: persona=%s, text_len=%d", persona_id, len(persona_text))

    # ---- 2. 核心行为准则 ----
    use_memory = enable_memory if enable_memory is not None else False
    memory_mode = "跨会话记忆: 已启用 — 你将能检索历史会话摘要辅助回答" if use_memory else "跨会话记忆: 已关闭 — 你只关注当前会话的对话历史"

    parts.append(f"""
核心行为准则:
1. 在回答前仔细分析用户意图，必要时使用工具获取准确信息。
2. 对于复杂任务，先制定计划再逐步执行。
3. 当前日期: {date.today().isoformat()}
4. 无论使用何种语气或风格，解决问题的能力始终是第一优先级。
5. {memory_mode}
""")

    # ---- 3. 跨会话记忆 (仅当用户主动开启) ----
    if use_memory and user_message:
        memories = get_relevant_memories(user_message, max_results=3)
        if memories:
            parts.append(memories)
            _logger.info("build_system_instructions: cross-session memories loaded for '%s'", user_message[:50])

    # ---- 4. 注入 Skill 指令 ----
    if enabled_skills and skill_instructions:
        skill_text = "\n已启用的 Skill 能力:\n"
        for skill_name in enabled_skills:
            if skill_name in skill_instructions:
                inst = skill_instructions[skill_name]
                skill_text += f"\n--- {skill_name} ---\n"
                skill_text += inst
                _logger.info("build_system_instructions: skill=%s, instr_len=%d", skill_name, len(inst))
        parts.append(skill_text)
    else:
        _logger.info("build_system_instructions: no skills enabled (enabled_skills=%s, has_instructions=%s)",
                     enabled_skills, bool(skill_instructions))

    return "\n".join(parts)
