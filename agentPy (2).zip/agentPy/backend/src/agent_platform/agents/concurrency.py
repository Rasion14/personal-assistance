"""并发控制器

使用 asyncio.Semaphore 限制同时执行的 Agent 数量。
超出限制的请求排队等待 (FIFO)，避免后端资源耗尽。
"""

from __future__ import annotations

import asyncio
import time
import logging

from agent_platform.config import get_settings

_logger = logging.getLogger("agent_platform.concurrency")


class ConcurrencyController:
    """并发控制器

    全局单例，所有 Agent 请求共享同一个信号量。
    支持超时等待和队列长度监控。
    """

    def __init__(self, max_concurrent: int | None = None) -> None:
        settings = get_settings()
        self._max = max_concurrent or settings.max_concurrent_requests
        self._semaphore = asyncio.Semaphore(self._max)
        self._waiting = 0
        self._active = 0

    @property
    def max_concurrent(self) -> int:
        return self._max

    @property
    def waiting_count(self) -> int:
        return self._waiting

    @property
    def active_count(self) -> int:
        return self._active

    async def acquire(self, timeout: float | None = None) -> bool:
        """获取执行槽位

        Args:
            timeout: 最大等待秒数，None=无限等待

        Returns:
            True=已获取, False=超时

        Raises:
            asyncio.TimeoutError: 等待超时
        """
        self._waiting += 1
        try:
            if timeout is not None:
                try:
                    await asyncio.wait_for(
                        self._semaphore.acquire(), timeout=timeout
                    )
                except asyncio.TimeoutError:
                    self._waiting -= 1
                    _logger.warning(
                        "Concurrency acquire timeout after %.1fs (waiting=%d active=%d)",
                        timeout, self._waiting, self._active,
                    )
                    raise
                self._waiting -= 1
                self._active += 1
                return True
            else:
                await self._semaphore.acquire()
                self._waiting -= 1
                self._active += 1
                return True
        except asyncio.TimeoutError:
            raise

    def release(self) -> None:
        """释放执行槽位"""
        self._active = max(0, self._active - 1)
        self._semaphore.release()

    async def __aenter__(self):
        await self.acquire()
        return self

    async def __aexit__(self, *args):
        self.release()


# 全局单例
_controller: ConcurrencyController | None = None


def get_concurrency_controller() -> ConcurrencyController:
    global _controller
    if _controller is None:
        _controller = ConcurrencyController()
    return _controller
