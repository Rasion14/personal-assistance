"""多角色人设配置加载器

管理 backend/config/personas/ 目录下的所有 .yaml 人设文件。
支持 list（列出所有可用人设）和 load（加载指定人设并渲染为自然语言指令）。

每个 .yaml 文件代表一个 Persona，文件名即为 persona_id。
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import yaml

from agent_platform.config import get_settings

_logger = logging.getLogger("agent_platform.persona")


def list_personas(persona_dir: Path | None = None) -> list[dict[str, Any]]:
    """列出所有可用人设的摘要信息（供前端展示）

    Args:
        persona_dir: persona 文件目录，默认从 Settings 读取

    Returns:
        [{id, name, display_name, icon, color, role, tagline}, ...]
    """
    if persona_dir is None:
        settings = get_settings()
        persona_dir = settings.persona_path

    if not persona_dir.exists():
        return [_fallback_summary()]

    personas: list[dict[str, Any]] = []
    for f in sorted(persona_dir.glob("*.yaml")):
        try:
            raw = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
            personas.append({
                "id": raw.get("id", f.stem),
                "name": raw.get("name", f.stem),
                "display_name": raw.get("display_name", f.stem),
                "icon": raw.get("icon", "fa-robot"),
                "color": raw.get("color", "#22d3ee"),
                "role": raw.get("identity", {}).get("role", ""),
                "tagline": raw.get("identity", {}).get("tagline", ""),
            })
        except Exception:
            continue

    return personas if personas else [_fallback_summary()]


def load_persona(persona_id: str = "default", persona_dir: Path | None = None) -> str:
    """加载指定人设并渲染为自然语言系统指令

    Args:
        persona_id: 人设标识 (对应文件名，如 "default"、"maid")
        persona_dir: persona 文件目录，默认从 Settings 读取

    Returns:
        该人设的自然语言描述，可直接拼接到 system prompt
    """
    if persona_dir is None:
        settings = get_settings()
        persona_dir = settings.persona_path

    file_path = persona_dir / f"{persona_id}.yaml"
    _logger.info("load_persona: persona_id=%s path=%s exists=%s",
                 persona_id, file_path, file_path.exists())

    if not file_path.exists():
        _logger.warning("load_persona: 人设文件不存在 %s, 使用默认空人设", file_path)
        return _render_instructions({})

    try:
        raw = yaml.safe_load(file_path.read_text(encoding="utf-8")) or {}
        result = _render_instructions(raw)
        _logger.info("load_persona: 已加载人设 %s, 指令长度=%d", persona_id, len(result))
        return result
    except Exception as e:
        _logger.error("load_persona: 加载失败 %s: %s", file_path, e)
        return _render_instructions({})


def _render_instructions(persona: dict[str, Any]) -> str:
    """将结构化人设转换为自然语言指令"""
    lines: list[str] = []

    identity = persona.get("identity", {})
    tone = persona.get("tone", {})
    behavior = persona.get("behavior", {})
    constraints = persona.get("constraints", {})

    # ---- 身份 (带强制前缀) ----
    name = identity.get("name", "Agent")
    role = identity.get("role", "智能助手")
    tagline = identity.get("tagline", "")
    backstory = identity.get("backstory", "")
    persona_id_value = persona.get("id", "")

    # 非默认人设添加强制声明
    if persona_id_value and persona_id_value != "default":
        lines.append(f"【重要：你现在必须扮演 {name}，严格使用该角色的语气、风格和行为方式回复，无论对话历史如何。】")
    lines.append(f"你是 {name}，一名{role}。{tagline}")
    if backstory:
        lines.append(backstory.strip())

    # ---- 语气 ----
    formality_guide = {
        "casual": "使用自然、口语化的表达方式，可以适当使用日常用语",
        "professional": "使用专业、正式的表达方式，措辞严谨",
        "academic": "使用学术风格，引用清晰、逻辑严密",
    }
    warmth_guide = {
        "cold": "保持冷静客观，不表达情感",
        "neutral": "保持中性语调",
        "friendly": "保持友好、亲切的态度",
        "enthusiastic": "保持热情、积极的态度，充满活力",
    }
    humor_guide = {
        "none": "不使用幽默",
        "occasional": "可以偶尔使用适度的幽默",
        "witty": "可以展现机智、俏皮和风趣",
    }
    concise_guide = {
        "terse": "回复尽量简短，少说废话",
        "balanced": "在简洁和详细之间保持平衡",
        "verbose": "可以详细展开，提供丰富背景",
    }

    tone_lines = [
        formality_guide.get(tone.get("formality", "casual"), ""),
        warmth_guide.get(tone.get("warmth", "friendly"), ""),
        humor_guide.get(tone.get("humor", "none"), ""),
        concise_guide.get(tone.get("conciseness", "balanced"), ""),
    ]
    lines.append("语气要求: " + "；".join(t for t in tone_lines if t) + "。")

    # ---- 行为 ----
    lang = behavior.get("language", "zh-CN")
    lines.append(f"始终使用{lang}回复用户，除非用户使用其他语言。")

    max_len = behavior.get("max_response_length", 2000)
    lines.append(f"单次回复长度控制在{max_len}字以内。")

    code_style = behavior.get("code_style", "")
    if code_style:
        lines.append(f"代码输出规范: {code_style.strip()}")

    tool_behavior = behavior.get("default_tool_behavior", "")
    if tool_behavior:
        lines.append(f"工具使用: {tool_behavior.strip()}")

    emoji_guide = {
        "none": "不使用 emoji",
        "minimal": "谨慎使用 emoji，仅在强调时使用",
        "moderate": "适度使用 emoji 增强表达",
        "liberal": "可以自由使用 emoji 丰富表达，让回复更加生动可爱",
    }
    emoji = behavior.get("emoji_usage", "moderate")
    lines.append(f"Emoji 使用: {emoji_guide.get(emoji, emoji_guide['moderate'])}。")

    # ---- 约束 ----
    forbidden = constraints.get("forbidden", [])
    if forbidden:
        lines.append("严格禁止: " + "；".join(forbidden) + "。")

    safety = constraints.get("safety_rules", [])
    if safety:
        lines.append("安全规则: " + "；".join(safety) + "。")

    scope = constraints.get("scope_rules", [])
    if scope:
        lines.append("范围规则: " + "；".join(scope) + "。")

    # ---- 自定义指令 ----
    custom = persona.get("custom_instructions", [])
    for ci in custom:
        lines.append(ci)

    return "\n".join(lines)


def _fallback_summary() -> dict[str, Any]:
    """默认回退摘要"""
    return {
        "id": "default",
        "name": "Rasion",
        "display_name": "Rasion · 默认助手",
        "icon": "fa-robot",
        "color": "#22d3ee",
        "role": "AI 智能助手",
        "tagline": "高效、可靠、优雅",
    }
