"""Agent 依赖类定义

定义注入到 RunContext 的依赖对象，供工具和钩子使用。
通过 deps_type=AgentDeps 注入，工具可通过 ctx.deps 访问。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class AgentDeps:
    """Agent 运行时依赖

    每个 Agent run 都会创建一个 AgentDeps 实例，
    通过 RunContext[AgentDeps] 传递给所有工具和钩子。
    """

    # 当前使用的模型标识 (如 "anthropic:claude-sonnet-4-6")
    model_id: str = "anthropic:claude-sonnet-4-6"

    # 当前对话 ID
    conversation_id: str = ""

    # 是否启用 Thinking 能力
    enable_thinking: bool = False

    # 已启用的 Skill 名称列表
    enabled_skills: list[str] = field(default_factory=list)

    # 自定义额外上下文 (供 Skill 注入)
    extra_context: dict[str, Any] = field(default_factory=dict)

    def add_skill_context(self, skill_name: str, context: dict[str, Any]) -> None:
        """注入 Skill 的额外上下文"""
        if skill_name not in self.enabled_skills:
            self.enabled_skills.append(skill_name)
        self.extra_context[skill_name] = context
