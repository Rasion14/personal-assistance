"""错误事件数据模型

每当 Agent 执行中发生错误时，生成 ErrorEvent 供回调消费。
可用于日志记录、指标上报、告警推送等。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class ErrorEvent:
    """Agent 执行错误事件"""

    model_id: str                              # 当前使用的模型
    error_type: str                            # rate_limit | timeout | context_length | server_error | ...
    error_message: str                         # 原始错误消息 (截断)
    attempt: int = 0                           # 第几次尝试 (0=首次)
    action: str = "fail"                       # retry | fallback | compress | fail
    elapsed: float = 0.0                       # 从请求开始到此刻的耗时 (秒)
    fallback_model: str | None = None          # 回退到的模型 (如有)
    conversation_id: str = ""                  # 对话 ID
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> dict:
        return {
            "model_id": self.model_id,
            "error_type": self.error_type,
            "error_message": self.error_message[:300],
            "attempt": self.attempt,
            "action": self.action,
            "elapsed": round(self.elapsed, 2),
            "fallback_model": self.fallback_model,
            "conversation_id": self.conversation_id,
            "timestamp": self.timestamp,
        }


# 默认事件回调: 记录到日志
def default_error_callback(event: ErrorEvent) -> None:
    """默认错误事件处理 — 写入日志"""
    import logging
    _logger = logging.getLogger("agent_platform.events")
    _logger.warning(
        "Agent error event: model=%s type=%s action=%s attempt=%d fallback=%s elapsed=%.2f",
        event.model_id,
        event.error_type,
        event.action,
        event.attempt,
        event.fallback_model or "-",
        event.elapsed,
    )
