"""自定义 Provider 解析

支持 OpenAI 兼容的第三方 Provider (DeepSeek, Qwen 等)、Ollama、vLLM。
通过配置驱动的模型字符串解析，自动构建合适的 Model 实例。

pydantic-ai 2.x 中，模型字符串格式为 "provider:model_name"。
对于 OpenAI 兼容的第三方 API，需要创建 OpenAIModel 实例并传入 base_url 和 api_key。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import logfire

from agent_platform.config import get_settings

_logger = logging.getLogger("agent_platform.models.providers")


# ---------------------------------------------------------------------------
# 自定义 Provider 数据模型
# ---------------------------------------------------------------------------

@dataclass
class CustomProvider:
    """自定义 Provider 配置"""
    name: str                    # Provider 名称 (如 "deepseek", "qwen", "vllm")
    display_name: str            # 显示名称
    api_key: str = ""            # API Key
    base_url: str = ""           # API Base URL
    models: list[str] = field(default_factory=list)  # 模型列表
    description: str = ""        # Provider 描述


# ---------------------------------------------------------------------------
# 从配置解析 Provider
# ---------------------------------------------------------------------------

def parse_openai_compatible_providers() -> list[CustomProvider]:
    """解析 OPENAI_COMPATIBLE_PROVIDERS 环境变量

    格式: name:api_key:base_url:model1,model2,model3|name2:api_key2:base_url2:modelA,modelB

    示例:
        deepseek:sk-xxx:https://api.deepseek.com/v1:deepseek-chat,deepseek-reasoner|qwen:sk-yyy:https://dashscope.aliyuncs.com/compatible-mode/v1:qwen-max,qwen-plus
    """
    settings = get_settings()
    providers: list[CustomProvider] = []
    raw = settings.openai_compatible_providers.strip()
    if not raw:
        return providers

    # 按 | 分割多个 provider
    for entry in raw.split("|"):
        entry = entry.strip()
        if not entry:
            continue

        # 格式: name:api_key:base_url:model1,model2
        # URL 可能含 :// 和端口, 用从右向左解析
        try:
            # 1. 第一个 :  → name
            first = entry.index(":")
            name = entry[:first]
            rest = entry[first + 1:]

            # 2. 第二个 : → api_key
            second = rest.index(":")
            api_key = rest[:second]
            rest2 = rest[second + 1:]

            # 3. 最后一个 : → 分隔 base_url 和 models
            last = rest2.rindex(":")
            base_url = rest2[:last]
            models_str = rest2[last + 1:]
        except ValueError:
            _logger.warning("跳过格式不正确的 Provider 配置: %s", entry)
            continue

        models = [m.strip() for m in models_str.split(",") if m.strip()]

        # 自动生成显示名称
        display_name = name.upper() if len(name) <= 4 else name.title()
        provider = CustomProvider(
            name=name.strip(),
            display_name=display_name,
            api_key=api_key.strip(),
            base_url=base_url.strip(),
            models=models,
            description=f"OpenAI 兼容 Provider: {name}",
        )
        providers.append(provider)
        _logger.info(
            "Loaded custom provider %s with %d models: %s",
            provider.name, len(provider.models), provider.models,
        )

    return providers


def parse_ollama_providers() -> list[CustomProvider]:
    """解析 Ollama 配置

    OLLAMA_BASE_URL: Ollama 服务地址
    OLLAMA_MODELS: 逗号分隔的模型列表 (如 "llama3.2,qwen2.5:7b,codellama")
    """
    settings = get_settings()
    models_str = settings.ollama_models.strip()
    if not models_str:
        return []

    models = [m.strip() for m in models_str.split(",") if m.strip()]
    if not models:
        return []

    provider = CustomProvider(
        name="ollama",
        display_name="Ollama (Local)",
        api_key="",  # Ollama 无需 API Key
        base_url=settings.ollama_base_url,
        models=models,
        description="本地 Ollama 部署",
    )
    _logger.info("Loaded Ollama with %d models: %s", len(models), models)
    return [provider]


def parse_vllm_providers() -> list[CustomProvider]:
    """解析 vLLM 配置

    VLLM_BASE_URL: vLLM 服务地址
    VLLM_API_KEY: 可选的 API Key
    VLLM_MODELS: 逗号分隔的模型列表 (如 "my-custom-model-v1,my-model-v2")
    """
    settings = get_settings()
    models_str = settings.vllm_models.strip()
    if not models_str:
        return []

    models = [m.strip() for m in models_str.split(",") if m.strip()]
    if not models:
        return []

    provider = CustomProvider(
        name="vllm",
        display_name="vLLM (Local)",
        api_key=settings.vllm_api_key,
        base_url=settings.vllm_base_url,
        models=models,
        description="本地 vLLM 部署",
    )
    _logger.info("Loaded vLLM with %d models: %s", len(models), models)
    return [provider]


def get_all_custom_providers() -> list[CustomProvider]:
    """获取所有自定义 Provider（含 Ollama 和 vLLM）"""
    providers = parse_openai_compatible_providers()
    # Ollama 作为单独处理（使用 pydantic-ai 原生 ollama 协议）
    # vLLM 作为 OpenAI 兼容处理
    providers.extend(parse_vllm_providers())
    return providers


# ---------------------------------------------------------------------------
# 模型注册辅助
# ---------------------------------------------------------------------------

def generate_model_entries() -> list[dict]:
    """从配置生成所有可用模型条目（供 API 返回）

    Returns:
        [{id, provider, display_name, description, is_default}, ...]
    """
    from agent_platform.models.registry import AVAILABLE_MODELS
    settings = get_settings()

    entries: list[dict] = []
    seen_ids: set[str] = set()
    configured_default = settings.default_model

    # 内置模型
    for m in AVAILABLE_MODELS:
        d = m.to_dict()
        # 如果配置的默认模型匹配, 标记为 is_default
        if d["id"] == configured_default:
            d["is_default"] = True
        elif configured_default and configured_default != d["id"]:
            d["is_default"] = False  # 取消内置默认
        entries.append(d)
        seen_ids.add(m.id)

    # OpenAI 兼容 Providers
    for provider in parse_openai_compatible_providers():
        for model_name in provider.models:
            model_id = f"{provider.name}:{model_name}"
            if model_id in seen_ids:
                continue
            seen_ids.add(model_id)
            entries.append({
                "id": model_id,
                "provider": f"openai-compatible:{provider.name}",
                "display_name": f"{model_name} ({provider.display_name})",
                "description": provider.description,
                "is_default": model_id == configured_default,
            })

    # vLLM
    for provider in parse_vllm_providers():
        for model_name in provider.models:
            model_id = f"vllm:{model_name}"
            if model_id in seen_ids:
                continue
            seen_ids.add(model_id)
            entries.append({
                "id": model_id,
                "provider": "vllm",
                "display_name": f"{model_name} (vLLM)",
                "description": "本地 vLLM 部署模型",
                "is_default": model_id == configured_default,
            })

    # Ollama 模型 — 使用 pydantic-ai 原生 ollama 协议
    for provider in parse_ollama_providers():
        for model_name in provider.models:
            model_id = f"ollama:{model_name}"
            if model_id in seen_ids:
                continue
            seen_ids.add(model_id)
            entries.append({
                "id": model_id,
                "provider": "ollama",
                "display_name": f"{model_name} (Ollama Local)",
                "description": "本地 Ollama 部署模型",
                "is_default": model_id == configured_default,
            })

    return entries
