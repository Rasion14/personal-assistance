"""模型解析器 (pydantic-ai 2.11+)

将 model_id 字符串解析为 pydantic-ai 可用的 Model 实例。

对于内置 Provider (Anthropic, OpenAI, Google, Groq) 直接使用 model_id 字符串。
对于 vLLM 和 OpenAI 兼容的第三方 API，使用 OpenAIProvider + OpenAIChatModel。

pydantic-ai 2.11 变更:
  - 移除 OpenAIModel，改用 OpenAIChatModel
  - Provider 拆分到 pydantic_ai.providers.openai.OpenAIProvider
  - 支持 OpenAIModelProfile 精细控制模型行为
"""

from __future__ import annotations

import logging
from typing import Any

from agent_platform.config import get_settings
from agent_platform.models.providers import (
    parse_openai_compatible_providers,
    parse_vllm_providers,
)

_logger = logging.getLogger("agent_platform.models.resolver")


def resolve_model(model_id: str):
    """根据 model_id 返回 pydantic-ai 可用的模型

    Args:
        model_id: 模型标识 (如 "anthropic:claude-sonnet-4-6" 或 "qwen3")

    Returns:
        model_id 字符串 (内置provider) 或 OpenAIChatModel 实例 (自定义provider)
    """
    settings = get_settings()

    if ":" not in model_id:
        raise ValueError(
            f"无效的 model_id 格式: {model_id}。正确格式为 'provider:model_name'"
        )

    provider_name, model_name = model_id.split(":", 1)

    # ---- 1. 内置 Provider: 验证 Key 后返回 model_id 字符串 ----
    if _is_builtin_provider(provider_name):
        _check_builtin_key(provider_name, settings)
        return model_id

    # ---- 2. ollama: 原生支持 ----
    if provider_name == "ollama":
        return model_id

    # ---- 3. vLLM / OpenAI 兼容 Providers ----
    # 检查 vLLM
    for provider in parse_vllm_providers():
        if model_name in provider.models:
            return _create_chat_model(
                model_name=model_name,
                base_url=provider.base_url,
                api_key=provider.api_key or "not-needed",
            )

    # 检查 OpenAI 兼容自定义 Provider
    for provider in parse_openai_compatible_providers():
        if provider.name == provider_name or (
            provider_name == "openai" and model_name in provider.models
        ):
            return _create_chat_model(
                model_name=model_name,
                base_url=provider.base_url,
                api_key=provider.api_key,
            )

    # ---- 4. model_id 格式校验 ----
    if "://" in model_id or model_name.startswith("//"):
        raise ValueError(
            f"无效的 model_id: {model_id}。"
            f"请检查 .env 中 OPENAI_COMPATIBLE_PROVIDERS 格式: name:api_key:base_url:model1,model2"
        )

    # ---- 5. 回退: 尝试作为字符串给内置 provider ----
    _logger.warning("Unknown provider '%s', trying as raw model_id", provider_name)
    return model_id


def _check_builtin_key(provider_name: str, settings) -> None:
    """检查内置 Provider 的 API Key 是否已配置"""
    key_map = {
        "anthropic": settings.anthropic_api_key,
        "openai": settings.openai_api_key,
        "google": settings.google_genai_api_key,
        "google-gla": settings.google_genai_api_key,
        "google-vertex": settings.google_genai_api_key,
        "groq": settings.groq_api_key,
        "mistral": "",  # Mistral 支持无 Key 本地部署
        "cohere": "",
        "bedrock": "",
        "azure": "",
    }
    key = key_map.get(provider_name.lower())
    if key is not None and key == "" and provider_name.lower() not in ("mistral", "cohere", "bedrock", "azure"):
        names = {
            "anthropic": "ANTHROPIC_API_KEY",
            "openai": "OPENAI_API_KEY",
            "google": "GOOGLE_GENAI_API_KEY",
            "google-gla": "GOOGLE_GENAI_API_KEY",
            "google-vertex": "GOOGLE_GENAI_API_KEY",
            "groq": "GROQ_API_KEY",
        }
        env_name = names.get(provider_name.lower(), f"{provider_name.upper()}_API_KEY")
        raise ValueError(f"{provider_name.title()} API Key 未配置，请在环境变量中设置 {env_name}")


def _is_builtin_provider(provider_name: str) -> bool:
    """检查是否为 pydantic-ai 内置 provider"""
    return provider_name.lower() in ("anthropic", "openai", "google-gla", "google",
                                      "google-vertex", "groq", "mistral", "cohere",
                                      "bedrock", "azure")


def _create_chat_model(
    model_name: str,
    base_url: str,
    api_key: str = "",
) -> Any:
    """创建 OpenAIChatModel 实例

    使用 pydantic-ai 2.11+ 的 OpenAIProvider + OpenAIChatModel API。
    默认配置 OpenAIModelProfile 以兼容本地部署模型 (如 qwen3, deepseek)。
    """
    try:
        from pydantic_ai.providers.openai import OpenAIProvider
        from pydantic_ai.models.openai import OpenAIChatModel, OpenAIModelProfile
    except ImportError as e:
        raise RuntimeError(
            "pydantic-ai 2.11+ 需要 openai 扩展: pip install 'pydantic-ai[openai]'"
        ) from e

    base_url = base_url.rstrip("/")

    provider = OpenAIProvider(
        base_url=base_url,
        api_key=api_key,
    )

    # qwen3 特殊处理: 关闭思考模式, 且不支持多 system msg 和 strict tools
    if model_name.lower() == "qwen3":
        profile = OpenAIModelProfile(
            openai_chat_supports_multiple_system_messages=False,
            openai_supports_strict_tool_definition=False,
        )
        from pydantic_ai.models.openai import OpenAIChatModelSettings
        settings = OpenAIChatModelSettings(
            extra_body={"chat_template_kwargs": {"enable_thinking": False}}
        )
        _logger.info("qwen3: special profile + disable thinking")
    else:
        # 其他兼容模型 (deepseek 等) 使用默认 profile
        profile = None
        settings = None

    model = OpenAIChatModel(
        model_name=model_name,
        provider=provider,
        profile=profile,
        settings=settings,
    )

    _logger.info(
        "Created OpenAIChatModel: model=%s base_url=%s",
        model_name, base_url,
    )
    return model


def list_available_models() -> list[dict]:
    """获取所有可用模型的列表"""
    from agent_platform.models.providers import generate_model_entries
    return generate_model_entries()
