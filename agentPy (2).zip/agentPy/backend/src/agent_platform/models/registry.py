"""模型注册

预定义可用的 LLM 模型列表，包含 provider、model_id、显示名称等信息。
前端通过 API 获取此列表供用户选择。
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ModelEntry:
    """可用模型条目"""

    id: str  # pydantic-ai 格式的 model string (如 "anthropic:claude-sonson-4-6")
    provider: str  # provider 名称
    display_name: str  # 前端显示名称
    description: str = ""  # 模型描述
    is_default: bool = False  # 是否为默认模型

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "provider": self.provider,
            "display_name": self.display_name,
            "description": self.description,
            "is_default": self.is_default,
        }


# 预注册可用模型
AVAILABLE_MODELS: list[ModelEntry] = [
    # Anthropic
    ModelEntry(
        id="anthropic:claude-opus-4-8",
        provider="anthropic",
        display_name="Claude Opus 4.8",
        description="Anthropic 最强模型，适合复杂推理和创意任务",
        is_default=True,
    ),
    ModelEntry(
        id="anthropic:claude-sonnet-4-6",
        provider="anthropic",
        display_name="Claude Sonnet 4.6",
        description="性能与速度的平衡之选，适合大多数任务",
    ),
    ModelEntry(
        id="anthropic:claude-haiku-4-5-20251001",
        provider="anthropic",
        display_name="Claude Haiku 4.5",
        description="轻量快速模型，适合简单任务和高并发场景",
    ),
    # OpenAI
    ModelEntry(
        id="openai:gpt-5.2",
        provider="openai",
        display_name="GPT-5.2",
        description="OpenAI 旗舰模型",
    ),
    ModelEntry(
        id="openai:gpt-4.1",
        provider="openai",
        display_name="GPT-4.1",
        description="OpenAI 高性能模型",
    ),
    # Google
    ModelEntry(
        id="google:gemini-3-pro-preview",
        provider="google",
        display_name="Gemini 3 Pro",
        description="Google Gemini 系列，多模态能力强",
    ),
    # Groq
    ModelEntry(
        id="groq:llama-3.3-70b-versatile",
        provider="groq",
        display_name="Llama 3.3 70B (Groq)",
        description="开源模型，Groq 加速推理",
    ),
    # Ollama (本地)
    ModelEntry(
        id="ollama:llama3.2",
        provider="ollama",
        display_name="Llama 3.2 (Ollama)",
        description="本地运行，无需 API Key",
    ),
]


def get_available_models() -> list[dict]:
    """获取所有可用模型的字典列表"""
    return [m.to_dict() for m in AVAILABLE_MODELS]


def get_default_model() -> dict:
    """获取默认模型"""
    for m in AVAILABLE_MODELS:
        if m.is_default:
            return m.to_dict()
    return AVAILABLE_MODELS[0].to_dict()


def get_model_by_id(model_id: str) -> dict | None:
    """根据 model_id 获取模型信息"""
    for m in AVAILABLE_MODELS:
        if m.id == model_id:
            return m.to_dict()
    return None
