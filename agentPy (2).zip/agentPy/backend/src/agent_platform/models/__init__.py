"""模型管理模块

提供可用模型的注册、查询和解析功能。
支持内置 Provider + OpenAI 兼容 Provider + Ollama + vLLM。
"""
