"""对话服务层

封装对话的 CRUD 业务逻辑，对接 API 路由和存储层。
"""

from __future__ import annotations

import uuid

from agent_platform.conversations.memory import save_conversation_md
from agent_platform.conversations.models import Conversation
from agent_platform.conversations.storage import ConversationStorage, get_storage


class ConversationService:
    """对话服务类

    提供对话的创建、查询、更新、删除等业务操作。
    """

    def __init__(self, storage: ConversationStorage | None = None) -> None:
        self._storage = storage or get_storage()

    async def create_conversation(
        self,
        title: str = "新对话",
        model_id: str = "anthropic:claude-sonnet-4-6",
    ) -> Conversation:
        """创建新对话"""
        conv_id = str(uuid.uuid4())
        conversation = Conversation(
            id=conv_id,
            title=title,
            model_id=model_id,
        )
        await self._storage.save_conversation(conversation)
        return conversation

    async def get_conversation(self, conversation_id: str) -> Conversation | None:
        """获取对话详情"""
        return await self._storage.get_conversation(conversation_id)

    async def list_conversations(self, limit: int = 50) -> list[dict]:
        """列出对话列表"""
        return await self._storage.list_conversations(limit)

    async def update_conversation(
        self, conversation_id: str, title: str | None = None,
        model_id: str | None = None, persona_id: str | None = None,
    ) -> Conversation | None:
        conversation = await self._storage.get_conversation(conversation_id)
        if not conversation: return None
        if title is not None: conversation.title = title
        if model_id is not None: conversation.model_id = model_id
        if persona_id is not None: conversation.metadata["persona_id"] = persona_id
        await self._storage.save_conversation(conversation)
        return conversation

    async def delete_conversation(self, conversation_id: str) -> bool:
        """删除对话"""
        return await self._storage.delete_conversation(conversation_id)

    async def add_message(
        self,
        conversation_id: str,
        role: str,
        content: str,
        tool_calls: list[dict] | None = None,
        persona_id: str = "default",
        model_id: str = "",
    ) -> Conversation | None:
        """向对话添加消息并自动导出 MD"""
        conversation = await self._storage.get_conversation(conversation_id)
        if not conversation:
            return None
        conversation.add_message(role, content, tool_calls, persona_id=persona_id)

        # 更新 model_id
        if model_id and model_id != conversation.model_id:
            conversation.model_id = model_id

        await self._storage.save_conversation(conversation)

        # 自动导出 MD 文件
        try:
            msgs = [
                {
                    "role": m.role,
                    "content": m.content,
                    "timestamp": m.timestamp.isoformat(),
                    "tool_calls": m.tool_calls,
                }
                for m in conversation.messages
            ]
            save_conversation_md(
                conv_id=conversation.id,
                title=conversation.title,
                messages=msgs,
                persona_id=persona_id,
                model_id=conversation.model_id,
                created_at=conversation.created_at.isoformat(),
            )
        except Exception:
            pass

        return conversation


# 全局单例
_service: ConversationService | None = None


def get_service() -> ConversationService:
    """获取服务单例"""
    global _service
    if _service is None:
        _service = ConversationService()
    return _service
