"""对话记忆模块

实现:
1. MD 文件导出 — 将对话导出为易读的 Markdown 文件
2. 跨会话记忆检索 — 搜索历史摘要，提取相关上下文注入新对话
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from agent_platform.config import get_settings


def get_conv_md_dir() -> Path:
    """获取 MD 导出目录"""
    settings = get_settings()
    return settings.conversations_md_path


def save_conversation_md(
    conv_id: str,
    title: str,
    messages: list[dict],
    persona_id: str = "default",
    model_id: str = "",
    created_at: str = "",
) -> Path:
    """将对话保存为 Markdown 文件

    Args:
        conv_id: 对话 ID
        title: 对话标题
        messages: 消息列表 [{role, content, timestamp}, ...]
        persona_id: 人设 ID
        model_id: 模型 ID
        created_at: 创建时间

    Returns:
        写入的 MD 文件路径
    """
    md_dir = get_conv_md_dir()
    md_dir.mkdir(parents=True, exist_ok=True)

    role_emoji = {
        "user": "👤",
        "assistant": "🤖",
        "system": "⚙️",
        "tool": "🔧",
    }

    lines = [
        f"# 对话: {title}",
        f"",
        f"- **ID**: `{conv_id}`",
        f"- **模型**: {model_id}",
        f"- **人设**: {persona_id}",
        f"- **创建**: {created_at}",
        f"- **导出**: {datetime.now().isoformat()}",
        f"",
        f"---",
        f"",
    ]

    for msg in messages:
        ts = msg.get("timestamp", "")
        if ts and len(ts) > 16:
            ts = ts[:16].replace("T", " ")
        elif not ts:
            ts = datetime.now().strftime("%Y-%m-%d %H:%M")
        content = msg.get("content", "").replace("\n", "\\n")
        role = msg.get("role", "unknown")
        role_label = {"user": "[User]", "assistant": "[AI]", "system": "[Sys]", "tool": "[Tool]"}.get(role, f"[{role}]")

        lines.append(f"| {ts} | {role_label} | {content} |")

    # 使用实际创建日期 (若不可用则使用当前日期)
    if created_at and len(created_at) >= 10:
        date_str = created_at[:10]
    else:
        date_str = datetime.now().strftime('%Y-%m-%d')

    file_name = f"{conv_id[:8]}_{date_str}.md"
    file_path = md_dir / file_name

    # 清理同前缀的旧 MD 文件 (避免重名旧文件残留)
    prefix = conv_id[:8]
    for old_file in md_dir.glob(f"{prefix}_*.md"):
        if old_file.name != file_name:
            try:
                old_file.unlink()
            except Exception:
                pass

    file_path.write_text("\n".join(lines), encoding="utf-8")
    return file_path


def save_conversation_json(conv_id: str, data: dict) -> Path:
    """以 JSON 格式保存对话原始数据 (备用)"""
    md_dir = get_conv_md_dir()
    md_dir.mkdir(parents=True, exist_ok=True)
    file_path = md_dir / f"{conv_id[:8]}.json"
    file_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return file_path


def get_relevant_memories(
    current_message: str,
    max_results: int = 3,
) -> str:
    """检索与当前消息相关的历史会话摘要

    从 summaries 目录读取索引，关键词匹配最近的摘要。

    Args:
        current_message: 当前用户消息
        max_results: 最多返回的摘要数

    Returns:
        记忆上下文字符串，若无需记忆则返回空字符串
    """
    settings = get_settings()
    if not settings.enable_memory:
        return ""

    index_file = settings.summaries_dir / "_index.json"
    if not index_file.exists():
        return ""

    try:
        index = json.loads(index_file.read_text(encoding="utf-8"))
    except Exception:
        return ""

    summaries = index.get("summaries", [])
    if not summaries:
        return ""

    # 使用统一的中英分词
    from agent_platform.conversations.memory_index import _tokenize
    keywords = set(_tokenize(current_message))
    scored = []
    for s in summaries:
        score = 0
        search_text = (
            s.get("summary", "")
            + " "
            + " ".join(s.get("key_points", []))
            + " "
            + " ".join(s.get("tags", []))
        ).lower()
        for kw in keywords:
            if len(kw) > 1 and kw in search_text:
                score += 1
        if score > 0:
            scored.append((score, s))

    scored.sort(key=lambda x: x[0], reverse=True)

    if not scored:
        # 无匹配时返回最近 2 条
        recent = summaries[-max_results:] if len(summaries) > max_results else summaries
        lines = ["\n📚 最近的对话历史:\n"]
        for s in recent:
            lines.append(f"- **{s.get('title', '对话')}**: {s.get('summary', '')[:200]}")
        return "\n".join(lines)

    top = [s for _, s in scored[:max_results]]
    lines = ["\n📚 相关的历史对话要点 (你可以参考):\n"]
    for s in top:
        lines.append(f"### {s.get('title', '对话')}")
        lines.append(f"- 摘要: {s.get('summary', '')}")
        for kp in s.get("key_points", [])[:3]:
            lines.append(f"  - {kp}")
        lines.append("")

    return "\n".join(lines)
