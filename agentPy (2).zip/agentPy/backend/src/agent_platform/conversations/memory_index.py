"""记忆索引模块

管理跨会话摘要的索引文件 (_index.json)。
支持增删查: 添加摘要、列出摘要、搜索关键词。

设计原则:
- 只索引「摘要」而非全文，保证检索速度和上下文大小可控
- 通过开关 (enable_memory) 控制 — 关闭时不进行任何检索和注入
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from agent_platform.config import get_settings


def _tokenize(text: str) -> list[str]:
    """中英混合分词

    英文按空格分词，中文按 2-gram 切分。
    例如 "快速排序算法" → ["快速", "速排", "排序", "序算", "算法"]
    """
    tokens: list[str] = []
    buf = ""
    for ch in text:
        if "一" <= ch <= "鿿" or "㐀" <= ch <= "䶿":
            # 中文字符
            if buf:
                tokens.append(buf.lower())
                buf = ""
            tokens.append(ch)
        elif ch.isalnum():
            buf += ch
        else:
            if buf:
                tokens.append(buf.lower())
                buf = ""
    if buf:
        tokens.append(buf.lower())

    # 对连续中文做 2-gram
    result: list[str] = []
    i = 0
    while i < len(tokens):
        t = tokens[i]
        if len(t) == 1 and "一" <= t <= "鿿":
            # 中文单字: 取 2-gram
            if i + 1 < len(tokens) and len(tokens[i + 1]) == 1 and "一" <= tokens[i + 1] <= "鿿":
                result.append(t + tokens[i + 1])
                i += 2
                continue
            # 落单的中文字
            if len(t) > 1:
                result.append(t)
            i += 1
        else:
            if len(t) > 1:
                result.append(t)
            i += 1

    return [r for r in result if len(r) > 1]


class MemoryIndex:
    """记忆索引管理器

    以单个 _index.json 文件管理所有会话摘要。
    支持增删改查，写入时有文件锁防止并发冲突。
    """

    def __init__(self, index_dir: Path | None = None) -> None:
        settings = get_settings()
        self._dir = index_dir or settings.summaries_dir
        self._dir.mkdir(parents=True, exist_ok=True)
        self._file = self._dir / "_index.json"

    def _read(self) -> dict[str, Any]:
        """读取索引文件"""
        if not self._file.exists():
            return {"version": 1, "updated": "", "summaries": []}
        try:
            return json.loads(self._file.read_text(encoding="utf-8"))
        except Exception:
            return {"version": 1, "updated": "", "summaries": []}

    def _write(self, index: dict[str, Any]) -> None:
        """写入索引文件"""
        index["updated"] = datetime.now().isoformat()
        self._file.write_text(json.dumps(index, ensure_ascii=False, indent=2), encoding="utf-8")

    def add(self, summary: dict[str, Any]) -> None:
        """添加或更新摘要"""
        index = self._read()
        conv_id = summary.get("conversation_id", "")

        # 移除同 ID 的旧记录
        index["summaries"] = [
            s for s in index["summaries"]
            if s.get("conversation_id") != conv_id
        ]
        summary["indexed_at"] = datetime.now().isoformat()
        index["summaries"].append(summary)

        # 最多保留 100 条，超出移除最早的
        if len(index["summaries"]) > 100:
            index["summaries"] = index["summaries"][-100:]

        self._write(index)

    def remove(self, conv_id: str) -> bool:
        """移除指定对话的摘要"""
        index = self._read()
        before = len(index["summaries"])
        index["summaries"] = [
            s for s in index["summaries"]
            if s.get("conversation_id") != conv_id
        ]
        if len(index["summaries"]) != before:
            self._write(index)
            return True
        return False

    def list_all(self) -> list[dict[str, Any]]:
        """列出所有摘要"""
        return self._read().get("summaries", [])

    def search(self, query: str, max_results: int = 5) -> list[dict[str, Any]]:
        """基于关键词搜索相关摘要

        Args:
            query: 搜索关键词
            max_results: 最大返回数

        Returns:
            按相关度排序的摘要列表
        """
        summaries = self.list_all()
        if not summaries:
            return []

        # 中英文混合分词: 空格分离 + 中文按 2-gram 切分
        tokens = _tokenize(query)
        if not tokens:
            # 无有效关键词时返回最近几条
            return summaries[-max_results:]

        scored = []
        for s in summaries:
            score = 0
            fields = (
                s.get("summary", "")
                + " "
                + " ".join(s.get("key_points", []))
                + " "
                + " ".join(s.get("tags", []))
                + " "
                + s.get("title", "")
            ).lower()
            for kw in tokens:
                if kw in fields:
                    score += 1
            if score > 0:
                scored.append((score, s))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [s for _, s in scored[:max_results]]

    def get_related_context(self, query: str, max_contexts: int = 3) -> str:
        """获取与查询相关的记忆上下文文本

        供 system prompt 注入使用。只返回匹配度最高的摘要要点。

        Args:
            query: 用户问题
            max_contexts: 最多注入的上下文条数

        Returns:
            格式化的记忆上下文字符串，无匹配时返回空字符串
        """
        results = self.search(query, max_results=max_contexts)
        if not results:
            return ""

        lines = [
            "",
            "📚 **以下是与当前问题相关的历史对话要点 (仅供参考):**",
            "",
        ]
        for r in results:
            title = r.get("title", "对话")
            summary = r.get("summary", "")[:300]
            key_points = r.get("key_points", [])[:3]
            lines.append(f"- **{title}**: {summary}")
            for kp in key_points:
                lines.append(f"    - {kp}")
            lines.append("")

        lines.append("> 你可以参考以上要点，但无需强制使用。如果与当前问题无关，请忽略。")
        return "\n".join(lines)


# 全局单例
_index: MemoryIndex | None = None


def get_memory_index() -> MemoryIndex:
    """获取记忆索引单例"""
    global _index
    if _index is None:
        _index = MemoryIndex()
    return _index
