"""会话摘要生成器

在对话结束后 (或手动触发) 精简对话要点，生成结构化摘要。
摘要存入 MemoryIndex，供后续跨会话检索。

设计:
- 使用简单的关键词提取 + 规则生成摘要 (无需额外 LLM 调用)
- 也可配置为调用 LLM 生成更高质量的摘要
"""

from __future__ import annotations

from datetime import datetime

from agent_platform.conversations.memory_index import MemoryIndex, get_memory_index
from agent_platform.conversations.models import Conversation
from agent_platform.config import get_settings


def generate_summary(
    conversation: Conversation,
    index: MemoryIndex | None = None,
) -> dict:
    """为对话生成结构化摘要

    提取: 标题、概述、关键点、标签、代码片段、决策

    Args:
        conversation: 对话对象
        index: 记忆索引实例 (默认从单例获取)

    Returns:
        结构化摘要字典
    """
    if index is None:
        index = get_memory_index()

    messages = conversation.messages
    if not messages:
        return {}

    # 提取所有文本
    all_text = " ".join(m.content for m in messages if m.role in ("user", "assistant"))

    # ---- 提取关键点 ----
    key_points = _extract_key_points(messages)

    # ---- 提取标签 ----
    tags = _extract_tags(all_text)

    # ---- 提取代码片段 ----
    code_snippets = _extract_code_snippets(all_text)

    # ---- 提取决策 ----
    decisions = _extract_decisions(messages)

    # ---- 生成摘要文本 ----
    summary_text = _compose_summary(conversation.title, key_points, decisions)

    summary = {
        "conversation_id": conversation.id,
        "title": conversation.title,
        "created_at": conversation.created_at.isoformat(),
        "updated_at": conversation.updated_at.isoformat(),
        "summary": summary_text,
        "key_points": key_points,
        "tags": tags,
        "decisions": decisions,
        "code_snippets": code_snippets,
        "persona_id": conversation.metadata.get("persona_id", "default"),
        "model_id": conversation.model_id,
        "message_count": len(messages),
    }

    # 写入索引
    index.add(summary)
    return summary


def _compose_summary(title: str, key_points: list[str], decisions: list[str]) -> str:
    """组合摘要文本"""
    parts = [f"讨论了关于「{title}」的内容"]
    if key_points:
        parts.append("涉及: " + "、".join(key_points[:5]))
    if decisions:
        parts.append("决定: " + "、".join(decisions[:3]))
    return "。".join(parts) + "。"


def _extract_key_points(messages) -> list[str]:
    """从消息中提取关键点"""
    points = []
    for m in messages:
        if m.role == "user":
            text = m.content.strip()
            # 取问句/请求的前 80 字作为关键点
            if len(text) > 10:
                points.append(text[:80].replace("\n", " "))
        elif m.role == "assistant":
            text = m.content.strip()
            # 取以 "**" 开头的粗体行或 "1." 开头的列表
            for line in text.split("\n"):
                line = line.strip()
                if (line.startswith("**") or line.startswith("1.") or line.startswith("- ")) and len(line) > 8:
                    clean = line.lstrip("*0123456789.- ").strip()
                    if len(clean) > 5:
                        points.append(clean[:100])
    return list(dict.fromkeys(points))[:8]  # 去重，最多 8 条


def _extract_tags(text: str) -> list[str]:
    """从文本提取关键词标签"""
    tag_patterns = {
        "python": ["python", "pip", "numpy", "pandas", "fastapi", "pydantic"],
        "算法": ["排序", "搜索", "算法", "复杂度", "优化"],
        "前端": ["html", "css", "javascript", "svelte", "react", "组件", "tailwind"],
        "后端": ["api", "数据库", "sql", "rest", "gunicorn", "uvicorn"],
        "部署": ["docker", "nginx", "部署", "服务器", "git"],
        "调试": ["bug", "error", "调试", "修复", "报错"],
        "设计": ["ui", "样式", "布局", "颜色", "主题"],
        "数据": ["json", "csv", "分析", "统计", "导出"],
    }
    found = []
    text_lower = text.lower()
    for tag, patterns in tag_patterns.items():
        for p in patterns:
            if p in text_lower:
                found.append(tag)
                break
    return list(dict.fromkeys(found))[:5]


def _extract_code_snippets(text: str) -> list[str]:
    """提取代码片段 (第一个 fenced code block 的首 200 字)"""
    snippets = []
    in_block = False
    buf = ""
    for line in text.split("\n"):
        if line.strip().startswith("```"):
            if in_block:
                if len(buf) > 10:
                    snippets.append(buf.strip()[:200])
                buf = ""
                in_block = False
            else:
                in_block = True
                buf = ""
        elif in_block:
            buf += line + "\n"
    return snippets[:3]


def _extract_decisions(messages) -> list[str]:
    """提取用户做出的决策"""
    decision_markers = [
        "好的", "就这样", "用这个", "选这个", "确定了", "决定了",
        "yes", "ok", "就用", "采用", "按这个来",
    ]
    decisions = []
    for m in messages:
        if m.role == "user":
            text_lower = m.content.lower()
            for marker in decision_markers:
                if marker in text_lower:
                    decisions.append(m.content.strip()[:100])
                    break
    return list(dict.fromkeys(decisions))[:5]
