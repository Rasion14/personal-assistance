"""对话存储后端

默认使用 SQLite (aiosqlite) 存储对话数据。
通过异步接口设计，未来可替换为 PostgreSQL 等其他数据库。
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

import aiosqlite

from agent_platform.config import get_settings
from agent_platform.conversations.models import Conversation, Message


class ConversationStorage:
    """对话存储类

    负责对话的持久化存储，支持 CRUD 操作。
    使用 SQLite 数据库，自动建表。
    """

    def __init__(self, db_url: str | None = None) -> None:
        self._db_url = db_url or get_settings().database_url
        self._db: aiosqlite.Connection | None = None

    async def connect(self) -> None:
        """连接数据库并初始化表结构"""
        db_path = self._db_url.replace("sqlite+aiosqlite:///", "")
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._db = await aiosqlite.connect(db_path)
        await self._db.execute("PRAGMA journal_mode=WAL")
        await self._db.execute("PRAGMA foreign_keys=ON")
        await self._create_tables()
        await self._db.commit()

    async def close(self) -> None:
        """关闭数据库连接"""
        if self._db:
            await self._db.close()
            self._db = None

    async def _create_tables(self) -> None:
        """创建数据表"""
        await self._db.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL DEFAULT '新对话',
                model_id TEXT NOT NULL DEFAULT 'anthropic:claude-sonnet-4-6',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                metadata TEXT DEFAULT '{}'
            )
        """)
        await self._db.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id TEXT PRIMARY KEY,
                conversation_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                tool_calls TEXT DEFAULT '[]',
                metadata TEXT DEFAULT '{}',
                FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
            )
        """)

    async def save_conversation(self, conversation: Conversation) -> None:
        """保存对话及其所有消息"""
        if not self._db:
            await self.connect()

        await self._db.execute(
            """INSERT OR REPLACE INTO conversations
               (id, title, model_id, created_at, updated_at, metadata)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                conversation.id,
                conversation.title,
                conversation.model_id,
                conversation.created_at.isoformat(),
                conversation.updated_at.isoformat(),
                json.dumps(conversation.metadata, ensure_ascii=False),
            ),
        )

        # 删除旧消息，重新插入
        await self._db.execute("DELETE FROM messages WHERE conversation_id = ?", (conversation.id,))
        for msg in conversation.messages:
            await self._db.execute(
                """INSERT INTO messages
                   (id, conversation_id, role, content, timestamp, tool_calls, metadata)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    msg.id,
                    conversation.id,
                    msg.role,
                    msg.content,
                    msg.timestamp.isoformat(),
                    json.dumps(msg.tool_calls, ensure_ascii=False),
                    json.dumps(msg.metadata, ensure_ascii=False),
                ),
            )
        await self._db.commit()

    async def get_conversation(self, conversation_id: str) -> Conversation | None:
        """根据 ID 获取对话"""
        if not self._db:
            await self.connect()

        async with self._db.execute(
            "SELECT id, title, model_id, created_at, updated_at, metadata FROM conversations WHERE id = ?",
            (conversation_id,),
        ) as cursor:
            row = await cursor.fetchone()
        if not row:
            return None

        conv = Conversation(
            id=row[0],
            title=row[1],
            model_id=row[2],
            created_at=datetime.fromisoformat(row[3]),
            updated_at=datetime.fromisoformat(row[4]),
            metadata=json.loads(row[5]),
        )

        # 加载消息
        async with self._db.execute(
            "SELECT id, role, content, timestamp, tool_calls, metadata FROM messages WHERE conversation_id = ?",
            (conversation_id,),
        ) as cursor:
            messages = []
            async for msg_row in cursor:
                messages.append(Message(
                    id=msg_row[0],
                    role=msg_row[1],
                    content=msg_row[2],
                    timestamp=datetime.fromisoformat(msg_row[3]),
                    tool_calls=json.loads(msg_row[4]) if msg_row[4] else [],
                    metadata=json.loads(msg_row[5]) if msg_row[5] else {},
                ))
        conv.messages = messages
        return conv

    async def list_conversations(self, limit: int = 50) -> list[dict]:
        """列出对话摘要 (含消息计数)"""
        if not self._db:
            await self.connect()

        async with self._db.execute(
            """SELECT c.id, c.title, c.model_id, c.created_at, c.updated_at,
                      (SELECT COUNT(*) FROM messages m WHERE m.conversation_id = c.id) as msg_count
               FROM conversations c ORDER BY c.updated_at DESC LIMIT ?""",
            (limit,),
        ) as cursor:
            rows = await cursor.fetchall()

        return [
            {
                "id": row[0],
                "title": row[1],
                "model_id": row[2],
                "created_at": row[3],
                "updated_at": row[4],
                "message_count": row[5] or 0,
            }
            for row in rows
        ]

    async def delete_conversation(self, conversation_id: str) -> bool:
        """删除对话"""
        if not self._db:
            await self.connect()

        cursor = await self._db.execute(
            "DELETE FROM conversations WHERE id = ?", (conversation_id,)
        )
        await self._db.commit()
        return cursor.rowcount > 0


# 全局单例
_storage: ConversationStorage | None = None


def get_storage() -> ConversationStorage:
    """获取存储单例"""
    global _storage
    if _storage is None:
        _storage = ConversationStorage()
    return _storage
