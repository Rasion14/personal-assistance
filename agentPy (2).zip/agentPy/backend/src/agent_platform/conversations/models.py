"""对话数据模型

使用 Pydantic 定义 Conversation 和 Message 的结构化数据模型。
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class Message(BaseModel):
    """单条消息模型"""

    id: str = Field(description="消息唯一 ID")
    role: str = Field(description="角色: user / assistant / system / tool")
    content: str = Field(description="消息内容")
    timestamp: datetime = Field(default_factory=datetime.now, description="发送时间")
    tool_calls: list[dict[str, Any]] = Field(default_factory=list, description="工具调用信息")
    metadata: dict[str, Any] = Field(default_factory=dict, description="额外元数据")


class Conversation(BaseModel):
    """对话模型"""

    id: str = Field(description="对话唯一 ID")
    title: str = Field(default="新对话", description="对话标题")
    model_id: str = Field(default="anthropic:claude-sonnet-4-6", description="使用的模型")
    messages: list[Message] = Field(default_factory=list, description="消息历史")
    created_at: datetime = Field(default_factory=datetime.now, description="创建时间")
    updated_at: datetime = Field(default_factory=datetime.now, description="最后更新时间")
    metadata: dict[str, Any] = Field(default_factory=dict, description="额外元数据")

    def add_message(self, role: str, content: str, tool_calls: list[dict] | None = None, persona_id: str = "default") -> None:
        """添加消息并更新最后修改时间"""
        import uuid
        msg = Message(
            id=str(uuid.uuid4()),
            role=role,
            content=content,
            tool_calls=tool_calls or [],
            metadata={"persona_id": persona_id},
        )
        self.messages.append(msg)
        self.updated_at = datetime.now()

    def get_last_n(self, n: int) -> list[Message]:
        """获取最近 N 条消息"""
        return self.messages[-n:]
