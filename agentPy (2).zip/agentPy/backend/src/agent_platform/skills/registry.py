"""Skill 注册中心

管理本地已安装 Skill 的 CRUD 操作，包括版本管理和状态切换。
使用文件系统存储 Skill 元数据 (JSON)，便于持久化和调试。
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import logging

from agent_platform.config import get_settings
from agent_platform.skills.models import SkillInfo, SkillStatus

_logger = logging.getLogger("agent_platform.skills.registry")


class SkillRegistry:
    """Skill 注册中心

    负责:
    - 发现并加载已安装的 Skill
    - 添加 / 删除 / 更新 Skill 记录
    - 启用 / 禁用 Skill
    - 持久化元数据到本地文件
    """

    def __init__(self, skills_dir: Path | None = None) -> None:
        self._skills_dir = (skills_dir or get_settings().skills_data_path).resolve()
        self._skills_dir.mkdir(parents=True, exist_ok=True)
        self._index_file = self._skills_dir / "_index.json"
        self._skills: dict[str, SkillInfo] = {}
        self._load_index()
        self._discover_skills()  # 自动扫描目录发现未注册的 skill

    def _load_index(self) -> None:
        """从本地文件加载 Skill 索引"""
        if self._index_file.exists():
            try:
                data = json.loads(self._index_file.read_text(encoding="utf-8"))
                for item in data.get("skills", []):
                    self._skills[item["name"]] = SkillInfo(**item)
                _logger.info("Loaded {count} skills from index", count=len(self._skills))
            except (json.JSONDecodeError, KeyError) as e:
                _logger.error("Failed to load skill index: {error}", error=str(e))
                self._skills = {}

    def _save_index(self) -> None:
        """将 Skill 索引保存到本地文件"""
        data = {"skills": [skill.model_dump() for skill in self._skills.values()]}
        self._index_file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def refresh(self) -> int:
        """刷新 skill 列表 — 重新扫描文件系统，返回新发现的 skill 数量"""
        before = len(self._skills)
        self._discover_skills()
        after = len(self._skills)
        new_count = after - before
        if new_count > 0:
            _logger.info("Registry refresh: discovered {count} new skills (total: {total})",
                         count=new_count, total=after)
        return new_count

    def _discover_skills(self) -> None:
        """自动扫描 skills-data 目录，发现并注册未在索引中的 skill

        遍历 skills-data 下所有子目录 (排除 sandbox、隐藏目录)，
        对包含 SKILL.md 或 skill.yaml 的目录调用 load_skill_from_directory
        并自动注册。_resolve_skill_dir 会递归查找实际包含规格文件的子目录。
        """
        from agent_platform.skills.loader import load_skill_from_directory

        skip_names = {"sandbox", "_index", "__pycache__"}
        found = 0

        def _scan_dir(directory: Path, depth: int = 0) -> None:
            """递归扫描目录，发现 skill"""
            nonlocal found
            if depth > 3 or not directory.is_dir():
                return
            for entry in sorted(directory.iterdir(), key=lambda e: (e.is_file(), e.name)):
                if not entry.is_dir() or entry.name.startswith(".") or entry.name in skip_names:
                    continue

                # 尝试解析为 skill 目录 (内部会递归查找规格文件)
                actual = self._resolve_skill_dir(entry)
                if actual is None:
                    # 没有规格文件 → 递归进入子目录 (如 uploaded/)
                    _scan_dir(entry, depth + 1)
                    continue

                loaded = load_skill_from_directory(actual)
                skill_name = loaded.get("name", entry.name)
                if skill_name in self._skills:
                    continue  # 已注册
                if loaded.get("error"):
                    _logger.warning("Skip invalid skill at {path}: {err}", path=str(actual), err=loaded["error"])
                    continue

                info = SkillInfo(
                    name=skill_name,
                    version=loaded.get("version", "0.0.0"),
                    description=loaded.get("description", ""),
                    install_path=str(actual),
                    instructions=loaded.get("instructions", ""),
                    tools=loaded.get("tools", []),
                    metadata={"source": "discovered", **loaded.get("metadata", {})},
                )
                self._skills[skill_name] = info
                found += 1
                _logger.info("Discovered skill {name} at {path} (instructions={inst_len} chars)",
                             name=skill_name, path=str(actual), inst_len=len(info.instructions))

        _scan_dir(self._skills_dir)
        if found > 0:
            self._save_index()
            _logger.info("Registered {count} new skills (total: {total})",
                         count=found, total=len(self._skills))
        elif not self._skills:
            _logger.warning("No skills discovered in %s", self._skills_dir)

    @staticmethod
    def _resolve_skill_dir(entry: Path) -> Path | None:
        """返回 entry 中实际包含规格文件的目录，不移动文件

        递归查找包含 SKILL.md / skill.yaml 的目录。
        返回 None 表示未找到任何规格文件。
        """
        for name in ("SKILL.md", "skill.yaml", "skill.yml"):
            if (entry / name).exists():
                return entry

        # 递归进子目录查找
        try:
            for child in sorted(entry.iterdir(), key=lambda e: (e.is_file(), e.name)):
                if child.is_dir() and not child.name.startswith("."):
                    result = SkillRegistry._resolve_skill_dir(child)
                    if result is not None:
                        return result
        except PermissionError:
            pass

        return None

    def get_all(self) -> list[SkillInfo]:
        """获取所有已注册的 Skill"""
        return list(self._skills.values())

    def get_by_name(self, name: str) -> SkillInfo | None:
        """按名称获取 Skill"""
        return self._skills.get(name)

    def get_enabled(self) -> list[SkillInfo]:
        """获取所有已启用的 Skill"""
        return [s for s in self._skills.values() if s.is_active()]

    def get_enabled_names(self) -> list[str]:
        """获取已启用 Skill 的名称列表"""
        return [s.name for s in self._skills.values() if s.is_active()]

    def add_skill(self, skill: SkillInfo) -> SkillInfo:
        """添加 Skill 记录"""
        self._skills[skill.name] = skill
        self._save_index()
        _logger.info("Added skill {name} version={version}", name=skill.name, version=skill.version)
        return skill

    def update_skill(self, name: str, **kwargs) -> SkillInfo | None:
        """更新 Skill 属性"""
        skill = self._skills.get(name)
        if skill:
            skill = skill.model_copy(update=kwargs)
            self._skills[name] = skill
            self._save_index()
            _logger.info("Updated skill {name}", name=name)
        return skill

    def remove_skill(self, name: str) -> bool:
        """移除 Skill 记录"""
        skill = self._skills.pop(name, None)
        if skill:
            self._save_index()
            _logger.info("Removed skill {name}", name=name)
        return skill is not None

    def enable_skill(self, name: str) -> SkillInfo | None:
        """启用 Skill"""
        return self.update_skill(name, status=SkillStatus.ENABLED)

    def disable_skill(self, name: str) -> SkillInfo | None:
        """禁用 Skill"""
        return self.update_skill(name, status=SkillStatus.INSTALLED)

    def uninstall_skill(self, name: str) -> bool:
        """卸载 Skill — 删除记录和本地目录"""
        skill = self._skills.get(name)
        if skill:
            install_path = Path(skill.install_path)
            if install_path.exists():
                shutil.rmtree(install_path, ignore_errors=True)
            self.remove_skill(name)
            _logger.info("Uninstalled skill {name}", name=name)
            return True
        return False


# 全局单例
_registry: SkillRegistry | None = None


def get_registry() -> SkillRegistry:
    """获取 Skill 注册中心单例"""
    global _registry
    if _registry is None:
        _registry = SkillRegistry()
    return _registry
