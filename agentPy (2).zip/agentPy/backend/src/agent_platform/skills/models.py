"""Skill 数据模型

使用 Pydantic 定义 Skill 的结构化数据模型，
支持序列化、验证和 JSON Schema 生成。
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class SkillStatus(str, Enum):
    """Skill 安装状态"""

    INSTALLED = "installed"
    ENABLED = "enabled"
    DISABLED = "disabled"
    ERROR = "error"


class SkillCategory(str, Enum):
    """Skill 分类"""

    WEB = "web"
    CODE = "code"
    DATA = "data"
    FILE = "file"
    ANALYSIS = "analysis"
    CREATIVITY = "creativity"
    AUTOMATION = "automation"
    OTHER = "other"


class SkillInfo(BaseModel):
    """Skill 元信息模型

    描述一个已安装或待安装的 Skill 的完整信息。
    """

    name: str = Field(description="Skill 唯一名称")
    version: str = Field(description="版本号 (semver)")
    description: str = Field(description="Skill 功能描述")
    category: SkillCategory = Field(default=SkillCategory.OTHER, description="分类")
    source_url: str | None = Field(default=None, description="远程仓库 URL")
    install_path: str = Field(description="本地安装路径")
    status: SkillStatus = Field(default=SkillStatus.INSTALLED, description="当前状态")
    instructions: str = Field(default="", description="注入到 Agent 的系统指令")
    tools: list[str] = Field(default_factory=list, description="提供的工具名称列表")
    metadata: dict[str, Any] = Field(default_factory=dict, description="额外元数据")
    error_message: str | None = Field(default=None, description="错误信息 (status=error 时)")

    def is_active(self) -> bool:
        """判断 Skill 是否处于活跃状态 (已启用)"""
        return self.status == SkillStatus.ENABLED

    def is_available(self) -> bool:
        """判断 Skill 是否可用 (已安装且非错误状态)"""
        return self.status in (SkillStatus.INSTALLED, SkillStatus.ENABLED)


class SkillInstallRequest(BaseModel):
    """安装 Skill 的请求模型"""

    source_url: str = Field(
        description="远程 URL (GitHub Releases ZIP / GitLab 归档 / 直接 ZIP 链接)",
        examples=["https://github.com/org/skill-name/releases/download/v1.0.0/skill.zip"],
    )
    name: str | None = Field(
        default=None,
        description="可选 — 手动指定名称，不指定则从 URL 或压缩包中自动提取",
    )


class SkillUninstallRequest(BaseModel):
    """卸载 Skill 的请求模型"""

    name: str = Field(description="要卸载的 Skill 名称")
