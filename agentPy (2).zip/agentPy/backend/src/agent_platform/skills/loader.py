
"""Skill 加载器模块

从已安装的 Skill 目录中读取 SKILL.md 或 skill.yaml 规格文件，
解析出 name、version、description、instructions、tools 等字段，
返回可注入到 Agent 系统指令中的字典结构。

支持的格式:
  - SKILL.md  — Markdown 文件，顶部带有 YAML frontmatter (以 --- 包围)
  - skill.yaml / skill.yml — 纯 YAML 规格文件

设计原则:
  - 绝不向外抛出异常；解析失败时在返回字典中设置 error 字段
  - 所有注释使用中文
"""

from __future__ import annotations

import logging

import re
from pathlib import Path
from typing import Any

import yaml

from agent_platform.skills.models import SkillInfo, SkillStatus

_logger = logging.getLogger("agent_platform.skills.loader")

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

# SKILL.md 中 frontmatter 的正则：匹配文件开头由 --- 包围的 YAML 块
_FRONTmatter_RE = re.compile(
    r"^---\s*\n(?P<content>.*?)\n---\s*\n(?P<rest>.*)",
    re.DOTALL | re.MULTILINE,
)

# ---------------------------------------------------------------------------
# 公共 API — 模块级函数
# ---------------------------------------------------------------------------

def load_skill_from_directory(skill_dir: Path | str) -> dict[str, Any]:
    """从 Skill 安装目录加载 Skill 规格

    搜索顺序:
      1. SKILL.md（优先读取 frontmatter，正文作为补充说明）
      2. skill.yaml / skill.yml

    如果两个文件都存在，以 SKILL.md frontmatter 为主，YAML 文件字段
    作为补充合并（YAML 中独有且非空的字段会被保留）。

    参数
    ----
    skill_dir : Skill 的安装目录路径

    返回
    ----
    dict  — 包含解析后的字段，键包括:
        - name: str
        - version: str
        - description: str
        - instructions: str
        - tools: list[str]
        - metadata: dict
        - source: str  ("skill.md" | "skill.yaml" | "merged")
        - install_path: str
        - error: str | None

    注意
    ----
    不抛出异常；解析失败时在返回字典中设置 error 字段。
    """
    skill_path = Path(skill_dir).resolve()

    # 检查目录是否存在
    if not skill_path.is_dir():
        err_msg = f"Skill 目录不存在: {skill_path}"
        _logger.warn(err_msg)
        return _error_result(skill_path, err_msg)

    try:
        # 尝试读取 SKILL.md
        skill_md_data: dict[str, Any] | None = None
        skill_md_path = skill_path / "SKILL.md"
        if skill_md_path.exists():
            skill_md_data = _parse_skill_md(skill_md_path)

        # 尝试读取 skill.yaml / skill.yml
        skill_yaml_data: dict[str, Any] | None = None
        for yaml_name in ("skill.yaml", "skill.yml"):
            yaml_path = skill_path / yaml_name
            if yaml_path.exists():
                skill_yaml_data = _parse_skill_yaml(yaml_path)
                break

        # 两个文件都没有找到
        if skill_md_data is None and skill_yaml_data is None:
            err_msg = f"未找到 SKILL.md 或 skill.yaml 文件于: {skill_path}"
            _logger.warn(err_msg)
            return _error_result(skill_path, err_msg)

        # 合并数据
        merged: dict[str, Any]
        if skill_md_data is not None and skill_yaml_data is not None:
            merged = _merge_spec(skill_md_data, skill_yaml_data)
            merged["source"] = "merged"
        elif skill_md_data is not None:
            merged = dict(skill_md_data)
            merged["source"] = "skill.md"
        else:
            merged = dict(skill_yaml_data)
            merged["source"] = "skill.yaml"

        # 确保必要字段存在默认值
        merged.setdefault("name", skill_path.name)
        merged.setdefault("version", "0.0.0")
        merged.setdefault("description", "")
        merged.setdefault("instructions", "")
        merged.setdefault("tools", [])
        merged.setdefault("metadata", {})
        merged.setdefault("install_path", str(skill_path))
        merged["error"] = None

        # 规范化 tools 字段为字符串列表
        merged["tools"] = _normalize_tools(merged.get("tools", []))

        _logger.info(
            "Loaded skill {name} version={version} from={source}",
            name=merged["name"],
            version=merged["version"],
            source=merged["source"],
        )
        return merged

    except Exception as e:
        # 捕获所有未预期的异常，确保不会向上抛出
        err_msg = f"加载 Skill 时发生未知错误 ({skill_path}): {e}"
        _logger.error(err_msg, exc_info=True)
        return _error_result(skill_path, err_msg)

def load_skill_to_info(skill_dir: Path | str) -> SkillInfo:
    """加载 Skill 目录并返回 SkillInfo 模型实例

    内部调用 load_skill_from_directory()，然后将结果映射到
    SkillInfo Pydantic 模型。

    参数
    ----
    skill_dir : Skill 的安装目录路径

    返回
    ----
    SkillInfo — 解析后的 Skill 信息；加载失败时 status=ERROR。
    """
    data = load_skill_from_directory(skill_dir)

    if data.get("error"):
        return SkillInfo(
            name=data.get("name", Path(skill_dir).name),
            version=data.get("version", "0.0.0"),
            description=data.get("description", ""),
            install_path=str(Path(skill_dir).resolve()),
            status=SkillStatus.ERROR,
            error_message=data["error"],
        )

    return SkillInfo(
        name=data["name"],
        version=data["version"],
        description=data["description"],
        install_path=data.get("install_path", str(Path(skill_dir).resolve())),
        instructions=data.get("instructions", ""),
        tools=data.get("tools", []),
        metadata=data.get("metadata", {}),
        status=SkillStatus.INSTALLED,
    )

def build_system_instructions_prompt(skills: list[dict[str, Any]]) -> str:
    """将多个已加载的 Skill 字典合并为注入到 Agent 的系统指令文本

    参数
    ----
    skills : 已通过 load_skill_from_directory() 加载的字典列表

    返回
    ----
    str  — 格式化的系统指令文本，可直接附加到 Agent prompt 中。
           如果列表为空则返回空字符串。
    """
    if not skills:
        return ""

    sections: list[str] = []
    sections.append("# 已安装技能\n")

    for skill in skills:
        # 跳过加载失败的 Skill
        if skill.get("error"):
            continue

        name = skill.get("name", "unknown")
        desc = skill.get("description", "")
        instructions = skill.get("instructions", "")
        tools = skill.get("tools", [])

        section_lines: list[str] = []
        section_lines.append(f"## {name}")
        section_lines.append(f"版本: {skill.get('version', 'N/A')}")
        section_lines.append("")

        if desc:
            section_lines.append(f"**描述**: {desc}")
            section_lines.append("")

        if tools:
            tool_list = ", ".join(tools)
            section_lines.append(f"**可用工具**: {tool_list}")
            section_lines.append("")

        if instructions:
            section_lines.append("---")
            section_lines.append(instructions)
            section_lines.append("---")

        section_lines.append("")
        sections.append("\n".join(section_lines))

    return "\n".join(sections)

# ---------------------------------------------------------------------------
# 内部实现 — SKILL.md 解析
# ---------------------------------------------------------------------------

def _parse_skill_md(file_path: Path) -> dict[str, Any]:
    """解析 SKILL.md 文件

    从文件首部的 YAML frontmatter 中提取元数据字段，
    正文部分作为补充说明追加到 instructions 中。

    返回的字典包含:
      - name, version, description, instructions, tools, metadata
      - body (Markdown 正文，不含 frontmatter)
    """
    try:
        raw_text = file_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as e:
        raise ValueError(f"无法读取 SKILL.md ({file_path}): {e}") from e

    match = _FRONTmatter_RE.match(raw_text)

    if not match:
        # 没有 frontmatter 的 SKILL.md —— 将整个内容当作 instructions
        return {
            "name": file_path.parent.name,
            "version": "0.0.0",
            "description": "",
            "instructions": raw_text.strip(),
            "tools": [],
            "metadata": {},
            "body": "",
        }

    # 解析 frontmatter 中的 YAML 内容
    frontmatter_text = match.group("content").strip()
    body_text = match.group("rest").strip()

    try:
        frontmatter: dict[str, Any] = yaml.safe_load(frontmatter_text) or {}
    except yaml.YAMLError as e:
        raise ValueError(
            f"SKILL.md frontmatter YAML 解析失败 ({file_path}): {e}"
        ) from e

    if not isinstance(frontmatter, dict):
        raise ValueError(
            f"SKILL.md frontmatter 应为 YAML 映射对象 ({file_path})"
        )

    # 提取已知字段
    result: dict[str, Any] = {
        "name": _to_str(frontmatter.get("name", file_path.parent.name)),
        "version": _to_str(frontmatter.get("version", "0.0.0")),
        "description": _to_str(frontmatter.get("description", "")),
        "instructions": _to_str(frontmatter.get("instructions", "")),
        "tools": frontmatter.get("tools", []),
        "metadata": {},
        "body": body_text,
    }

    # 将正文内容追加到 instructions 后面
    if body_text:
        existing = result["instructions"]
        if existing:
            result["instructions"] = existing + "\n\n" + body_text
        else:
            result["instructions"] = body_text

    # 收集未在已知字段中出现的额外键到 metadata
    known_keys = {"name", "version", "description", "instructions", "tools"}
    result["metadata"] = {
        k: v for k, v in frontmatter.items() if k not in known_keys
    }

    return result

# ---------------------------------------------------------------------------
# 内部实现 — skill.yaml 解析
# ---------------------------------------------------------------------------

def _parse_skill_yaml(file_path: Path) -> dict[str, Any]:
    """解析 skill.yaml / skill.yml 规格文件

    期望的 YAML 结构:

        name: my-skill
        version: 1.0.0
        description: 这是一个技能
        instructions: |
          执行任务时请遵循以下规则...
        tools:
          - tool_alpha
          - tool_beta
        metadata:
          author: someone
          category: analysis

    返回的字典包含:
      - name, version, description, instructions, tools, metadata
    """
    try:
        raw_text = file_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as e:
        raise ValueError(
            f"无法读取 YAML 规格文件 ({file_path}): {e}"
        ) from e

    try:
        spec: dict[str, Any] = yaml.safe_load(raw_text) or {}
    except yaml.YAMLError as e:
        raise ValueError(
            f"skill.yaml YAML 解析失败 ({file_path}): {e}"
        ) from e

    if not isinstance(spec, dict):
        raise ValueError(
            f"skill.yaml 顶层应为 YAML 映射对象 ({file_path})"
        )

    # 提取已知字段，确保类型正确
    result: dict[str, Any] = {
        "name": _to_str(spec.get("name", file_path.parent.name)),
        "version": _to_str(spec.get("version", "0.0.0")),
        "description": _to_str(spec.get("description", "")),
        "instructions": _to_str(spec.get("instructions", "")),
        "tools": spec.get("tools", []),
        "metadata": spec.get("metadata", {}),
    }

    # 确保 metadata 是字典类型
    if not isinstance(result["metadata"], dict):
        result["metadata"] = {}

    return result

# ---------------------------------------------------------------------------
# 内部实现 — 合并与辅助工具
# ---------------------------------------------------------------------------

def _merge_spec(md_data: dict[str, Any], yaml_data: dict[str, Any]) -> dict[str, Any]:
    """合并 SKILL.md 和 skill.yaml 的解析结果

    合并策略:
      - name / version: 以 SKILL.md frontmatter 为准
      - description: SKILL.md 优先，为空时采用 YAML
      - instructions: SKILL.md 优先，YAML 有内容时追加在末尾
      - tools: 合并两个来源的列表并去重
      - metadata: 合并字典，SKILL.md 的键优先级高
    """
    merged = dict(yaml_data)  # 以 YAML 为基底

    # name 和 version 以 SKILL.md 为主
    merged["name"] = md_data.get("name", merged.get("name"))
    merged["version"] = md_data.get("version", merged.get("version"))

    # description: SKILL.md 优先
    if md_data.get("description"):
        merged["description"] = md_data["description"]

    # instructions: 合并两段说明文本
    md_inst = md_data.get("instructions", "")
    yaml_inst = merged.get("instructions", "")
    if md_inst and yaml_inst:
        merged["instructions"] = yaml_inst + "\n\n" + md_inst
    elif md_inst:
        merged["instructions"] = md_inst
    # else: 保留 YAML 的 instructions

    # tools: 合并两个来源后去重
    md_tools = md_data.get("tools", [])
    yaml_tools = merged.get("tools", [])
    merged["tools"] = _deduplicate_list(md_tools + yaml_tools)

    # metadata: 合并字典，SKILL.md 的键优先级更高
    merged_meta = dict(merged.get("metadata", {}))
    md_meta = md_data.get("metadata", {})
    merged_meta.update(md_meta)
    merged["metadata"] = merged_meta

    return merged

def _normalize_tools(tools: Any) -> list[str]:
    """将 tools 字段规范化为字符串列表

    处理各种输入格式:
      - 字符串列表 ["a", "b"] — 直接返回
      - 字典列表 [{"name": "a"}, ...] — 提取 name 键
      - 单个字符串 "tool_name" — 转为单元素列表
      - None / 空 — 返回空列表
    """
    if tools is None:
        return []
    if isinstance(tools, str):
        return [tools] if tools.strip() else []
    if isinstance(tools, list):
        result: list[str] = []
        for item in tools:
            if isinstance(item, str):
                result.append(item)
            elif isinstance(item, dict):
                # 工具定义可能是字典格式 {name: ..., description: ...}
                result.append(str(item.get("name", "")))
            else:
                result.append(str(item))
        return result
    return []

def _deduplicate_list(items: list[str]) -> list[str]:
    """去重列表，保持原始顺序"""
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        if item and item not in seen:
            seen.add(item)
            result.append(item)
    return result

def _to_str(value: Any) -> str:
    """安全地将任意值转换为字符串，None 变为空字符串"""
    if value is None:
        return ""
    return str(value)

def _error_result(skill_dir: Path, error_msg: str) -> dict[str, Any]:
    """构造加载失败时的错误返回字典

    即使失败也返回结构完整的字典，方便调用方统一处理。
    """
    return {
        "name": skill_dir.name,
        "version": "0.0.0",
        "description": "",
        "instructions": "",
        "tools": [],
        "metadata": {},
        "install_path": str(skill_dir),
        "source": "none",
        "error": error_msg,
    }
