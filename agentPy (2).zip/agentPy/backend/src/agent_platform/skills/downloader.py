"""Skill 下载器模块

从远程源（GitHub Releases / GitLab / 直接 ZIP 链接）下载并解压
Skill 压缩包，校验解压后的目录结构，最终返回本地安装路径。

核心流程:
    1. 识别 URL 来源类型 (GitHub / GitLab / 直链 ZIP)
    2. 使用 httpx 异步流式下载 ZIP 到临时文件
    3. 解压 ZIP 到 skills_data_dir 下的目标目录
    4. 校验解压后是否存在 SKILL.md 或 skill.yaml
    5. 清理临时文件，返回安装路径
"""

from __future__ import annotations

import asyncio
import re
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx
import logfire

from agent_platform.config import get_settings

_logger_name = "agent_platform.skills.downloader"
import logging
_logger = logging.getLogger(_logger_name)

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

# 校验文件 — 解压后必须存在其中之一
_REQUIRED_FILES = ("SKILL.md", "skill.yaml", "skill.yml")

# ZIP 包大小上限 — 50 MB
_MAX_ZIP_SIZE = 50 * 1024 * 1024

# httpx 超时配置 (连接 10s / 读取 30s)
_HTTP_TIMEOUT = httpx.Timeout(connect=10.0, read=30.0, write=30.0, pool=10.0)

# 下载进度回调的数据类型
_ChunkStats = dict[str, Any]


# ---------------------------------------------------------------------------
# 异常
# ---------------------------------------------------------------------------

class SkillDownloadError(Exception):
    """Skill 下载过程中发生的错误"""

    def __init__(self, message: str, *, source: str | None = None) -> None:
        self.source = source
        super().__init__(message)


class SkillValidationFailedError(Exception):
    """Skill 解压后结构校验失败"""

    def __init__(self, message: str, *, install_path: Path | None = None) -> None:
        self.install_path = install_path
        super().__init__(message)


# ---------------------------------------------------------------------------
# URL 工具
# ---------------------------------------------------------------------------

class URLType:
    """URL 来源类型标记"""

    GITHUB_RELEASE = "github_release"
    GITLAB_ARCHIVE = "gitlab_archive"
    DIRECT_ZIP = "direct_zip"


def detect_url_type(url: str) -> str:
    """检测 URL 所属的来源类型

    根据域名和路径特征判断是 GitHub Release、GitLab 归档还是直链 ZIP。

    Args:
        url: 待检测的 URL 字符串

    Returns:
        URLType 常量之一

    Raises:
        SkillDownloadError: URL 格式不合法
    """
    parsed = urlparse(url)
    if not parsed.scheme or not parsed.netloc:
        raise SkillDownloadError(
            f"无效的 URL 格式: {url}",
            source=url,
        )

    host = parsed.netloc.lower()

    if "github.com" in host:
        return URLType.GITHUB_RELEASE
    if "gitlab.com" in host:
        return URLType.GITLAB_ARCHIVE

    return URLType.DIRECT_ZIP


def normalize_download_url(url: str) -> str:
    """标准化下载 URL

    对于 GitHub / GitLab 仓库首页链接，自动转换为对应的 ZIP 归档下载链接。
    直链 ZIP 直接原样返回。

    Args:
        url: 原始 URL

    Returns:
        可直接用于下载的 ZIP URL

    Raises:
        SkillDownloadError: 无法推断下载链接
    """
    parsed = urlparse(url)
    host = parsed.netloc.lower()
    path = parsed.path.rstrip("/")

    # GitHub 仓库首页 -> archive ZIP
    if "github.com" in host and not path.endswith(".zip"):
        # 例如: https://github.com/org/repo -> archive.zip
        parts = path.strip("/").split("/")
        if len(parts) >= 2:
            org, repo = parts[0], parts[1]
            return f"https://github.com/{org}/{repo}/archive/refs/heads/main.zip"
        raise SkillDownloadError(
            f"无法从 GitHub URL 推断下载链接: {url}",
            source=url,
        )

    # GitLab 仓库首页 -> archive ZIP
    if "gitlab.com" in host and not path.endswith(".zip"):
        parts = path.strip("/").split("/")
        if len(parts) >= 2:
            group, project = parts[0], parts[1]
            return f"https://gitlab.com/{group}/{project}/-/archive/main/{project}-main.zip"
        raise SkillDownloadError(
            f"无法从 GitLab URL 推断下载链接: {url}",
            source=url,
        )

    return url


def extract_skill_name(url: str) -> str:
    """从 URL 中提取 Skill 名称

    优先取 ZIP 文件名（去掉扩展名），失败则取路径最后一段。

    Args:
        url: 下载 URL

    Returns:
        小写的 Skill 名称（仅含字母、数字、连字符和下划线）
    """
    parsed = urlparse(url)
    filename = Path(parsed.path).stem

    # 清理 Git 归档常见的后缀 (如 repo-main -> repo)
    filename = re.sub(r"-(?:main|master|HEAD)\.zip$", "", filename)
    filename = Path(filename).stem  # 再次去扩展名

    # 如果文件名是 archive，取父目录名
    if filename == "archive":
        filename = Path(parsed.path).parent.name

    # 规范化为合法的目录名
    name = re.sub(r"[^a-zA-Z0-9_-]", "-", filename.lower())
    name = re.sub(r"-{2,}", "-", name).strip("-")

    return name or "unnamed-skill"


# ---------------------------------------------------------------------------
# 下载逻辑
# ---------------------------------------------------------------------------

async def download_zip(url: str, tmp_path: Path) -> None:
    """异步流式下载 ZIP 文件到临时路径

    使用 httpx 异步流式读取，避免将整个文件加载到内存中。
    下载过程中校验文件大小不超过上限。

    Args:
        url: ZIP 文件的下载 URL
        tmp_path: 本地临时文件路径

    Raises:
        SkillDownloadError: 网络错误、超时、文件大小超限或服务器非 2xx
    """
    _logger.info("开始下载 ZIP", url=url, dest=str(tmp_path))

    headers = {
        "User-Agent": "AgentPy-Skill-Downloader/0.1",
        "Accept": "application/zip, application/octet-stream, */*",
    }

    try:
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT, follow_redirects=True) as client:
            async with client.stream("GET", url, headers=headers) as response:
                # 检查 HTTP 状态码
                if response.status_code >= 400:
                    raise SkillDownloadError(
                        f"下载失败: HTTP {response.status_code} - {response.reason_phrase}",
                        source=url,
                    )

                # 尝试读取 Content-Length 以预估大小
                content_length = response.headers.get("content-length")
                total_size = int(content_length) if content_length else None

                if total_size and total_size > _MAX_ZIP_SIZE:
                    raise SkillDownloadError(
                        f"ZIP 文件过大 ({total_size / 1024 / 1024:.1f} MB)，上限为 {_MAX_ZIP_SIZE / 1024 / 1024:.0f} MB",
                        source=url,
                    )

                # 流式写入临时文件
                downloaded = 0
                async with tmp_path.open("wb") as f:
                    async for chunk in response.aiter_bytes(chunk_size=64 * 1024):
                        downloaded += len(chunk)
                        # 运行时检查大小
                        if downloaded > _MAX_ZIP_SIZE:
                            tmp_path.unlink(missing_ok=True)
                            raise SkillDownloadError(
                                f"ZIP 文件过大 ({downloaded / 1024 / 1024:.1f} MB)，下载已中止",
                                source=url,
                            )
                        f.write(chunk)

    except httpx.TimeoutException as e:
        tmp_path.unlink(missing_ok=True)
        raise SkillDownloadError(
            f"下载超时: {e}",
            source=url,
        ) from e
    except httpx.RequestError as e:
        tmp_path.unlink(missing_ok=True)
        raise SkillDownloadError(
            f"网络请求失败: {e}",
            source=url,
        ) from e

    mb = downloaded / 1024 / 1024
    _logger.info("ZIP 下载完成", url=url, size_mb=round(mb, 2))


# ---------------------------------------------------------------------------
# 解压逻辑
# ---------------------------------------------------------------------------

def extract_zip(tmp_zip: Path, dest_dir: Path) -> Path:
    """解压 ZIP 到目标目录

    解压策略:
    - 如果 ZIP 顶层只有一个目录，直接将该目录内容解压到 dest_dir
    - 否则整个 ZIP 内容解压到 dest_dir

    解压完成后删除临时 ZIP 文件。

    Args:
        tmp_zip: ZIP 临时文件路径
        dest_dir: 目标安装目录

    Returns:
        实际的 Skill 安装路径（解压后的目录）

    Raises:
        SkillDownloadError: ZIP 损坏或解压失败
    """
    dest_dir.mkdir(parents=True, exist_ok=True)

    try:
        with zipfile.ZipFile(tmp_zip, "r") as zf:
            # 安全校验: 检查所有条目路径，防止 ZIP Slip 攻击
            for member in zf.namelist():
                member_path = Path(member)
                if member_path.is_absolute() or ".." in member_path.parts:
                    raise SkillDownloadError(
                        f"ZIP 包含不安全的路径条目: {member}",
                    )

            # 判断是否需要"去顶层目录" — 即 ZIP 里只有一个顶层文件夹
            top_level = _get_top_level_entries(zf)
            single_dir: Path | None = None
            if len(top_level) == 1 and top_level[0].is_dir():
                single_dir = top_level[0]

            # 执行解压
            zf.extractall(dest_dir)
            zf.close()

    except zipfile.BadZipFile as e:
        raise SkillDownloadError(
            f"ZIP 文件已损坏或格式无效: {e}",
        ) from e
    except Exception as e:
        raise SkillDownloadError(
            f"解压失败: {e}",
        ) from e
    finally:
        # 无论成功失败都清理临时文件
        tmp_zip.unlink(missing_ok=True)

    # 如果 ZIP 里只有一个顶层目录，把内容移出来
    if single_dir:
        extracted_dir = dest_dir / single_dir.name
        if extracted_dir.is_dir():
            for item in extracted_dir.iterdir():
                shutil.move(str(item), str(dest_dir / item.name))
            extracted_dir.rmdir()
            _logger.info(
                "已从 ZIP 中移除顶层目录 {dir}",
                dir=single_dir.name,
            )

    return dest_dir


def _get_top_level_entries(zf: zipfile.ZipFile) -> list[Path]:
    """获取 ZIP 顶层条目列表

    Args:
        zf: 已打开的 ZipFile 对象

    Returns:
        顶层目录/文件的 Path 列表
    """
    top_dirs: dict[str, Path] = {}
    for name in zf.namelist():
        parts = Path(name).parts
        if len(parts) >= 1:
            root = parts[0]
            if root not in top_dirs:
                is_dir = name.endswith("/") or any(
                    n.startswith(root + "/") for n in zf.namelist() if n != name
                )
                top_dirs[root] = Path(root)
                # 简化判断: 只要有子条目就是目录
    return list(top_dirs.values())


# ---------------------------------------------------------------------------
# 结构校验
# ---------------------------------------------------------------------------

def validate_skill_structure(install_path: Path) -> str:
    """校验解压后的 Skill 目录结构

    检查是否存在 SKILL.md 或 skill.yaml / skill.yml 文件。

    Args:
        install_path: Skill 解压后的目录

    Returns:
        找到的校验文件名

    Raises:
        SkillValidationFailedError: 未找到任何校验文件
    """
    if not install_path.is_dir():
        raise SkillValidationFailedError(
            f"安装路径不是有效目录: {install_path}",
            install_path=install_path,
        )

    found = [f for f in _REQUIRED_FILES if (install_path / f).exists()]

    if not found:
        # 列出实际文件，帮助调试
        files = [p.name for p in install_path.iterdir() if p.is_file()]
        raise SkillValidationFailedError(
            f"Skill 结构无效 — 未找到 {_REQUIRED_FILES} 中的任何一个。"
            f" 当前文件: {files or '(空目录)'}",
            install_path=install_path,
        )

    # 返回优先级最高的匹配 (SKILL.md > skill.yaml > skill.yml)
    for required in _REQUIRED_FILES:
        if required in found:
            _logger.info(
                "Skill 结构校验通过",
                skill_path=str(install_path),
                manifest=required,
            )
            return required

    # 理论上不会到达这里
    raise SkillValidationFailedError(
        "校验逻辑错误: 无法确定 manifest 文件",
        install_path=install_path,
    )


# ---------------------------------------------------------------------------
# 清理逻辑
# ---------------------------------------------------------------------------

def cleanup_install_path(install_path: Path) -> None:
    """清理安装失败的遗留目录

    当校验或安装过程中出错时调用，删除不完整的安装目录。

    Args:
        install_path: 要清理的目录
    """
    if install_path.exists():
        shutil.rmtree(install_path, ignore_errors=True)
        _logger.warning("已清理不完整的安装目录", path=str(install_path))


# ---------------------------------------------------------------------------
# 主入口 — 一键下载并安装 Skill
# ---------------------------------------------------------------------------

async def download_and_install(source_url: str, *, name: str | None = None) -> Path:
    """下载、解压、校验并安装一个 Skill

    完整流程:
    1. 标准化 URL（仓库链接 -> ZIP 下载链接）
    2. 确定 Skill 名称和目标目录
    3. 下载 ZIP 到临时文件
    4. 解压到 skills_data_dir
    5. 校验目录结构（SKILL.md / skill.yaml）
    6. 返回安装路径

    Args:
        source_url: 远程源 URL（GitHub Release ZIP / GitLab 归档 / 直链）
        name: 可选的手动指定名称，不指定则从 URL 自动提取

    Returns:
        Skill 安装路径 (Path)

    Raises:
        SkillDownloadError: 下载失败（网络、超时、文件过大等）
        SkillValidationFailedError: 解压后结构校验失败
    """
    settings = get_settings()
    url_type = detect_url_type(source_url)
    normalized_url = normalize_download_url(source_url)
    skill_name = name or extract_skill_name(normalized_url)
    install_path = settings.skills_data_path / skill_name

    _logger.info(
        "开始安装 Skill",
        name=skill_name,
        url=source_url,
        url_type=url_type,
        install_path=str(install_path),
    )

    # 如果目标目录已存在，先清理以避免冲突
    if install_path.exists():
        _logger.warning("目标目录已存在，将先清理", path=str(install_path))
        cleanup_install_path(install_path)

    tmp_zip = Path(tempfile.gettempdir()) / f"skill-{skill_name}-{asyncio.get_running_loop().time():.0f}.zip"

    try:
        # 第一步: 下载 ZIP
        await download_zip(normalized_url, tmp_zip)

        # 第二步: 解压到目标目录
        extract_zip(tmp_zip, install_path)

        # 第三步: 校验目录结构
        manifest = validate_skill_structure(install_path)

        _logger.info(
            "Skill 安装成功",
            name=skill_name,
            path=str(install_path),
            manifest=manifest,
        )

        return install_path

    except (SkillDownloadError, SkillValidationFailedError):
        # 已知异常直接抛出，上层处理
        cleanup_install_path(install_path)
        raise
    except Exception as e:
        # 未知异常包装后抛出
        cleanup_install_path(install_path)
        raise SkillDownloadError(
            f"安装 Skill 时发生未知错误: {e}",
            source=source_url,
        ) from e
