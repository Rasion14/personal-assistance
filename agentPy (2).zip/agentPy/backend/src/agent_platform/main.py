"""FastAPI 应用入口

负责:
1. 创建 FastAPI 实例
2. 配置 CORS、速率限制、API Key 认证等 Middleware
3. 挂载所有 API 路由
4. 初始化 Logfire 可观测性 (如配置了 token)
5. 注册全局异常处理器
"""

from __future__ import annotations

import time
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from agent_platform.config import get_settings
from agent_platform.conversations.storage import get_storage
from agent_platform.errors import register_exception_handlers
from agent_platform.middleware.request_id import RequestIDMiddleware
from agent_platform.observability import configure_observability
from agent_platform.security import create_security_middleware


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None]:
    """应用生命周期管理

    启动时初始化配置、创建必要目录、连接数据库、配置可观测性。
    关闭时执行清理逻辑。
    """
    settings = get_settings()
    # 启动时确保目录存在
    settings.skills_data_path.mkdir(parents=True, exist_ok=True)
    settings.sandbox_path.mkdir(parents=True, exist_ok=True)

    # 生产环境安全校验
    if settings.is_production and settings.api_key == "default-dev-key-change-me":
        raise RuntimeError(
            "生产环境必须修改 API_KEY 配置，不能使用默认密钥。"
            "请在 .env 文件中设置 API_KEY 环境变量。"
        )

    # 连接数据库
    storage = get_storage()
    await storage.connect()

    # 记录启动时间
    app.state.start_time = time.time()

    # 配置可观测性 (在 DB 连接之后，确保 tracer 可用)
    if settings.logfire_token:
        configure_observability(app)

    yield  # 应用运行中

    # 关闭时的清理逻辑
    await storage.close()


def create_app() -> FastAPI:
    """创建并配置 FastAPI 应用实例"""
    settings = get_settings()

    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description="Enterprise-grade AI Agent Platform built with Pydantic AI",
        lifespan=lifespan,
        docs_url="/api/docs" if settings.app_debug else None,
        redoc_url="/api/redoc" if settings.app_debug else None,
    )

    # ==================== CORS Middleware ====================
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ==================== 安全中间件 ====================
    for middleware_cls, kwargs in create_security_middleware():
        app.add_middleware(middleware_cls, **kwargs)

    # ==================== 请求追踪 ====================
    app.add_middleware(RequestIDMiddleware)

    # ==================== 注册全局异常处理器 ====================
    register_exception_handlers(app)

    # ==================== 路由注册 ====================
    from agent_platform.api.router_health import router as health_router
    from agent_platform.api.router_chat import router as chat_router
    from agent_platform.api.router_stream import router as stream_router
    from agent_platform.api.router_models import router as models_router
    from agent_platform.api.router_skills import router as skills_router
    from agent_platform.api.router_personas import router as personas_router
    from agent_platform.api.router_conversations import router as conversations_router

    app.include_router(health_router, prefix="/api", tags=["健康检查"])
    app.include_router(chat_router, prefix="/api/chat", tags=["对话"])
    app.include_router(stream_router, prefix="/api/chat", tags=["流式对话"])
    app.include_router(models_router, prefix="/api/models", tags=["模型管理"])
    app.include_router(skills_router, prefix="/api/skills", tags=["Skill 管理"])
    app.include_router(personas_router, prefix="/api/personas", tags=["人设管理"])
    from agent_platform.api.router_tools import router as tools_router
    app.include_router(conversations_router, prefix="/api/conversations", tags=["对话管理"])
    app.include_router(tools_router, prefix="/api/tools", tags=["工具管理"])

    return app


# 导出 ASGI 应用，供 uvicorn 直接引用
app = create_app()
