"""安全中间件模块

实现:
1. API Key 认证 — 校验 X-API-Key 请求头
2. 速率限制 — 基于内存的滑动窗口限流
3. 白名单路径 — 健康检查、文档等公开接口无需认证

注意: slowapi 新版 API 不直接暴露 open()/errors，
这里使用内置限流实现，兼容所有 slowapi 版本。
"""

from __future__ import annotations

import time
from collections import defaultdict
from dataclasses import dataclass, field

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

from agent_platform.config import get_settings

# 无需认证的公开路径白名单
# 注意: 白名单仅对认证放行, 速率限制仍会对白名单路径放行
_PUBLIC_PATHS = {
    "/api/health",
    "/api/health/ready",
    "/api/docs",
    "/api/redoc",
    "/openapi.json",
}


# ====================================================================
# 内存限流器 (替代 slowapi 兼容层)
# ====================================================================

@dataclass
class _RateLimiter:
    """简单的固定窗口限流器

    按 key 分组，记录每个窗口内的请求计数。
    """
    max_requests: int = 20
    window_seconds: int = 60
    _requests: dict[str, list[float]] = field(default_factory=lambda: defaultdict(list))

    def is_rate_limited(self, key: str) -> tuple[bool, int | None]:
        """检查是否被限流

        Returns:
            (是否被限流, 剩余秒数或 None)
        """
        now = time.time()
        cutoff = now - self.window_seconds

        # 清理过期请求
        self._requests[key] = [
            t for t in self._requests[key] if t > cutoff
        ]

        if len(self._requests[key]) >= self.max_requests:
            oldest = self._requests[key][0]
            retry_after = int(oldest + self.window_seconds - now) + 1
            return True, max(1, retry_after)

        self._requests[key].append(now)
        return False, None


# 全局限流器实例
_rate_limiter: _RateLimiter | None = None


def _get_rate_limiter() -> _RateLimiter:
    global _rate_limiter
    if _rate_limiter is None:
        settings = get_settings()
        _rate_limiter = _RateLimiter(
            max_requests=settings.rate_limit_requests,
            window_seconds=settings.rate_limit_window,
        )
    return _rate_limiter


# ====================================================================
# API Key 认证中间件
# ====================================================================
class APIKeyAuthMiddleware(BaseHTTPMiddleware):
    """API Key 认证中间件

    检查请求头中的 X-API-Key 是否与配置中的密钥匹配。
    白名单路径和开发模式下的默认密钥会跳过认证。
    """

    async def dispatch(self, request: Request, call_next):
        # CORS 预检请求 (OPTIONS) 不携带自定义头, 必须放行
        if request.method == "OPTIONS":
            return await call_next(request)

        # 白名单路径直接放行, 无需认证
        if request.url.path in _PUBLIC_PATHS:
            return await call_next(request)

        settings = get_settings()

        # 开发模式下未修改默认密钥时跳过认证, 方便本地调试
        if settings.app_env == "development" and settings.api_key == "default-dev-key-change-me":
            return await call_next(request)

        api_key = request.headers.get("X-API-Key")
        if not api_key or api_key != settings.api_key:
            return JSONResponse(
                status_code=401,
                content={
                    "error": {
                        "code": "UNAUTHORIZED",
                        "message": "无效或缺少 API Key",
                    }
                },
                headers={"WWW-Authenticate": "ApiKey"},
            )

        response = await call_next(request)
        return response


# ====================================================================
# 速率限制中间件
# ====================================================================
class RateLimitMiddleware(BaseHTTPMiddleware):
    """基于内存固定窗口的速率限制中间件

    按 API Key 对请求进行限流, 白名单路径跳过限流。
    """

    async def dispatch(self, request: Request, call_next):
        # OPTIONS 预检请求和白名单路径不限流
        if request.method == "OPTIONS" or request.url.path in _PUBLIC_PATHS:
            return await call_next(request)

        # 获取限流 key (优先 API Key, 否则远程地址)
        key = request.headers.get("X-API-Key") or (request.client.host if request.client else "unknown")

        limiter = _get_rate_limiter()
        limited, retry_after = limiter.is_rate_limited(key)

        if limited:
            return JSONResponse(
                status_code=429,
                content={
                    "error": {
                        "code": "RATE_LIMITED",
                        "message": "请求频率过高",
                    }
                },
                headers={
                    "Retry-After": str(retry_after) if retry_after else "60",
                },
            )

        response = await call_next(request)
        return response


# ====================================================================
# 中间件工厂函数 — 供 main.py 调用
# ====================================================================
def create_security_middleware() -> list[tuple]:
    """创建安全中间件列表

    返回 (中间件类, 构造参数字典) 的列表, 供 FastAPI app.add_middleware() 循环使用。
    顺序: 先认证后限流, 确保无效 Key 不会浪费限流配额。

    Returns:
        [(APIKeyAuthMiddleware, {}), (RateLimitMiddleware, {})]
    """
    return [
        (APIKeyAuthMiddleware, {}),
        (RateLimitMiddleware, {}),
    ]
