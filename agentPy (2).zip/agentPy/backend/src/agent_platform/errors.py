"""统一错误处理模块

定义结构化错误响应格式和全局异常处理器，
所有 API 错误返回一致的错误码和消息。
"""

from __future__ import annotations

import logging
import uuid
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

_logger = logging.getLogger("agent_platform.errors")


# ---------------------------------------------------------------------------
# 错误码常量
# ---------------------------------------------------------------------------

class ErrorCode:
    # 客户端错误 (4xxx)
    VALIDATION_ERROR = "VALIDATION_ERROR"  # 400
    UNAUTHORIZED = "UNAUTHORIZED"  # 401
    FORBIDDEN = "FORBIDDEN"  # 403
    NOT_FOUND = "NOT_FOUND"  # 404
    CONFLICT = "CONFLICT"  # 409
    RATE_LIMITED = "RATE_LIMITED"  # 429
    TIMEOUT = "TIMEOUT"  # 408

    # 服务端错误 (5xxx)
    AGENT_EXECUTION_FAILED = "AGENT_EXECUTION_FAILED"  # 500
    MODEL_ERROR = "MODEL_ERROR"  # 502
    INTERNAL_ERROR = "INTERNAL_ERROR"  # 500


# ---------------------------------------------------------------------------
# 自定义异常
# ---------------------------------------------------------------------------

class AgentPlatformError(Exception):
    """Agent Platform 基础异常

    Attributes:
        error_code: 错误码 (ErrorCode 常量)
        message: 用户可读的错误消息
        status_code: HTTP 状态码
    """

    def __init__(
        self,
        message: str,
        *,
        error_code: str = ErrorCode.INTERNAL_ERROR,
        status_code: int = 500,
    ) -> None:
        self.error_code = error_code
        self.message = message
        self.status_code = status_code
        super().__init__(message)


class ValidationError(AgentPlatformError):
    """请求验证错误"""

    def __init__(self, message: str, *, error_code: str = ErrorCode.VALIDATION_ERROR) -> None:
        super().__init__(message, error_code=error_code, status_code=400)


class NotFoundError(AgentPlatformError):
    """资源未找到"""

    def __init__(self, message: str, *, error_code: str = ErrorCode.NOT_FOUND) -> None:
        super().__init__(message, error_code=error_code, status_code=404)


class UnauthorizedError(AgentPlatformError):
    """未授权"""

    def __init__(
        self,
        message: str = "缺少或无效的 API Key",
        *,
        error_code: str = ErrorCode.UNAUTHORIZED,
    ) -> None:
        super().__init__(message, error_code=error_code, status_code=401)


class ConflictError(AgentPlatformError):
    """资源冲突"""

    def __init__(self, message: str, *, error_code: str = ErrorCode.CONFLICT) -> None:
        super().__init__(message, error_code=error_code, status_code=409)


class TimeoutError(AgentPlatformError):
    """请求超时"""

    def __init__(
        self,
        message: str = "Agent 执行超时",
        *,
        error_code: str = ErrorCode.TIMEOUT,
    ) -> None:
        super().__init__(message, error_code=error_code, status_code=408)


# ---------------------------------------------------------------------------
# 结构化错误响应
# ---------------------------------------------------------------------------

def _build_error_response(
    status_code: int,
    error_code: str,
    message: str,
    request_id: str | None = None,
) -> JSONResponse:
    """构建结构化错误响应"""
    body: dict[str, Any] = {
        "error": {
            "code": error_code,
            "message": message,
        }
    }
    if request_id:
        body["error"]["request_id"] = request_id
    return JSONResponse(status_code=status_code, content=body)


# ---------------------------------------------------------------------------
# 全局异常处理器
# ---------------------------------------------------------------------------

def register_exception_handlers(app: FastAPI) -> None:
    """注册全局异常处理器到 FastAPI 应用"""

    @app.exception_handler(AgentPlatformError)
    async def agent_platform_error_handler(
        request: Request, exc: AgentPlatformError
    ) -> JSONResponse:
        request_id = request.scope.get("request_id", "") or ""
        _logger.warning(
            "AgentPlatformError %s request_id=%s msg=%s",
            exc.error_code, request_id, exc.message,
        )
        return _build_error_response(
            status_code=exc.status_code,
            error_code=exc.error_code,
            message=exc.message,
            request_id=request_id or None,
        )

    @app.exception_handler(StarletteHTTPException)
    async def http_exception_handler(
        request: Request, exc: StarletteHTTPException
    ) -> JSONResponse:
        request_id = request.scope.get("request_id", "") or ""
        return _build_error_response(
            status_code=exc.status_code,
            error_code="HTTP_ERROR",
            message=exc.detail if isinstance(exc.detail, str) else str(exc.detail),
            request_id=request_id or None,
        )

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        request_id = request.scope.get("request_id", "") or ""
        errors = []
        for err in exc.errors():
            loc = " -> ".join(str(l) for l in err.get("loc", []))
            msg = err.get("msg", "")
            errors.append(f"{loc}: {msg}")
        return _build_error_response(
            status_code=422,
            error_code=ErrorCode.VALIDATION_ERROR,
            message="; ".join(errors),
            request_id=request_id or None,
        )

    @app.exception_handler(Exception)
    async def global_exception_handler(
        request: Request, exc: Exception
    ) -> JSONResponse:
        request_id = request.scope.get("request_id", "") or ""
        _logger.error(
            "Unhandled exception request_id=%s type=%s msg=%s",
            request_id, type(exc).__name__, str(exc),
            exc_info=True,
        )
        # 不向客户端暴露内部错误细节
        return _build_error_response(
            status_code=500,
            error_code=ErrorCode.INTERNAL_ERROR,
            message="服务器内部错误",
            request_id=request_id or None,
        )
