"""可观测性配置模块

使用 Logfire 配置应用的全链路可观测性:
- Tracing: FastAPI 请求追踪、Pydantic AI Agent run 追踪
- Metrics: 对话计数、工具调用计数、响应延迟
- 结构化日志

遵循 Logfire 最佳实践: configure() 在 instrument_*() 之前调用。
"""

from __future__ import annotations

from fastapi import FastAPI

import logfire

from agent_platform.config import get_settings


def configure_observability(app: FastAPI) -> None:
    """配置可观测性

    在应用启动时调用一次，设置 Logfire 追踪和指标。
    如果未配置 LOGFIRE_TOKEN，则只配置本地输出。

    Args:
        app: FastAPI 应用实例
    """
    settings = get_settings()

    # 1. 配置 Logfire (必须在 instrument_* 之前调用)
    logfire.configure(
        send_to_logfire=settings.logfire_send_to_pydantic and bool(settings.logfire_token),
        service_name=settings.app_name,
        service_version=settings.app_version,
        environment=settings.app_env,
    )

    # 2. 仪器化 FastAPI — 追踪每个 HTTP 请求
    logfire.instrument_fastapi(app)

    # 3. 仪器化 Pydantic AI — 追踪 Agent run、工具调用、模型请求
    logfire.instrument_pydantic_ai()

    # 4. 仪器化 HTTPX — 追踪所有 HTTP 客户端请求
    logfire.instrument_httpx()

    # 5. 创建自定义指标
    global _conversation_counter, _tool_call_counter, _response_histogram

    _conversation_counter = logfire.metric_counter(
        "agent.conversations.total",
        unit="1",
        description="对话总次数",
    )

    _tool_call_counter = logfire.metric_counter(
        "agent.tool_calls.total",
        unit="1",
        description="工具调用总次数",
    )

    _response_histogram = logfire.metric_histogram(
        "agent.response.duration",
        unit="s",
        description="Agent 响应延迟 (秒)",
    )

    logfire.info(
        "Observability configured for {service_name} env={environment}",
        service_name=settings.app_name,
        environment=settings.app_env,
    )


# 自定义指标 — 全局引用
_conversation_counter = None
_tool_call_counter = None
_response_histogram = None


def record_conversation(status: str = "success") -> None:
    """记录一次对话"""
    if _conversation_counter:
        _conversation_counter.add(1, {"status": status})


def record_tool_call(tool_name: str) -> None:
    """记录一次工具调用"""
    if _tool_call_counter:
        _tool_call_counter.add(1, {"tool_name": tool_name})


def record_response_duration(seconds: float) -> None:
    """记录响应延迟"""
    if _response_histogram:
        _response_histogram.record(seconds)
