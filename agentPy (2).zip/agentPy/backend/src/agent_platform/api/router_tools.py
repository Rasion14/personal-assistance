"""Agent 工具管理路由

- GET  /api/tools       — 列出所有可用工具及源码
- PUT  /api/tools/{name} — 更新工具源码 (写入 tools/ 目录)
"""

from __future__ import annotations

import ast
from pathlib import Path

from pydantic import BaseModel

from fastapi import APIRouter, HTTPException

router = APIRouter()

TOOLS_DIR = Path(__file__).resolve().parent.parent / "tools"


class ToolUpdateRequest(BaseModel):
    source: str = ""   # Python 源码
    new_name: str = ""  # 新文件名 (重命名时使用)


@router.post("/rename")
async def rename_tool(old_name: str, new_name: str):
    """重命名工具文件"""
    if old_name in ("__init__", "base") or new_name in ("__init__", "base"):
        raise HTTPException(status_code=400, detail="不能修改核心文件")
    old_path = TOOLS_DIR / f"{old_name}.py"
    new_path = TOOLS_DIR / f"{new_name}.py"
    if not old_path.exists():
        raise HTTPException(status_code=404, detail=f"工具 {old_name} 不存在")
    if new_path.exists():
        raise HTTPException(status_code=409, detail=f"工具 {new_name} 已存在")
    old_path.rename(new_path)
    return {"success": True, "old_name": old_name, "new_name": new_name}


@router.get("")
async def list_tools():
    """列出所有可用工具 (从 get_all_tools() 获取实际 Tool 对象)"""
    from agent_platform.tools.base import get_all_tools
    all_tools = get_all_tools()
    tools = []
    for t in all_tools:
        tools.append({
            "name": t.name,
            "description": getattr(t, 'description', ''),
        })
    return {"tools": tools}


@router.get("/files")
async def list_tool_files():
    """列出工具源文件 (用于工具编辑页面)"""
    tools = []
    for f in sorted(TOOLS_DIR.glob("*.py")):
        if f.name.startswith("_") or f.name == "base.py":
            continue
        source = f.read_text(encoding="utf-8")
        funcs = _extract_functions(source)
        tools.append({
            "name": f.stem,
            "file": f.name,
            "functions": funcs,
            "source": source,
        })
    return {"tools": tools}


@router.post("/create")
async def create_tool(name: str, source: str = ""):
    """创建新工具文件"""
    if name in ("__init__", "base"):
        raise HTTPException(status_code=400, detail="不能使用保留名称")
    file_path = TOOLS_DIR / f"{name}.py"
    if file_path.exists():
        raise HTTPException(status_code=409, detail=f"工具 {name} 已存在")
    default_source = source or f'"""新工具: {name}"""\n\n\ndef {name}(query: str) -> str:\n    """处理查询"""\n    return f"结果: {{query}}"\n'
    file_path.write_text(default_source, encoding="utf-8")
    return {"success": True, "name": name}


@router.delete("/{name}")
async def delete_tool(name: str):
    """删除工具文件"""
    if name in ("__init__", "base"):
        raise HTTPException(status_code=400, detail="不能删除核心文件")
    file_path = TOOLS_DIR / f"{name}.py"
    if not file_path.exists():
        raise HTTPException(status_code=404, detail=f"工具 {name} 不存在")
    file_path.unlink()
    return {"success": True, "message": f"工具 {name} 已删除"}


@router.get("/{name}")
async def get_tool(name: str):
    """获取单个工具源码"""
    file_path = TOOLS_DIR / f"{name}.py"
    if not file_path.exists():
        raise HTTPException(status_code=404, detail=f"工具 {name} 不存在")
    return {"name": name, "source": file_path.read_text(encoding="utf-8")}


@router.put("/{name}")
async def update_tool(name: str, req: ToolUpdateRequest):
    """更新工具源码"""
    file_path = TOOLS_DIR / f"{name}.py"
    if not file_path.exists():
        raise HTTPException(status_code=404, detail=f"工具 {name} 不存在")
    if name in ("__init__", "base"):
        raise HTTPException(status_code=400, detail="不能修改核心文件")

    # 基本语法检查
    try:
        ast.parse(req.source)
    except SyntaxError as e:
        raise HTTPException(status_code=400, detail=f"Python 语法错误: {e}")

    file_path.write_text(req.source, encoding="utf-8")
    return {"success": True, "message": f"工具 {name} 已更新"}


def _extract_functions(source: str) -> list[dict]:
    """提取 Python 源文件中的函数定义"""
    funcs = []
    try:
        tree = ast.parse(source)
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if node.name.startswith("_"):
                    continue
                doc = ast.get_docstring(node) or ""
                funcs.append({
                    "name": node.name,
                    "doc": doc[:200],
                    "async": isinstance(node, ast.AsyncFunctionDef),
                })
    except SyntaxError:
        pass
    return funcs
