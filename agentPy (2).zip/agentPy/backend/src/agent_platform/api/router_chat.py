"""普通对话路由

处理非流式的 Agent 对话请求。
包含输入验证、超时控制、指标记录和结构化错误响应。
"""

from __future__ import annotations

import asyncio
import time

from pydantic import BaseModel, Field

from fastapi import APIRouter, Request

from agent_platform.agents.factory import create_resilient_agent
from agent_platform.config import get_settings
from agent_platform.conversations.service import get_service
from agent_platform.errors import TimeoutError, ValidationError, AgentPlatformError
from agent_platform.observability import record_response_duration, record_conversation
from agent_platform.skills.registry import get_registry


def _build_history(raw: list[dict] | None) -> list | None:
    """将前端传来的 [{role, content}] 转为 pydantic-ai ModelMessage 列表, 含上下文管理"""
    if not raw:
        return None
    from agent_platform.agents.context_manager import manage_context
    from agent_platform.config import get_settings
    settings = get_settings()

    # 上下文管理: 截断/滑动窗口
    managed = manage_context(
        raw,
        strategy=settings.context_strategy,
        max_messages=settings.max_context_messages,
        max_tokens=settings.max_context_tokens,
    )

    from pydantic_ai.messages import ModelRequest, ModelResponse, UserPromptPart, TextPart
    history = []
    for m in managed:
        role, content = m.get("role", ""), m.get("content", "")
        if role == "user":
            history.append(ModelRequest(parts=[UserPromptPart(content=content)]))
        elif role == "assistant":
            history.append(ModelResponse(parts=[TextPart(content=content)]))
    return history if history else None


async def _generate_title(user_msg: str, ai_reply: str) -> str:
    """根据首轮对话生成简短标题"""
    # 简单规则：提取用户消息的关键词
    text = user_msg.strip()
    # 截取前 15 个字符，去掉换行
    title = text.replace("\n", " ")[:15]
    if len(text) > 15:
        title += "…"
    return title if title else "新对话"


def _format_usage(u) -> dict:
    """兼容 pydantic-ai 2.x 的 RunUsage 对象"""
    try:
        return u.model_dump()
    except AttributeError:
        return {
            "request_tokens": getattr(u, "request_tokens", 0),
            "response_tokens": getattr(u, "response_tokens", 0),
            "total_tokens": getattr(u, "total_tokens", 0),
        }

router = APIRouter()


class ChatRequest(BaseModel):
    """对话请求"""

    message: str = Field(min_length=1, max_length=10000, description="用户消息内容")
    conversation_id: str = Field(default="", description="对话 ID")
    persona_id: str = Field(default="default", description="人设标识")
    model_id: str | None = Field(default=None, description="模型标识")
    enable_thinking: bool = Field(default=False, description="是否启用深度思考")
    enable_memory: bool | None = Field(default=None, description="跨会话记忆 (已弃用, 用 enable_cross_session)")
    message_history: list[dict] | None = Field(default=None, description="当前会话历史消息")
    enabled_tools: list[str] | None = Field(default=None, description="本次启用的工具名列表 (None=全部)")
    enabled_skills: list[str] | None = Field(default=None, description="本次启用的 skill 名列表 (None=全局配置)")
    enable_cross_session: bool = Field(default=False, description="是否启用跨会话记忆检索")


@router.post("")
async def chat(request_obj: ChatRequest, http_request: Request):
    """发送消息并获取 Agent 回复

    Args:
        request_obj: 包含用户消息和可选参数的请求体
        http_request: HTTP 请求上下文 (用于获取 request_id)

    Returns:
        Agent 的回复文本
    """
    settings = get_settings()
    model_id = request_obj.model_id or settings.default_model
    persona_id = request_obj.persona_id or "default"

    # 输入验证
    if len(request_obj.message) > settings.max_message_length:
        raise ValidationError(
            f"消息长度超过限制 ({settings.max_message_length} 字符)",
        )

    # 创建带韧性包装的 Agent (并发控制 + 重试 + 回退 + 压缩)
    registry = get_registry()
    registry.refresh()  # 每次请求前刷新，确保 skill 列表最新
    agent, deps = await create_resilient_agent(
        model_id=model_id,
        conversation_id=request_obj.conversation_id,
        persona_id=persona_id,
        skill_registry=registry,
        enable_thinking=request_obj.enable_thinking,
        enable_memory=request_obj.enable_memory,
        user_message=request_obj.message,
        enabled_tools=request_obj.enabled_tools,
        enabled_skills=request_obj.enabled_skills,
        enable_cross_session=request_obj.enable_cross_session,
    )

    start_time = time.time()
    try:
        # 带超时的 Agent 执行
        result = await asyncio.wait_for(
            agent.run(request_obj.message, deps=deps, message_history=_build_history(request_obj.message_history)),
            timeout=settings.agent_request_timeout,
        )
        elapsed = time.time() - start_time

        # 持久化消息到对话存储
        content = str(result.output)[: settings.max_response_length]
        if request_obj.conversation_id:
            conv_service = get_service()
            await conv_service.add_message(request_obj.conversation_id, "user", request_obj.message, persona_id=persona_id, model_id=model_id)
            await conv_service.add_message(request_obj.conversation_id, "assistant", content, persona_id=persona_id, model_id=model_id)
            # 会话级存储 persona_id
            await conv_service.update_conversation(request_obj.conversation_id, persona_id=persona_id)
            conv = await conv_service.get_conversation(request_obj.conversation_id)
            if conv and conv.title == "新对话" and len(conv.messages) >= 2:
                try:
                    title = await _generate_title(request_obj.message, content)
                    await conv_service.update_conversation(request_obj.conversation_id, title=title)
                except Exception:
                    pass  # 标题生成失败不影响主流程

        # 记录指标
        record_response_duration(elapsed)
        record_conversation("success")

        return {
            "content": content,
            "conversation_id": request_obj.conversation_id,
            "model_id": model_id,
            "usage": _format_usage(result.usage) if hasattr(result, "usage") else {},
            "elapsed": round(elapsed, 2),
        }

    except asyncio.TimeoutError:
        record_conversation("timeout")
        raise TimeoutError(
            f"Agent 执行超时 ({settings.agent_request_timeout}s)",
        )
    except AgentPlatformError:
        record_conversation("error")
        raise
    except Exception as e:
        record_conversation("error")
        raise AgentPlatformError(
            "Agent 执行失败",
            error_code="AGENT_EXECUTION_FAILED",
        ) from e
