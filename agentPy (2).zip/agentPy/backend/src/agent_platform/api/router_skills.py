"""Skill 管理路由

提供 Skill 的安装、卸载、启用、禁用和列表查询功能。
"""

from __future__ import annotations

import shutil
import zipfile
import tempfile
from pathlib import Path

from pydantic import BaseModel, Field

from fastapi import APIRouter, HTTPException, UploadFile, File

from agent_platform.config import get_settings
from agent_platform.skills.downloader import download_and_install
from agent_platform.skills.downloader import SkillDownloadError, SkillValidationFailedError
from agent_platform.skills.loader import load_skill_from_directory
from agent_platform.skills.models import SkillInfo, SkillInstallRequest, SkillUninstallRequest
from agent_platform.skills.registry import get_registry

def _has_spec_file(directory: Path) -> bool:
    """检查目录顶层是否包含 SKILL.md 或 skill.yaml/skill.yml"""
    for name in ("SKILL.md", "skill.yaml", "skill.yml"):
        if (directory / name).exists():
            return True
    return False


def _find_skill_root(extract_path: Path) -> Path | None:
    """递归搜索包含 SKILL.md / skill.yaml 的目录

    从 extract_path 开始向下搜索，返回第一个包含规格文件的目录。
    如果找不到则返回 None。
    """
    if _has_spec_file(extract_path):
        return extract_path

    try:
        for entry in sorted(extract_path.iterdir(), key=lambda e: (e.is_file(), e.name)):
            if entry.is_dir() and not entry.name.startswith("."):
                result = _find_skill_root(entry)
                if result is not None:
                    return result
    except PermissionError:
        pass

    return None


def _flatten_skill_dir(extract_path: Path) -> Path:
    """将压缩包嵌套目录上提

    递归查找包含 SKILL.md / skill.yaml 的目录，
    将其内容移动到 extract_path 顶层，使 extract_path 直接包含规格文件。
    如果顶层已有规格文件或找不到任何规格文件，则不做处理。
    """
    # 顶层已有规格文件 → 无需处理
    if _has_spec_file(extract_path):
        return extract_path

    # 递归搜索包含规格文件的目录
    skill_root = _find_skill_root(extract_path)

    if skill_root is None or skill_root == extract_path:
        # 找不到规格文件，返回原始路径 (由 load_skill_from_directory 报错)
        return extract_path

    # 将 skill_root 中的所有内容移动到 extract_path
    for item in list(skill_root.iterdir()):
        target = extract_path / item.name
        if target.exists():
            if target.is_dir():
                shutil.rmtree(target)
            else:
                target.unlink()
        shutil.move(str(item), str(target))

    # 清理从 extract_path 到 skill_root 之间的空目录链
    _remove_empty_dirs_between(extract_path, skill_root)

    return extract_path


def _remove_empty_dirs_between(root: Path, target: Path) -> None:
    """删除 root 和 target 之间的空目录链 (包含 target 但不包含 root)"""
    # 从 target 向上逐个删除空目录，直到 root
    current = target
    while current != root and current.parent != current:
        try:
            if not any(current.iterdir()):
                current.rmdir()
            else:
                # 目录非空，停止清理（可能包含其他文件）
                break
        except (OSError, PermissionError):
            break
        current = current.parent


router = APIRouter()


@router.get("")
async def list_skills():
    """获取所有已安装的 Skill 列表"""
    registry = get_registry()
    registry.refresh()  # 每次查询前刷新，确保最新状态
    return {"skills": [skill.model_dump() for skill in registry.get_all()]}


@router.post("/install")
async def install_skill(request: SkillInstallRequest):
    """安装 Skill

    从远程 URL 下载并安装 Skill。

    Args:
        request: 包含 source_url 和可选 name 的请求体
    """
    registry = get_registry()

    # 确定 Skill 名称用于检查
    check_name = request.name or ""
    if check_name and registry.get_by_name(check_name):
        raise HTTPException(status_code=409, detail=f"Skill {check_name} 已存在")

    try:
        # 下载并安装 — 返回安装路径 (Path)
        install_path = await download_and_install(
            source_url=request.source_url,
            name=request.name,
        )

        # 加载 Skill 元数据
        loaded_data = load_skill_from_directory(install_path)
        if loaded_data.get("error"):
            raise HTTPException(
                status_code=400,
                detail=f"Skill 加载失败: {loaded_data['error']}",
            )

        # 构建 SkillInfo 并注册
        skill_info = SkillInfo(
            name=loaded_data.get("name", "unknown"),
            version=loaded_data.get("version", "0.0.0"),
            description=loaded_data.get("description", ""),
            install_path=str(install_path),
            instructions=loaded_data.get("instructions", ""),
            tools=loaded_data.get("tools", []),
            metadata=loaded_data.get("metadata", {}),
            source_url=request.source_url,
        )
        registry.add_skill(skill_info)

        return {
            "success": True,
            "message": f"Skill {skill_info.name} 安装成功",
            "skill": skill_info.model_dump(),
        }

    except (SkillDownloadError, SkillValidationFailedError) as e:
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"安装失败: {e}")


@router.post("/uninstall")
async def uninstall_skill(request: SkillUninstallRequest):
    """卸载 Skill"""
    registry = get_registry()
    if not registry.uninstall_skill(request.name):
        raise HTTPException(status_code=404, detail=f"Skill {request.name} 不存在")
    return {"success": True, "message": f"Skill {request.name} 已卸载"}


@router.post("/{name}/enable")
async def enable_skill(name: str):
    """启用 Skill"""
    registry = get_registry()
    skill = registry.enable_skill(name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill {name} 不存在")
    return {"success": True, "skill": skill.model_dump()}


@router.post("/{name}/disable")
async def disable_skill(name: str):
    """禁用 Skill"""
    registry = get_registry()
    skill = registry.disable_skill(name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill {name} 不存在")
    return {"success": True, "skill": skill.model_dump()}


@router.post("/upload")
async def upload_skill(file: UploadFile = File(...)):
    """上传本地 Skill zip 文件

    解压到 skills-data/uploaded/{name}/ 目录，
    自动注册到 Skill Registry。
    """
    if not file.filename or not file.filename.endswith(".zip"):
        raise HTTPException(status_code=400, detail="只支持 .zip 文件")

    settings = get_settings()
    upload_dir = settings.skills_data_path / "uploaded"
    upload_dir.mkdir(parents=True, exist_ok=True)

    # 保存临时文件
    with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp:
        tmp.write(await file.read())
        tmp_path = Path(tmp.name)

    try:
        # 解压到 uploaded/{name}
        skill_name = file.filename.replace(".zip", "").strip()
        extract_path = upload_dir / skill_name
        if extract_path.exists():
            shutil.rmtree(extract_path)

        with zipfile.ZipFile(tmp_path, "r") as zf:
            zf.extractall(extract_path)

        # 处理压缩包内部嵌套一层目录的情况：
        # 例如 zip 内含 building-pydantic-ai-agents/SKILL.md，
        # 解压后变成 .../uploaded/building-pydantic-ai-agents/building-pydantic-ai-agents/SKILL.md
        # 需要将嵌套子目录的内容上提一层
        actual_path = _flatten_skill_dir(extract_path)

        # 尝试加载
        loaded = load_skill_from_directory(actual_path)
        if loaded.get("error"):
            raise HTTPException(status_code=400, detail=f"Skill 无效: {loaded['error']}")

        registry = get_registry()
        info = SkillInfo(
            name=loaded.get("name", skill_name),
            version=loaded.get("version", "0.0.0"),
            description=loaded.get("description", ""),
            install_path=str(actual_path),
            instructions=loaded.get("instructions", ""),
            tools=loaded.get("tools", []),
            metadata={"source": "uploaded", **loaded.get("metadata", {})},
        )
        registry.add_skill(info)

        return {"success": True, "skill": info.model_dump()}
    finally:
        if tmp_path.exists():
            tmp_path.unlink()
