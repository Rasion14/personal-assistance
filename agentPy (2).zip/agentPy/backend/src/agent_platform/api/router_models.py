"""模型管理路由

提供可用模型列表查询和模型切换功能。
支持内置模型 + OpenAI 兼容 Provider (DeepSeek/Qwen等) + Ollama + vLLM。
"""

from __future__ import annotations

from pydantic import BaseModel

from fastapi import APIRouter

from agent_platform.models.registry import get_available_models, get_default_model
from agent_platform.models.resolver import resolve_model, list_available_models

router = APIRouter()


class ModelSwitchRequest(BaseModel):
    """切换模型请求"""

    model_id: str


@router.get("")
async def list_models():
    """获取所有可用模型列表（含自定义 Provider）"""
    return {
        "models": list_available_models(),
        "default": get_default_model(),
    }


@router.get("/current")
async def get_current_model():
    """获取当前默认模型"""
    return get_default_model()


@router.post("/switch")
async def switch_model(request: ModelSwitchRequest):
    """切换当前使用的模型

    Args:
        request: 包含目标 model_id 的请求体

    Returns:
        切换后的模型信息
    """
    # 验证 model_id 格式
    from agent_platform.models.registry import get_model_by_id

    resolved = resolve_model(request.model_id)

    # 查找模型信息
    all_models = list_available_models()
    model_info = None
    for m in all_models:
        if m["id"] == request.model_id:
            model_info = m
            break

    if model_info is None:
        model_info = {"id": request.model_id, "display_name": request.model_id}

    return {
        "success": True,
        "message": f"模型已切换为 {request.model_id}",
        "model": model_info,
    }
