"""健康检查路由

提供应用健康检查和版本信息接口。
- GET /health — liveness probe (服务是否存活)
- GET /health/ready — readiness probe (数据库是否就绪)
无需认证，供负载均衡器和监控系统使用。
"""

from __future__ import annotations

import time

from fastapi import APIRouter

from agent_platform.config import get_settings

router = APIRouter()


@router.get("/health")
async def health_check():
    """健康检查端点 (liveness probe)

    返回应用的基本状态信息，供负载均衡器使用。
    """
    settings = get_settings()
    uptime = time.time() - getattr(getattr(router, "app", None) or {}, "state", {}).get("start_time", time.time())
    return {
        "status": "healthy",
        "service": settings.app_name,
        "version": settings.app_version,
        "environment": settings.app_env,
    }


@router.get("/health/ready")
async def readiness_check():
    """就绪检查端点 (readiness probe)

    检查数据库连接是否可用。
    """
    from agent_platform.conversations.storage import get_storage

    try:
        storage = get_storage()
        # 如果数据库未连接，尝试连接
        if not storage._db:
            await storage.connect()
        return {
            "status": "ready",
            "database": "connected",
        }
    except Exception as e:
        return {
            "status": "not_ready",
            "database": f"error: {e}",
        }
