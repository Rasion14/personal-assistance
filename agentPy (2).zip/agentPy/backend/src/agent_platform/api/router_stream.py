"""SSE 流式对话路由

使用 Server-Sent Events (SSE) 实现实时流式对话，
前端可以逐 token 接收 Agent 回复并渲染打字动画效果。
包含输入验证、超时控制、指标记录和结构化错误响应。
"""

from __future__ import annotations

import asyncio
import json
import logging
import time

from pydantic import BaseModel, Field

from fastapi import APIRouter, Request
from sse_starlette.sse import EventSourceResponse

_logger = logging.getLogger("agent_platform.api.stream")

from agent_platform.agents.factory import create_resilient_agent
from agent_platform.compat.asyncio import asyncio_timeout
from agent_platform.config import get_settings
from agent_platform.errors import TimeoutError, ValidationError, AgentPlatformError
from agent_platform.observability import record_response_duration, record_conversation
from agent_platform.conversations.service import get_service
from agent_platform.skills.registry import get_registry


def _build_history(raw: list[dict] | None) -> list | None:
    if not raw: return None
    from pydantic_ai.messages import ModelRequest, ModelResponse, UserPromptPart, TextPart
    history = []
    for m in raw[-20:]:
        role, content = m.get("role", ""), m.get("content", "")
        if role == "user": history.append(ModelRequest(parts=[UserPromptPart(content=content)]))
        elif role == "assistant": history.append(ModelResponse(parts=[TextPart(content=content)]))
    return history or None


def _format_usage(u) -> dict:
    try:
        return u.model_dump()
    except AttributeError:
        return {
            "request_tokens": getattr(u, "request_tokens", 0),
            "response_tokens": getattr(u, "response_tokens", 0),
            "total_tokens": getattr(u, "total_tokens", 0),
        }


router = APIRouter()


class StreamChatRequest(BaseModel):
    """流式对话请求"""

    message: str = Field(min_length=1, max_length=10000, description="用户消息内容")
    conversation_id: str = Field(default="", description="对话 ID")
    persona_id: str = Field(default="default", description="人设标识")
    model_id: str | None = Field(default=None, description="模型标识")
    enable_thinking: bool = Field(default=False, description="是否启用深度思考")
    enable_memory: bool | None = Field(default=None, description="跨会话记忆 (已弃用, 用 enable_cross_session)")
    message_history: list[dict] | None = Field(default=None, description="当前会话历史消息")
    enabled_tools: list[str] | None = Field(default=None, description="本次启用的工具名列表 (None=全部)")
    enabled_skills: list[str] | None = Field(default=None, description="本次启用的 skill 名列表 (None=全局配置)")
    enable_cross_session: bool = Field(default=False, description="是否启用跨会话记忆检索")


@router.post("/stream")
async def stream_chat(request_obj: StreamChatRequest, http_request: Request):
    """流式对话端点

    使用 SSE 协议逐 chunk 推送 Agent 输出到前端。

    事件格式:
    - data: JSON 格式的文本片段
    - done: 结束标记
    - error: 错误信息
    - tool_call: 工具调用信息
    """
    settings = get_settings()
    model_id = request_obj.model_id or settings.default_model
    persona_id = request_obj.persona_id or "default"

    _logger.info("stream_chat: model=%s persona=%s tools=%s skills=%s cross_session=%s",
                 model_id, persona_id,
                 request_obj.enabled_tools, request_obj.enabled_skills,
                 request_obj.enable_cross_session)

    # 输入验证
    if len(request_obj.message) > settings.max_message_length:
        raise ValidationError(
            f"消息长度超过限制 ({settings.max_message_length} 字符)",
        )

    registry = get_registry()
    registry.refresh()  # 每次请求前刷新，确保 skill 列表最新
    agent, deps = await create_resilient_agent(
        model_id=model_id,
        conversation_id=request_obj.conversation_id,
        persona_id=persona_id,
        skill_registry=registry,
        enable_thinking=request_obj.enable_thinking,
        enable_memory=request_obj.enable_memory,
        user_message=request_obj.message,
        enabled_tools=request_obj.enabled_tools,
        enabled_skills=request_obj.enabled_skills,
        enable_cross_session=request_obj.enable_cross_session,
    )

    async def event_generator():
        """SSE 事件生成器"""
        start_time = time.time()
        total_content = ""

        try:
            # 带超时的流式执行 — 不传 message_history (与 Second Version 一致,
            # 确保角色风格不受历史消息干扰; 对话连续性由前端展示历史消息承担)
            async with asyncio_timeout(settings.agent_request_timeout):
                async with agent.run_stream(request_obj.message, deps=deps) as result:
                    # 逐 chunk 输出文本
                    async for text in result.stream_text(delta=True):
                        total_content += text
                        yield {
                            "event": "data",
                            "data": json.dumps({"content": text, "type": "text"}),
                        }

                    # 持久化消息 + 自动标题
                    if request_obj.conversation_id:
                        conv_service = get_service()
                        await conv_service.add_message(request_obj.conversation_id, "user", request_obj.message, persona_id=persona_id, model_id=model_id)
                        await conv_service.add_message(request_obj.conversation_id, "assistant", total_content, persona_id=persona_id, model_id=model_id)
                        conv = await conv_service.get_conversation(request_obj.conversation_id)
                        if conv and conv.title == "新对话" and len(conv.messages) >= 2:
                            try:
                                from agent_platform.api.router_chat import _generate_title
                                title = await _generate_title(request_obj.message, total_content)
                                await conv_service.update_conversation(request_obj.conversation_id, title=title)
                                # 重新导出 MD (带新标题)
                                from agent_platform.conversations.memory import save_conversation_md
                                msgs = [{"role": m.role, "content": m.content, "timestamp": m.timestamp.isoformat(), "tool_calls": m.tool_calls} for m in conv.messages]
                                save_conversation_md(conv.id, title, msgs, persona_id=persona_id, model_id=model_id, created_at=conv.created_at.isoformat())
                            except Exception:
                                pass

                    # 输出结束标记
                    elapsed = time.time() - start_time

                    # 记录指标
                    record_response_duration(elapsed)
                    record_conversation("success")

                    yield {
                        "event": "done",
                        "data": json.dumps({
                            "elapsed": round(elapsed, 2),
                            "usage": _format_usage(result.usage) if hasattr(result, "usage") else {},
                        }),
                    }

        except TimeoutError:
            record_conversation("timeout")
            raise
        except asyncio.TimeoutError:
            record_conversation("timeout")
            yield {
                "event": "error",
                "data": json.dumps({
                    "code": "TIMEOUT",
                    "error": f"Agent 执行超时 ({settings.agent_request_timeout}s)",
                }),
            }
        except AgentPlatformError:
            record_conversation("error")
            raise
        except Exception as e:
            record_conversation("error")
            yield {
                "event": "error",
                "data": json.dumps({
                    "code": "AGENT_EXECUTION_FAILED",
                    "error": "Agent 执行失败",
                }),
            }

    return EventSourceResponse(
        event_generator(),
        media_type="text/event-stream",
        sep="\n",
    )
