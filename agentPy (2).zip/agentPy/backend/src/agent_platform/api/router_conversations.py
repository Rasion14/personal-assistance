"""对话管理路由

提供对话的创建、列表、详情、删除等功能。
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

from pydantic import BaseModel

from fastapi import APIRouter, HTTPException

from agent_platform.config import get_settings
from agent_platform.conversations.memory import save_conversation_md, get_conv_md_dir
from agent_platform.conversations.service import get_service
from agent_platform.conversations.summarizer import generate_summary

_logger = logging.getLogger("agent_platform.api.conversations")

router = APIRouter()


class CreateConversationRequest(BaseModel):
    """创建对话请求"""

    title: str = "新对话"
    model_id: str = "anthropic:claude-sonnet-4-6"


class UpdateConversationRequest(BaseModel):
    """更新对话请求"""

    title: str | None = None
    model_id: str | None = None


@router.get("")
async def list_conversations(limit: int = 50):
    """获取对话列表 (DB + MD 文件合并)"""
    service = get_service()
    db_list = await service.list_conversations(limit)
    db_ids = {c["id"] for c in db_list}

    # 扫描 MD 文件目录，补充 DB 中不存在的对话
    md_dir = get_conv_md_dir()
    if md_dir.exists():
        for f in sorted(md_dir.glob("*.md"), key=lambda x: x.stat().st_mtime, reverse=True):
            # 从文件名提取 conv_id 前缀
            match = re.match(r"([a-f0-9]{8})_", f.name)
            if match:
                prefix = match.group(1)
                # 检查是否已在 DB 列表中
                found = any(c["id"].startswith(prefix) for c in db_list)
                if not found:
                    # 解析 MD 文件头部获取元数据
                    meta = _parse_md_meta(f)
                    db_list.append({
                        "id": meta.get("id", prefix),
                        "title": meta.get("title", f.stem),
                        "model_id": meta.get("model", ""),
                        "created_at": meta.get("created", ""),
                        "updated_at": "",
                        "message_count": meta.get("msg_count", 0),
                        "source": "md_only",  # 标记来源
                    })
            if len(db_list) >= limit:
                break

    return {"conversations": db_list[:limit]}


@router.post("")
async def create_conversation(request: CreateConversationRequest):
    """创建新对话"""
    service = get_service()
    conversation = await service.create_conversation(
        title=request.title,
        model_id=request.model_id,
    )
    return conversation


async def _find_conversation(conversation_id: str) -> dict | None:
    """查找对话: DB 优先, MD 文件回退。返回 dict 或 None"""
    service = get_service()

    # 1. 先查 DB
    conv = await service.get_conversation(conversation_id)
    if conv:
        return {
            "source": "db",
            "id": conv.id,
            "title": conv.title,
            "model_id": conv.model_id,
            "messages": [
                {
                    "id": m.id, "role": m.role, "content": m.content,
                    "timestamp": m.timestamp.isoformat(), "tool_calls": m.tool_calls,
                    "metadata": m.metadata,
                }
                for m in conv.messages
            ],
            "metadata": conv.metadata,
            "created_at": conv.created_at.isoformat(),
        }

    # 2. DB 中没有 → 尝试从 MD 文件加载
    md_dir = get_conv_md_dir()
    prefix = conversation_id[:8]
    for f in md_dir.glob(f"{prefix}*.md"):
        loaded = _load_conv_from_md(f)
        if loaded and loaded.get("id", "").startswith(prefix):
            loaded["source"] = "md"
            return loaded

    return None


@router.get("/{conversation_id}")
async def get_conversation(conversation_id: str):
    """获取对话详情 (DB 优先, MD 文件回退)"""
    result = await _find_conversation(conversation_id)
    if result is None:
        raise HTTPException(status_code=404, detail="对话不存在")
    return result


def _load_conv_from_md(file_path: Path) -> dict | None:
    """从 MD 文件加载对话内容"""
    try:
        content = file_path.read_text(encoding="utf-8")
        conv = {"id": "", "title": "", "model_id": "", "messages": [], "metadata": {}}
        current_role = ""
        current_content: list[str] = []

        for line in content.split("\n"):
            line = line.strip()
            if line.startswith("- **ID**:"):
                conv["id"] = line.split("`")[1] if "`" in line else ""
            elif line.startswith("- **模型**:"):
                conv["model_id"] = line.split(":", 1)[1].strip()
            elif line.startswith("- **人设**:"):
                conv["metadata"]["persona_id"] = line.split(":", 1)[1].strip()
            elif line.startswith("# 对话:"):
                conv["title"] = line.replace("# 对话:", "").strip()
            elif line.startswith("| ") and "| [" in line and "] |" in line:
                # 保存上一条消息
                if current_role and current_content:
                    conv["messages"].append({
                        "id": str(len(conv["messages"])),
                        "role": current_role,
                        "content": "\n".join(current_content).replace("\\n", "\n"),
                        "timestamp": "",
                        "metadata": {},
                    })
                # 解析新消息: | timestamp | [Role] | content |
                parts = line.split("|")
                if len(parts) >= 4:
                    role_tag = parts[2].strip()
                    current_role = "user" if "[User]" in role_tag else "assistant" if "[AI]" in role_tag else ""
                    current_content = [parts[3].strip()] if parts[3].strip() else []
            elif current_role and line and not line.startswith("|"):
                # 续行 (多行内容)
                if line and not line.startswith("#") and not line.startswith("-"):
                    current_content.append(line)

        # 保存最后一条消息
        if current_role and current_content:
            conv["messages"].append({
                "id": str(len(conv["messages"])),
                "role": current_role,
                "content": "\n".join(current_content).replace("\\n", "\n"),
                "timestamp": "",
                "metadata": {},
            })

        return conv if conv["id"] else None
    except Exception:
        return None


@router.put("/{conversation_id}")
async def update_conversation(conversation_id: str, request: UpdateConversationRequest):
    """更新对话信息"""
    service = get_service()
    conversation = await service.update_conversation(
        conversation_id=conversation_id,
        title=request.title,
        model_id=request.model_id,
    )
    if not conversation:
        raise HTTPException(status_code=404, detail="对话不存在")
    return conversation


@router.delete("/{conversation_id}")
async def delete_conversation(conversation_id: str):
    """删除对话 (DB + MD 文件)"""
    service = get_service()
    deleted_db = await service.delete_conversation(conversation_id)

    # 同步删除 MD 文件
    deleted_md = False
    md_dir = get_conv_md_dir()
    if md_dir.exists():
        prefix = conversation_id[:8]
        for f in md_dir.glob(f"{prefix}*.md"):
            f.unlink()
            deleted_md = True

    if not deleted_db and not deleted_md:
        raise HTTPException(status_code=404, detail="对话不存在")
    return {"success": True, "message": "对话已删除", "deleted_db": deleted_db, "deleted_md": deleted_md}


def _parse_md_meta(file_path: Path) -> dict:
    """解析 MD 文件头部元数据"""
    meta = {"id": file_path.stem[:8]}
    try:
        content = file_path.read_text(encoding="utf-8")
        for line in content.split("\n")[:10]:
            if line.startswith("- **ID**:"):
                meta["id"] = line.split("`")[1] if "`" in line else meta["id"]
            elif line.startswith("- **模型**:"):
                meta["model"] = line.split(":", 1)[1].strip()
            elif line.startswith("- **创建**:"):
                meta["created"] = line.split(":", 1)[1].strip()
        # 统计消息数 (以 | 开头的数据行)
        meta["msg_count"] = sum(1 for line in content.split("\n") if line.startswith("| ") and "| [User]" in line or "| [AI]" in line)
        # 提取 title
        title_match = re.match(r"^# 对话: (.+)", content)
        if title_match:
            meta["title"] = title_match.group(1).strip()
    except Exception:
        pass
    return meta


@router.delete("/{conversation_id}/messages/{message_index}")
async def delete_message(conversation_id: str, message_index: int):
    """删除对话中的某条消息及其配对的下一跳消息 (User→Assistant), 同步更新 DB + MD"""
    service = get_service()

    # 使用统一查找 (DB 优先, MD 回退)
    data = await _find_conversation(conversation_id)
    if not data:
        _logger.warning("delete_message: 对话不存在 conv_id=%s", conversation_id)
        raise HTTPException(status_code=404, detail="对话不存在")

    msgs = data["messages"]
    _logger.info("delete_message: conv_id=%s idx=%d total_msgs=%d source=%s",
                 conversation_id[:8], message_index, len(msgs), data.get("source"))

    if message_index < 0 or message_index >= len(msgs):
        raise HTTPException(status_code=400, detail="消息索引无效")

    # 删除指定消息; 如果是 user，同时删除紧跟的 assistant
    to_remove = {message_index}
    role_at_idx = msgs[message_index].get("role", "")
    if role_at_idx == "user" and message_index + 1 < len(msgs) and msgs[message_index + 1].get("role") == "assistant":
        to_remove.add(message_index + 1)
    elif role_at_idx == "assistant" and message_index > 0 and msgs[message_index - 1].get("role") == "user":
        to_remove.add(message_index - 1)

    # 更新消息列表
    data["messages"] = [m for i, m in enumerate(msgs) if i not in to_remove]

    # 保存到 DB (如来源是 MD, 先同步到 DB)
    try:
        from agent_platform.conversations.models import Conversation, Message as ConvMessage
        from datetime import datetime
        conv = Conversation(
            id=data["id"],
            title=data.get("title", "新对话"),
            model_id=data.get("model_id", ""),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.now(),
            metadata=data.get("metadata", {}),
        )
        for m in data["messages"]:
            conv.add_message(
                role=m["role"], content=m["content"],
                persona_id=data.get("metadata", {}).get("persona_id", "default"),
            )
        await service._storage.save_conversation(conv)
        _logger.info("delete_message: 已保存到 DB, 剩余 %d 条消息", len(data["messages"]))
    except Exception as e:
        _logger.error("delete_message: DB 保存失败: %s", e)

    # 重新导出 MD
    from agent_platform.conversations.memory import save_conversation_md
    persona_id = data.get("metadata", {}).get("persona_id", "default")
    md_msgs = [
        {"role": m["role"], "content": m["content"], "timestamp": m.get("timestamp", ""), "tool_calls": m.get("tool_calls", [])}
        for m in data["messages"]
    ]
    md_path = save_conversation_md(
        data["id"], data.get("title", "对话"), md_msgs,
        persona_id=persona_id, model_id=data.get("model_id", ""),
        created_at=data.get("created_at", ""),
    )
    _logger.info("delete_message: MD 已重新导出到 %s", md_path.name)

    return {"success": True, "deleted_indices": sorted(to_remove)}


@router.get("/{conversation_id}/export")
async def export_conversation(conversation_id: str):
    """导出对话为 Markdown

    返回生成的 MD 文件路径和内容预览。
    """
    service = get_service()
    conversation = await service.get_conversation(conversation_id)
    if not conversation:
        raise HTTPException(status_code=404, detail="对话不存在")

    msgs = [
        {
            "role": m.role,
            "content": m.content,
            "timestamp": m.timestamp.isoformat(),
            "tool_calls": m.tool_calls,
        }
        for m in conversation.messages
    ]
    file_path = save_conversation_md(
        conv_id=conversation.id,
        title=conversation.title,
        messages=msgs,
        persona_id=conversation.metadata.get("persona_id", "default"),
        model_id=conversation.model_id,
        created_at=conversation.created_at.isoformat(),
    )
    return {
        "success": True,
        "file": str(file_path),
        "message": f"对话已导出到 {file_path.name}",
    }


@router.post("/{conversation_id}/summarize")
async def summarize_conversation(conversation_id: str):
    """生成对话摘要

    提取关键点、标签、决策等，存入记忆索引供跨会话检索。
    """
    service = get_service()
    conversation = await service.get_conversation(conversation_id)
    if not conversation:
        raise HTTPException(status_code=404, detail="对话不存在")

    summary = generate_summary(conversation)
    return {
        "success": True,
        "summary": summary,
        "message": "摘要已生成并存入记忆索引",
    }
