"""API 路由模块

包含所有 HTTP API 端点的路由定义。
"""
