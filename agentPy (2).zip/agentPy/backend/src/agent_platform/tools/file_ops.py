"""文件操作工具

提供安全的文件读写和目录列出功能。
所有路径都限制在 sandbox_dir 内，防止越界访问。
添加了文件大小限制，防止读取过大文件。
"""

from __future__ import annotations

from pathlib import Path

from pydantic_ai import RunContext
from pydantic_ai.tools import Tool

from agent_platform.agents.deps import AgentDeps
from agent_platform.config import get_settings


def _safe_resolve(sandbox: Path, user_path: str) -> Path:
    """安全解析路径，确保不越出 sandbox 目录"""
    target = (sandbox / user_path).resolve()
    if not str(target).startswith(str(sandbox.resolve())):
        raise PermissionError(f"路径越界: {user_path}")
    return target


def read_file(ctx: RunContext[AgentDeps], file_path: str) -> str:
    """读取文件内容

    Args:
        file_path: 相对于 sandbox 的文件路径

    Returns:
        文件内容文本 (最多读取 max_file_read_bytes 字节)
    """
    settings = get_settings()
    try:
        sandbox = Path(ctx.deps.extra_context.get("sandbox_dir", str(settings.sandbox_path)))
        target = _safe_resolve(sandbox, file_path)
        if not target.exists():
            return f"文件不存在: {file_path}"
        if not target.is_file():
            return f"不是文件: {file_path}"
        # 检查文件大小
        file_size = target.stat().st_size
        if file_size > settings.max_file_read_bytes:
            return f"文件过大 ({file_size} 字节)，最大允许 {settings.max_file_read_bytes} 字节"
        return target.read_text(encoding="utf-8")
    except PermissionError:
        return f"访问被拒绝 (路径越界): {file_path}"
    except Exception as e:
        return f"读取失败: {e}"


def write_file(ctx: RunContext[AgentDeps], file_path: str, content: str) -> str:
    """写入文件内容

    Args:
        file_path: 相对于 sandbox 的文件路径
        content: 要写入的内容

    Returns:
        操作结果
    """
    settings = get_settings()
    try:
        sandbox = Path(ctx.deps.extra_context.get("sandbox_dir", str(settings.sandbox_path)))
        target = _safe_resolve(sandbox, file_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return f"已写入 {len(content)} 字节到 {file_path}"
    except PermissionError:
        return f"写入被拒绝 (路径越界): {file_path}"
    except Exception as e:
        return f"写入失败: {e}"


def list_dir(ctx: RunContext[AgentDeps], dir_path: str = ".") -> str:
    """列出目录内容

    Args:
        dir_path: 相对于 sandbox 的目录路径

    Returns:
        目录列表文本
    """
    settings = get_settings()
    try:
        sandbox = Path(ctx.deps.extra_context.get("sandbox_dir", str(settings.sandbox_path)))
        target = _safe_resolve(sandbox, dir_path)
        if not target.exists():
            return f"目录不存在: {dir_path}"
        if not target.is_dir():
            return f"不是目录: {dir_path}"
        items = []
        for item in sorted(target.iterdir()):
            prefix = "[DIR]  " if item.is_dir() else "[FILE] "
            items.append(f"{prefix}{item.name}")
        return "\n".join(items) if items else "目录为空"
    except PermissionError:
        return f"访问被拒绝 (路径越界): {dir_path}"
    except Exception as e:
        return f"列出失败: {e}"


read_file_tool = Tool(
    read_file,
    name="read_file",
    description="读取 sandbox 目录中的文件内容",
)

write_file_tool = Tool(
    write_file,
    name="write_file",
    description="向 sandbox 目录中的文件写入内容",
)

list_dir_tool = Tool(
    list_dir,
    name="list_dir",
    description="列出 sandbox 目录中的文件和子目录",
)
