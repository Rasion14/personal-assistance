"""网页搜索和抓取工具

使用 DuckDuckGo 进行免费搜索，使用 httpx 抓取网页内容。
"""

from __future__ import annotations

import re

import httpx
from pydantic_ai.tools import Tool


async def web_search(query: str, max_results: int = 5) -> str:
    """网页搜索

    使用 DuckDuckGo 免费搜索，无需 API Key。

    Args:
        query: 搜索关键词
        max_results: 最大结果数 (默认 5)

    Returns:
        搜索结果文本
    """
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                "https://html.duckduckgo.com/html/?q=" + httpx.URL.encode(query),
                headers={"User-Agent": "Mozilla/5.0 (Agent Platform)"},
            )
            resp.raise_for_status()
            html = resp.text
            titles = re.findall(r'<a class="result__title"[^>]*>(.*?)</a>', html, re.DOTALL)
            urls = re.findall(r'<a class="result__url"[^>]*>(.*?)</a>', html, re.DOTALL)
            snippets = re.findall(r'<a class="result__snippet"[^>]*>(.*?)</a>', html, re.DOTALL)

            results = []
            for i in range(min(max_results, len(titles))):
                title = re.sub(r'<[^>]+>', '', titles[i]).strip() if i < len(titles) else ""
                snippet = re.sub(r'<[^>]+>', '', snippets[i]).strip() if i < len(snippets) else ""
                url = re.sub(r'<[^>]+>', '', urls[i]).strip() if i < len(urls) else ""
                results.append(f"{title}\n{snippet}\n{url}")

            return "\n\n".join(results) if results else "未找到搜索结果"
    except Exception as e:
        return f"搜索失败: {e}"


async def web_fetch(url: str, max_length: int = 5000) -> str:
    """抓取网页内容

    Args:
        url: 目标 URL
        max_length: 最大返回长度

    Returns:
        网页文本内容
    """
    try:
        async with httpx.AsyncClient(timeout=15, follow_redirects=True) as client:
            resp = await client.get(url, headers={"User-Agent": "Mozilla/5.0 (Agent Platform)"})
            resp.raise_for_status()
            html = resp.text
            # 简单提取文本: 移除 HTML 标签
            text = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL | re.IGNORECASE)
            text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL | re.IGNORECASE)
            text = re.sub(r'<[^>]+>', ' ', text)
            text = re.sub(r'\s+', ' ', text).strip()
            return text[:max_length]
    except Exception as e:
        return f"抓取失败: {e}"


web_search_tool = Tool(
    web_search,
    name="web_search",
    description="使用 DuckDuckGo 搜索网页，返回标题、摘要和链接",
)

web_fetch_tool = Tool(
    web_fetch,
    name="web_fetch",
    description="抓取指定 URL 的网页内容，返回纯文本",
)
