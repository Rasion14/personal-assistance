"""工具注册基类

统一管理所有工具的注册和获取。
"""

from __future__ import annotations

from agent_platform.tools.calculator import calculator_tool
from agent_platform.tools.file_ops import read_file_tool, write_file_tool, list_dir_tool
from agent_platform.tools.web import web_search_tool, web_fetch_tool


def get_all_tools() -> list:
    """获取所有已注册的工具"""
    return [
        calculator_tool,
        web_search_tool,
        web_fetch_tool,
        read_file_tool,
        write_file_tool,
        list_dir_tool,
    ]
