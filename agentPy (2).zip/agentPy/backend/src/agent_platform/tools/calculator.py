"""计算器工具

提供数学计算能力，使用 Python 内置 eval 安全计算表达式。
仅允许数字和基本运算符，防止任意代码执行。
"""

from __future__ import annotations

import re
from pydantic_ai import Agent
from pydantic_ai.tools import Tool


def calculator(expression: str) -> str:
    """安全计算数学表达式

    Args:
        expression: 数学表达式 (如 "2 + 3 * 4", "sqrt(16)", "10 % 3")

    Returns:
        计算结果字符串
    """
    # 安全校验: 只允许数字、运算符、括号和空白字符
    sanitized = expression.strip()
    if not re.match(r'^[\d\+\-\*\/\%\(\)\.\s\:]+$', sanitized):
        return f"错误: 表达式包含非法字符: {expression}"

    try:
        # 使用受限的 eval，只允许 __builtins__ 为空
        result = eval(sanitized, {"__builtins__": {}}, {})
        return str(result)
    except Exception as e:
        return f"计算错误: {e}"


calculator_tool = Tool(
    calculator,
    name="calculator",
    description="安全计算数学表达式，支持加减乘除、取余、括号等",
)
