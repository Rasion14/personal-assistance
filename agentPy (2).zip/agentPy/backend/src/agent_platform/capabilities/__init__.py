"""Harness 能力注册模块

封装 pydantic-ai-harness 提供的能力: CodeMode, FileSystem, Shell, SubAgents, Planning, Compaction。

每个能力独立配置，统一通过 build_capabilities() 组合。
所有能力默认关闭，通过 Settings 配置按需启用。
"""

from __future__ import annotations

from pathlib import Path

from pydantic_ai.capabilities import Thinking


def build_capabilities(
    sandbox_dir: str | None = None,
    enable_thinking: bool = False,
    enable_planning: bool = False,
    enable_code_mode: bool = False,
    enable_filesystem: bool = False,
    enable_shell: bool = False,
    enable_subagents: bool = False,
    enable_compaction: bool = False,
    shell_commands: list[str] | None = None,
) -> list:
    """构建所有启用的 capabilities 列表

    Args:
        sandbox_dir: 沙箱工作目录 (FileSystem / CodeMode 使用)
        enable_thinking: 启用 Thinking 能力
        enable_planning: 启用 Planning 能力
        enable_code_mode: 启用 CodeMode 沙箱代码执行
        enable_filesystem: 启用 FileSystem 安全文件操作
        enable_shell: 启用 Shell 安全命令执行
        enable_subagents: 启用 SubAgents 子智能体委派
        enable_compaction: 启用 Compaction 对话历史压缩
        shell_commands: Shell 白名单命令列表 (默认使用安全最小集)

    Returns:
        capabilities 实例列表
    """
    capabilities = []

    # Thinking — 模型深度思考
    if enable_thinking:
        capabilities.append(Thinking(effort="high"))

    # Planning — 任务规划
    if enable_planning:
        try:
            from pydantic_ai_harness.planning import Planning
            capabilities.append(Planning())
        except ImportError:
            pass  # pydantic-ai-harness 未安装

    # CodeMode — 沙箱代码执行
    if enable_code_mode:
        try:
            from pydantic_ai_harness import CodeMode
            capabilities.append(CodeMode(tools="all", max_retries=3))
        except ImportError:
            pass  # codemode extra 未安装

    # FileSystem — 安全文件操作
    if enable_filesystem and sandbox_dir:
        try:
            from pydantic_ai_harness import FileSystem
            capabilities.append(FileSystem(root=Path(sandbox_dir)))
        except ImportError:
            pass  # pydantic-ai-harness 未安装

    # Shell — 安全命令执行
    if enable_shell:
        try:
            from pydantic_ai_harness import Shell
            # 使用配置提供的白名单，默认为安全最小集
            allowed = shell_commands or [
                "ls", "cat", "grep", "head", "tail", "wc", "sort",
                "python", "python3", "node",
                "mkdir", "echo", "date", "whoami",
                "curl", "diff",
            ]
            capabilities.append(Shell(
                allowed=allowed,
                default_timeout=30,
            ))
        except ImportError:
            pass  # pydantic-ai-harness 未安装

    # SubAgents — 子智能体委派
    if enable_subagents:
        try:
            from pydantic_ai_harness.subagents import SubAgents
            capabilities.append(SubAgents())
        except ImportError:
            pass  # pydantic-ai-harness 未安装

    # Compaction — 对话历史压缩
    if enable_compaction:
        try:
            from pydantic_ai_harness.compaction import SlidingWindow
            capabilities.append(SlidingWindow(max_tokens=100_000))
        except ImportError:
            pass  # pydantic-ai-harness 未安装

    return capabilities
