"""全局配置模块

使用 pydantic-settings 管理所有配置项，支持环境变量和 .env 文件。
分环境 (development / production) 自动切换日志级别和调试模式。

配置分为两类:
- 必要配置: 必须有值才能正常启动（如 APP_ENV, DEFAULT_MODEL, 至少一个 LLM Key）
- 可选配置: 有安全默认值，按需提供增强能力
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import ClassVar

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


def _find_env_file() -> str:
    """自动查找 .env 文件

    优先级:
    1. 当前目录
    2. config.py 所在目录 (backend/)
    3. 父目录 (项目根)
    """
    candidates = [
        Path.cwd() / ".env",
        Path(__file__).resolve().parent.parent.parent / ".env",  # backend/.env
        Path(__file__).resolve().parent.parent.parent.parent / ".env",  # project/.env
    ]
    for p in candidates:
        if p.exists():
            return str(p)
    return ".env"  # 回退


class Settings(BaseSettings):
    """全局应用配置

    所有配置项均可通过环境变量覆盖，优先级: 环境变量 > .env 文件 > 默认值
    """

    model_config = SettingsConfigDict(
        env_file=_find_env_file(),
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ==================== 必要配置 — 基础应用 ====================
    app_name: str = "agent-platform"
    app_env: str = "development"  # development | production
    app_debug: bool = True
    app_version: str = "0.1.0"

    # ==================== 必要配置 — API 认证 ====================
    api_key: str = Field(
        default="default-dev-key-change-me",
        description="API Key，前端请求需通过 X-API-Key 头携带",
    )

    # ==================== 必要配置 — LLM Provider ====================
    default_model: str = "anthropic:claude-sonnet-4-6"

    # ==================== 可选配置 — LLM Provider API Keys ====================
    anthropic_api_key: str = ""
    openai_api_key: str = ""
    google_genai_api_key: str = ""
    groq_api_key: str = ""

    # ==================== 可选配置 — OpenAI 兼容 Providers ====================
    # 格式: name:api_key:base_url:model1,model2|name2:api_key2:base_url2:modelA,modelB
    # 示例: deepseek:sk-xxx:https://api.deepseek.com/v1:deepseek-chat,deepseek-reasoner|qwen:sk-xxx:https://dashscope.aliyuncs.com/compatible-mode/v1:qwen-max,qwen-plus
    openai_compatible_providers: str = ""

    # ==================== 可选配置 — Ollama (本地) ====================
    ollama_base_url: str = "http://localhost:11434"
    ollama_models: str = ""  # 逗号分隔: "llama3.2,qwen2.5:7b,codellama"

    # ==================== 可选配置 — vLLM (本地 OpenAI 兼容) ====================
    vllm_base_url: str = "http://localhost:8000/v1"
    vllm_api_key: str = ""
    vllm_models: str = ""  # 逗号分隔: "my-model-v1,my-custom-model"

    # ==================== 可选配置 — 可观测性 ====================
    logfire_token: str = ""
    logfire_send_to_pydantic: bool = True

    # ==================== 可选配置 — 数据库 ====================
    database_url: str = "sqlite+aiosqlite:///./data/agent_platform.db"

    # ==================== 可选配置 — 速率限制 ====================
    rate_limit_requests: int = 100
    rate_limit_window: int = 60  # 秒

    # ==================== 可选配置 — CORS ====================
    cors_origins: str = "http://localhost:5173,http://localhost:3000"

    @property
    def cors_origins_list(self) -> list[str]:
        """解析为列表，便于 FastAPI 的 CORSMiddleware 使用"""
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]

    # ==================== 可选配置 — 目录 ====================
    skills_data_dir: str = "./skills-data"
    sandbox_dir: str = "./skills-data/sandbox"

    @property
    def skills_data_path(self) -> Path:
        return Path(self.skills_data_dir).resolve()

    @property
    def sandbox_path(self) -> Path:
        return Path(self.sandbox_dir).resolve()

    # ==================== 可选配置 — 能力开关 ====================
    # 默认为 false，用户通过环境变量按需启用
    enable_thinking: bool = False
    enable_planning: bool = False
    enable_code_mode: bool = False
    enable_filesystem: bool = False
    enable_shell: bool = False
    enable_subagents: bool = False
    enable_compaction: bool = False

    # ==================== 可选配置 — 人设 (多角色) ====================
    persona_dir: str = "config/personas"  # 人设配置目录，每个 .yaml 一个角色

    @property
    def persona_path(self) -> Path:
        p = Path(self.persona_dir)
        if p.is_absolute():
            return p
        # 相对于 backend/ 目录解析 (config.py 在 backend/src/agent_platform/ 下)
        backend_root = Path(__file__).resolve().parent.parent.parent
        resolved = (backend_root / p).resolve()
        if resolved.exists():
            return resolved
        # 回退: 相对于 CWD
        return p.resolve()

    # ==================== 可选配置 — 记忆系统 ====================
    enable_memory: bool = False  # 跨会话记忆开关: true=检索历史摘要辅助回答
    conversations_md_dir: str = "./data/conversations"  # 对话 MD 导出目录
    summaries_dir: str = "./data/summaries"  # 摘要索引目录

    @property
    def conversations_md_path(self) -> Path:
        return Path(self.conversations_md_dir).resolve()

    @property
    def summaries_path(self) -> Path:
        return Path(self.summaries_dir).resolve()

    # ==================== 可选配置 — 韧性系统 ====================
    # 并发控制
    max_concurrent_requests: int = 10  # 最大并发 Agent 请求数

    # 重试
    retry_max_attempts: int = 3       # 最大重试次数 (不含首次)
    retry_base_delay: float = 1.0     # 退避基础延迟 (秒)
    retry_max_delay: float = 30.0     # 退避最大延迟 (秒)

    # 模型回退链: 逗号分隔的备用模型列表
    # 示例: "openai:gpt-4.1,anthropic:claude-haiku-4-5-20251001"
    model_fallback_chain: str = ""

    # 熔断器
    circuit_breaker_threshold: int = 3   # 连续失败 N 次后熔断
    circuit_breaker_cooldown: int = 60   # 冷却时间 (秒)

    # 上下文管理
    context_compression_enabled: bool = True
    compressor_model: str = "anthropic:claude-haiku-4-5-20251001"
    max_context_messages: int = 20       # 最大上下文消息数
    max_context_tokens: int = 8000       # 最大上下文 token 数
    context_strategy: str = "sliding_window"  # sliding_window | truncate | summarize

    # ==================== 可选配置 — 安全参数 ====================
    agent_request_timeout: int = 120  # Agent 请求超时（秒）
    max_message_length: int = 10000  # 用户消息最大长度
    max_response_length: int = 65536  # Agent 响应最大长度
    max_file_read_bytes: int = 1048576  # 文件读取上限 (1MB)

    # ==================== 可选配置 — Shell 安全 ====================
    shell_allowed_commands: str = (
        "ls,cat,grep,find,head,tail,wc,sort,python,python3,node,"
        "mkdir,rm,cp,mv,echo,printf,date,whoami,curl,diff"
    )

    @property
    def shell_commands_list(self) -> list[str]:
        return [cmd.strip() for cmd in self.shell_allowed_commands.split(",") if cmd.strip()]

    # ==================== 派生属性 ====================

    @property
    def is_production(self) -> bool:
        return self.app_env == "production"

    @property
    def log_level(self) -> str:
        return "INFO" if self.is_production else "DEBUG"

    def has_any_llm_key(self) -> bool:
        """检查是否至少配置了一个 LLM Provider Key"""
        return bool(
            self.anthropic_api_key
            or self.openai_api_key
            or self.google_genai_api_key
            or self.groq_api_key
            or self.ollama_models  # Ollama 有模型配置才有效
            or self.vllm_models    # vLLM 有模型配置才有效
            or self.openai_compatible_providers  # 有自定义 Provider
        )

    def get_database_backend(self) -> str:
        """根据 database_url 返回数据库后端类型"""
        if self.database_url.startswith("postgresql"):
            return "postgresql"
        return "sqlite"


# 全局单例 — 整个应用共享同一配置实例
_settings: Settings | None = None


def get_settings() -> Settings:
    """获取全局配置单例

    首次调用时从环境变量 / .env 文件加载，后续调用返回缓存实例。
    """
    global _settings
    if _settings is None:
        _settings = Settings()
        # 确保必要目录存在
        _settings.skills_data_path.mkdir(parents=True, exist_ok=True)
        _settings.sandbox_path.mkdir(parents=True, exist_ok=True)
        # 确保数据库目录存在
        db_path = Path(_settings.database_url.replace("sqlite+aiosqlite:///", ""))
        if str(db_path).startswith("./"):
            db_path = Path.cwd() / str(db_path)[2:]
        db_path.parent.mkdir(parents=True, exist_ok=True)
    return _settings
