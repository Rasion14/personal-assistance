"""asyncio 兼容层

Python 3.10 缺少 asyncio.timeout (3.11+ 引入)。
此模块提供向后兼容的 asyncio_timeout 上下文管理器。
"""

from __future__ import annotations

import asyncio


def asyncio_timeout(delay: float | None):
    """asyncio.timeout 的跨版本兼容

    Python 3.11+: 直接返回 asyncio.timeout(delay)
    Python 3.10: 使用 asyncio.wait_for 包装

    用法:
        try:
            async with asyncio_timeout(5.0):
                result = await some_long_operation()
        except asyncio.TimeoutError:
            ...
    """
    if hasattr(asyncio, "timeout"):
        return asyncio.timeout(delay)
    else:
        return _TimeoutContext(delay)


class _TimeoutContext:
    """Python 3.10 的 asyncio.timeout 替代实现

    使用 Task.cancel() 实现超时取消。
    """

    def __init__(self, delay: float | None) -> None:
        self._delay = delay
        self._task: asyncio.Task | None = None
        self._timer: asyncio.Task | None = None

    async def __aenter__(self):
        if self._delay is not None and self._delay > 0:
            loop = asyncio.get_running_loop()
            self._task = asyncio.current_task()

            async def _timer():
                await asyncio.sleep(self._delay)
                if self._task and not self._task.done():
                    self._task.cancel()

            self._timer = asyncio.ensure_future(_timer())
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._timer and not self._timer.done():
            self._timer.cancel()
            try:
                await self._timer
            except asyncio.CancelledError:
                pass

        if exc_type is asyncio.CancelledError:
            raise asyncio.TimeoutError(
                f"Operation timed out after {self._delay}s"
            )

        return False
