"""测试当前配置的模型是否可用"""
import asyncio
from agent_platform.agents.factory import create_agent
from agent_platform.config import get_settings

async def main():
    s = get_settings()
    print(f'Model : {s.default_model}')
    print(f'URL   : {s.vllm_base_url}')
    print()

    agent, deps = create_agent(model_id=s.default_model, enable_thinking=False)
    print('Q: 你是谁')
    result = await agent.run('你是谁', deps=deps)
    print(f'A: {result.output}')
    print('OK!')

asyncio.run(main())
