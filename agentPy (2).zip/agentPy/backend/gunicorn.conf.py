"""Gunicorn 生产配置

用于 make run 或 production Docker 容器。
使用 uvicorn workers 支持 ASGI (FastAPI)。
"""

# Worker 配置
worker_class = "uvicorn.workers.UvicornWorker"
bind = "0.0.0.0:8000"

# Worker 数量 (公式: 2 × CPU + 1)
import multiprocessing
workers = (multiprocessing.cpu_count() or 1) * 2 + 1

# 超时
timeout = 120          # Worker 请求超时 (秒)
graceful_timeout = 30  # 优雅关闭超时 (秒)
keepalive = 5          # Keep-alive 连接时间 (秒)

# 日志
accesslog = "-"        # 访问日志输出到 stdout
errorlog = "-"         # 错误日志输出到 stderr
loglevel = "info"

# Worker 预热
preload_app = True     # 预加载应用 (减少内存, 加快启动)

# 进程名
proc_name = "agent-platform"
