# Agent Platform — Enterprise AI Agent

基于 FastAPI + Pydantic AI 2.x + Pydantic AI Harness 构建的 AI 智能体平台。

## 核心特性

- **多模型支持** — Anthropic Claude, OpenAI GPT, Google Gemini, Groq, DeepSeek, Qwen (通义千问), 智谱, Ollama, vLLM 无缝切换
- **Skill 系统** — 动态安装/卸载/启用/禁用 Skill，支持远程下载
- **流式对话** — SSE (Server-Sent Events) 实时流式输出
- **沙箱安全** — 代码执行、文件操作、Shell 命令均有严格安全边界
- **可观测性** — Logfire 全链路追踪、自定义指标、结构化日志
- **配置驱动** — 必要配置 + 可选配置，按需扩展 Agent 能力

## 快速开始

```bash
# 1. 克隆并进入项目
cd agentPy

# 2. 安装依赖
make install

# 3. 配置环境变量
cp backend/.env.example backend/.env
# 编辑 .env 填入你的 API Key

# 4. 启动开发服务器
make dev

# 5. 访问
# 后端 API: http://localhost:8000/api/docs
# 健康检查: http://localhost:8000/api/health
```

## 能力扩展

通过 `.env` 中的可选配置按需启用能力:

```bash
# 启用深度思考
ENABLE_THINKING=true

# 启用代码执行
ENABLE_CODE_MODE=true

# 启用文件操作
ENABLE_FILESYSTEM=true

# 启用 Shell 命令
ENABLE_SHELL=true
```

详见 [CONFIGURATION.md](docs/CONFIGURATION.md)。

## 部署

- **快速部署**: `make run` (Gunicorn + Uvicorn)
- **Docker 部署**: `make deploy-docker`
- **Docker Compose**: 包含 Backend + Frontend + (可选) PostgreSQL

详见 [DEPLOYMENT.md](docs/DEPLOYMENT.md)。

## 项目结构

```
agentPy/
├── backend/          # FastAPI 后端
│   ├── src/agent_platform/
│   │   ├── main.py          # 应用入口
│   │   ├── config.py        # 配置管理
│   │   ├── security.py      # 认证 & 限流
│   │   ├── errors.py        # 统一错误处理
│   │   ├── observability.py # 可观测性
│   │   ├── middleware/      # 中间件
│   │   ├── agents/          # Agent 工厂、系统指令、钩子
│   │   ├── api/             # API 路由
│   │   ├── capabilities/    # 能力注册
│   │   ├── conversations/   # 对话存储
│   │   ├── models/          # 模型注册与解析
│   │   ├── skills/          # Skill 管理
│   │   └── tools/           # 内置工具
│   └── tests/               # 测试
├── frontend/         # SvelteKit 前端
├── skills/           # 预装 Skill
├── docker-compose.yml
└── Makefile
```

详见 [ARCHITECTURE.md](docs/ARCHITECTURE.md)。

## 测试

```bash
make test           # 运行所有测试
make test-cov       # 运行测试 + 覆盖率报告
```

## License

MIT
