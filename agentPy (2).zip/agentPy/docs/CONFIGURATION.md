# Agent Platform — 配置说明

## 配置分类

配置分为 **必要配置** 和 **可选配置** 两类。

### 必要配置

| 环境变量 | 默认值 | 说明 |
|---------|--------|------|
| `APP_ENV` | `development` | 运行环境 (`development` / `production`) |
| `DEFAULT_MODEL` | `anthropic:claude-sonnet-4-6` | 默认模型 ID |
| `API_KEY` | `default-dev-key-change-me` | API 认证密钥 (生产环境必须修改) |

> **注意**: 至少配置一个 LLM Provider 的 Key 或模型配置，否则 Agent 无法运行。

---

## LLM Provider 配置

### 内置 Provider

| 环境变量 | 默认值 | 说明 |
|---------|--------|------|
| `ANTHROPIC_API_KEY` | `` | Anthropic Claude API Key |
| `OPENAI_API_KEY` | `` | OpenAI API Key |
| `GOOGLE_GENAI_API_KEY` | `` | Google Gemini API Key |
| `GROQ_API_KEY` | `` | Groq API Key |

### OpenAI 兼容 Providers (DeepSeek, Qwen, 智谱等)

支持任何兼容 OpenAI API 的第三方大模型服务。

| 环境变量 | 默认值 | 说明 |
|---------|--------|------|
| `OPENAI_COMPATIBLE_PROVIDERS` | `` | 自定义 Provider 配置 |

**格式**: `name:api_key:base_url:model1,model2,model3`
多个 Provider 用 `|` 分隔。

**示例 — DeepSeek + 通义千问 + 智谱**:
```bash
OPENAI_COMPATIBLE_PROVIDERS=deepseek:sk-your-key:https://api.deepseek.com/v1:deepseek-chat,deepseek-reasoner|qwen:sk-your-key:https://dashscope.aliyuncs.com/compatible-mode/v1:qwen-max,qwen-plus,qwen-turbo|zhipu:your-key:https://open.bigmodel.cn/api/paas/v4:glm-4-plus,glm-4-flash
```

配置后，模型列表会自动包含这些 Provider 的模型。
选择模型时使用 `openai:model-name` 格式（如 `openai:deepseek-chat`），系统会自动路由到对应的 API 端点。

### Ollama (本地部署)

| 环境变量 | 默认值 | 说明 |
|---------|--------|------|
| `OLLAMA_BASE_URL` | `http://localhost:11434` | Ollama 服务地址 |
| `OLLAMA_MODELS` | `` | 逗号分隔的模型列表 |

**示例**:
```bash
OLLAMA_MODELS=llama3.2,qwen2.5:7b,codellama,deepseek-r1:8b
```

模型 ID 格式: `ollama:model-name`（如 `ollama:llama3.2`）

### vLLM (本地 OpenAI 兼容)

| 环境变量 | 默认值 | 说明 |
|---------|--------|------|
| `VLLM_BASE_URL` | `http://localhost:8000/v1` | vLLM 服务地址 |
| `VLLM_API_KEY` | `` | 可选 API Key |
| `VLLM_MODELS` | `` | 逗号分隔的模型列表 |

**示例**:
```bash
VLLM_MODELS=my-custom-model-v1,my-finetuned-model
```

模型 ID 格式: `openai:model-name`（如 `openai:my-custom-model-v1`），自动路由到 vLLM 端点。

---

## 可选配置 — 能力开关

所有能力默认 **关闭**，通过环境变量按需启用:

| 环境变量 | 默认值 | 说明 |
|---------|--------|------|
| `ENABLE_THINKING` | `false` | 深度思考 (High effort reasoning) |
| `ENABLE_PLANNING` | `false` | 任务规划 |
| `ENABLE_CODE_MODE` | `false` | 沙箱代码执行 |
| `ENABLE_FILESYSTEM` | `false` | 安全文件操作 |
| `ENABLE_SHELL` | `false` | 安全命令执行 |
| `ENABLE_SUBAGENTS` | `false` | 子智能体委派 |
| `ENABLE_COMPACTION` | `false` | 对话历史压缩 |

## 可选配置 — 安全参数

| 环境变量 | 默认值 | 说明 |
|---------|--------|------|
| `AGENT_REQUEST_TIMEOUT` | `120` | Agent 请求超时 (秒) |
| `MAX_MESSAGE_LENGTH` | `10000` | 用户消息最大长度 |
| `MAX_RESPONSE_LENGTH` | `65536` | Agent 响应最大长度 |
| `MAX_FILE_READ_BYTES` | `1048576` | 文件读取上限 (字节) |

## 可选配置 — 数据库

| 环境变量 | 默认值 | 说明 |
|---------|--------|------|
| `DATABASE_URL` | `sqlite+aiosqlite:///./data/agent_platform.db` | 数据库连接 URL |

支持的后端: **SQLite** 和 **PostgreSQL**

## 可选配置 — 速率限制

| 环境变量 | 默认值 | 说明 |
|---------|--------|------|
| `RATE_LIMIT_REQUESTS` | `20` | 限流请求数 |
| `RATE_LIMIT_WINDOW` | `60` | 限流时间窗口 (秒) |

## 可选配置 — 可观测性

| 环境变量 | 默认值 | 说明 |
|---------|--------|------|
| `LOGFIRE_TOKEN` | `` | Logfire 追踪 Token |
| `LOGFIRE_SEND_TO_PYDANTIC` | `true` | 是否发送数据到 Logfire 云端 |

## 配置优先级

环境变量 > `.env` 文件 > 默认值

## 生产环境安全校验

当 `APP_ENV=production` 时:
- 如果 `API_KEY=default-dev-key-change-me`，应用 **拒绝启动**
- 如果未配置任何 LLM Provider Key 或模型配置，发出 warn 日志但不阻止
