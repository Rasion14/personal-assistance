# Agent Platform — 部署指南

## 快速部署（裸 Python）

适用于本地开发和快速验证。

### 1. 环境准备

```bash
# Python 3.10+
python --version

# Node.js 20+ (前端)
node --version
```

### 2. 安装依赖

```bash
make install          # 安装后端 + 前端依赖
# 或分别安装
make install-backend  # pip install -e ".[dev]"
make install-frontend # npm install
```

### 3. 配置

```bash
cp backend/.env.example backend/.env
# 编辑 .env，至少配置 ANTHROPIC_API_KEY（或其他 Provider）
```

### 4. 启动

```bash
# 开发模式
make dev-backend      # uvicorn --reload
make dev-frontend     # Vite dev server

# 生产模式
make run              # Gunicorn + Uvicorn workers
```

### 5. 访问

- 后端 API 文档: http://localhost:8000/api/docs
- 前端: http://localhost:3000

---

## Docker 部署

### 1. 前置条件

- Docker Engine 24+
- Docker Compose v2

### 2. 构建并启动

```bash
# 首次部署
make deploy-docker

# 查看日志
make logs-docker

# 停止
make stop-docker
```

### 3. 手动操作

```bash
# 构建并启动
docker compose up --build -d

# 仅重启
docker compose restart

# 查看状态
docker compose ps
```

### 4. 配置

Docker 部署使用 `backend/.env` 作为环境变量来源。确保 `.env` 文件中包含必要的配置。

### 5. 持久化

数据持久化目录（通过 volumes 挂载）:
- `./backend/data/` — 数据库文件
- `./skills-data/` — Skill 和沙箱数据

---

## 使用 PostgreSQL

### Docker Compose

取消 `docker-compose.yml` 中 `postgres` 服务的注释，并修改 `.env`:

```bash
DATABASE_URL=postgresql+asyncpg://agent_user:agent_password@postgres:5432/agent_platform
```

### 本地开发

```bash
# 启动 PostgreSQL
docker run -d --name agent-pg -p 5432:5432 \
  -e POSTGRES_DB=agent_platform \
  -e POSTGRES_USER=agent_user \
  -e POSTGRES_PASSWORD=agent_password \
  postgres:17-alpine

# 配置 DATABASE_URL
DATABASE_URL=postgresql+asyncpg://agent_user:agent_password@localhost:5432/agent_platform
```

---

## 生产检查清单

- [ ] 修改 `API_KEY` 为强密钥
- [ ] 配置 LLM Provider API Key
- [ ] 设置 `APP_ENV=production`
- [ ] 配置 `CORS_ORIGINS` 为实际前端域名
- [ ] 按需启用能力开关
- [ ] 配置 Logfire Token（可观测性）
- [ ] 配置合理的 `RATE_LIMIT_REQUESTS`
- [ ] 设置 `AGENT_REQUEST_TIMEOUT`
- [ ] 运行测试: `make test`
