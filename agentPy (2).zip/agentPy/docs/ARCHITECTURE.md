# Agent Platform — 架构设计

## 架构概览

```
┌─────────────────────────────────────────────────────┐
│                    Frontend (SvelteKit)              │
│  ┌──────────┐  ┌──────────┐  ┌──────────────┐      │
│  │  Chat UI  │  │ Skills   │  │  Settings    │      │
│  └────┬─────┘  └────┬─────┘  └──────┬───────┘      │
└───────┼──────────────┼──────────────┼───────────────┘
        │              │              │
        │   HTTP / SSE │              │
        ├──────────────┼──────────────┤
        │              │              │
┌───────┼──────────────┼──────────────┼───────────────┐
│       ▼              ▼              ▼               │
│  Backend (FastAPI)                               │
│                                                   │
│  Middleware:                                      │
│  ┌──────────┐ ┌──────────┐ ┌──────────────────┐  │
│  │ CORS     │ │ API Key  │ │ Rate Limiter     │  │
│  │          │ │ Auth     │ │                  │  │
│  └──────────┘ └──────────┘ └──────────────────┘  │
│                                                   │
│  Routers:                                         │
│  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌────────┐ │
│  │Health│ │ Chat │ │Models│ │Skills│ │Convo   │ │
│  └──┬───┘ └──┬───┘ └──┬───┘ └──┬───┘ └───┬────┘ │
│     │        │        │        │         │       │
│     │        ▼        │        │         │       │
│     │   ┌─────────────┼────────┴─────────┤       │
│     │   │ Agent Factory                        │  │
│     │   │  ┌─────────┐ ┌────────┐ ┌──────┐    │  │
│     │   │  │ Systems │ │Tools   │ │Hooks │    │  │
│     │   │  │ Prompt  │ │(6 built│ │      │    │  │
│     │   │  └─────────┘ │ in)    │ └──────┘    │  │
│     │   │  ┌──────────┐│        │             │  │
│     │   │  │ Capabili-││        │             │  │
│     │   │  │ ties(7)  ││        │             │  │
│     │   │  └──────────┘│        │             │  │
│     │   └──────────────│────────┘             │  │
│     │                  │                      │  │
│     │              LLM Provider               │  │
│     │           (Anthropic/OpenAI/...)        │  │
│     │                                        │  │
│  Storage:                                   │  │
│  ┌──────────────────────────────────────┐   │  │
│  │ SQLite / PostgreSQL (对话持久化)       │   │  │
│  └──────────────────────────────────────┘   │  │
│                                              │  │
└──────────────────────────────────────────────┘
```

## 分层架构

| 层 | 模块 | 职责 |
|---|------|------|
| **Entry** | `main.py` | ASGI 应用工厂，生命周期管理 |
| **Middleware** | `security.py`, `middleware/` | 认证、限流、请求追踪 |
| **API Routes** | `api/router_*.py` | HTTP 端点，请求/响应模型 |
| **Business Logic** | `agents/factory.py`, `conversations/service.py` | Agent 创建、对话管理 |
| **Domain** | `tools/`, `skills/`, `capabilities/`, `models/` | 核心业务领域 |
| **Storage** | `conversations/storage*.py` | 数据持久化 |
| **Config** | `config.py` | 全局配置 |
| **Observability** | `observability.py` | 指标、追踪 |

## Agent 生命周期

```
HTTP Request (chat/stream)
    │
    ▼
Router: 输入验证 → 创建 Agent
    │
    ▼
Factory:
    ├─ AgentDeps (运行时依赖)
    ├─ System Instructions (基础指令 + Skill 注入)
    ├─ Capabilities (按需启用)
    ├─ Tools (6 个内置工具)
    └─ Hooks (生命周期钩子)
    │
    ▼
Agent.run() / Agent.run_stream()
    │
    ├─ before_run: 记录开始时间
    ├─ before_model_request: 记录消息数
    ├─ LLM Provider (网络请求)
    ├─ after_model_request: 记录完成
    ├─ after_run: 记录耗时和用量
    └─ run_error: 记录错误
    │
    ▼
Response: 截断响应 → 记录指标 → 返回客户端
```

## 能力扩展系统

### 必要配置 (Required)
- `APP_ENV` — 环境标识
- `DEFAULT_MODEL` — 默认模型
- `API_KEY` — 认证密钥
- 至少一个 LLM Provider Key

### 可选配置 (Optional — 按需启用)
- **Thinking** (`ENABLE_THINKING`) — 模型深度推理
- **Planning** (`ENABLE_PLANNING`) — 任务规划
- **CodeMode** (`ENABLE_CODE_MODE`) — 沙箱代码执行
- **FileSystem** (`ENABLE_FILESYSTEM`) — 安全文件操作
- **Shell** (`ENABLE_SHELL`) — 白名单命令执行
- **SubAgents** (`ENABLE_SUBAGENTS`) — 子智能体委派
- **Compaction** (`ENABLE_COMPACTION`) — 对话历史压缩

每个能力独立编译时导入，缺失依赖时 graceful degradation（不报错，静默跳过）。

## Skill 系统

```
SKILL.md / skill.yaml  (Skill 定义)
    │
    ▼
loader.py: 解析 → dict {name, version, instructions, tools}
    │
    ▼
registry.py: CRUD → JSON 持久化 → 启用/禁用切换
    │
    ▼
factory.py: 已启用 Skill → 注入系统指令
    │
    ▼
Agent 运行时
```

### 远程安装
```
URL (GitHub/GitLab/Direct ZIP)
    │
    ▼
downloader.py: 下载 → ZIP Slip 校验 → 解压 → 结构校验
    │
    ▼
registry.py: 注册
```

## 安全边界

| 边界 | 实现 |
|------|------|
| API 认证 | X-API-Key 头校验 |
| 速率限制 | slowapi per-key fixed window |
| 输入长度 | `MAX_MESSAGE_LENGTH` (10000) |
| 输出长度 | `MAX_RESPONSE_LENGTH` (65536) |
| 请求超时 | `AGENT_REQUEST_TIMEOUT` (120s) |
| 文件读取 | `MAX_FILE_READ_BYTES` (1MB) |
| 文件路径 | `_safe_resolve()` 防止路径穿越 |
| 计算器 | 正则白名单 + `__builtins__={}` |
| Shell | 命令白名单 + 30s 超时 |
| ZIP 下载 | 50MB 上限 + ZIP Slip 防护 |
| 生产安全 | 默认 Key 检测 → 拒绝启动 |

## 技术栈

- **后端**: Python 3.14, FastAPI, Pydantic AI 2.x, Pydantic AI Harness
- **前端**: Svelte 5, SvelteKit, TailwindCSS, DaisyUI
- **可观测性**: Logfire (OpenTelemetry)
- **数据库**: SQLite (默认) / PostgreSQL (可选)
- **部署**: Docker, Gunicorn + Uvicorn
